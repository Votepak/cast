# Image credits

- Hero image (`public/images/pakistan-voices.jpg`): AI-generated for Pakvote. It depicts a fictional group of people and is not an image of a real event.
- Imran Khan (`public/images/imran.jpg`): *Imran Khan - UNGA (48784380531) - cropped enhanced.jpg*, The White House, public domain (U.S. Government work). https://commons.wikimedia.org/wiki/File:Imran_Khan_-_UNGA_(48784380531)_-_cropped_enhanced.jpg
- Nawaz Sharif (`public/images/nawaz.jpg`): *Nawaz Sharif March 2014.jpg*, U.S. Department of State, public domain (U.S. Government work). https://commons.wikimedia.org/wiki/File:Nawaz_Sharif_March_2014.jpg
- Bilawal Bhutto Zardari (`public/images/bilawal.jpg`): *Bilawal - 2022 (52577074232) (cropped).jpg*, Ron Przysucha / U.S. Department of State, public domain (U.S. Government work). https://commons.wikimedia.org/wiki/File:Bilawal_-_2022_(52577074232)_(cropped).jpg

The use of a portrait is for neutral identification only; it does not imply endorsement. Pakistan flag drawn in-site with SVG as a representation of the national flag.
