import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  devIndicators: false,
  allowedDevOrigins: ['*.e2b.app', '127.0.0.1', 'localhost'],
};

export default nextConfig;
