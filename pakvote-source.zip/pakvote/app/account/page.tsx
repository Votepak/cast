import type { Metadata } from 'next';
import { AccountClient } from '@/components/AccountClient';
export const metadata: Metadata = {
  title: 'My account',
  description: 'See your verified account and polls you have participated in.',
};
export default function AccountPage() {
  return <AccountClient />;
}
