import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import {
  ApiError,
  adminCredentials,
  assertSameOrigin,
  clientIp,
  handleApiError,
  isAdmin,
  isEqual,
  rateLimit,
  startAdminSession,
} from '@/lib/security';
import { isDemoMode } from '@/lib/db';
export const runtime = 'nodejs';
export async function GET(req: NextRequest) {
  try {
    return NextResponse.json(
      { authenticated: await isAdmin(req), demo: isDemoMode() },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  } catch (error) {
    return handleApiError(error);
  }
}
export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req);
    await rateLimit(`admin-ip:${clientIp(req)}`, 12, 15);
    const data = z
      .object({ email: z.string().trim().email().max(254), password: z.string().min(1).max(300) })
      .parse(await req.json());
    const credentials = adminCredentials();
    if (
      !isEqual(data.email.toLowerCase(), credentials.email.toLowerCase()) ||
      !isEqual(data.password, credentials.password)
    ) {
      throw new ApiError('Invalid administrator credentials.', 401);
    }
    const response = NextResponse.json({ ok: true });
    await startAdminSession(response);
    return response;
  } catch (error) {
    return handleApiError(error);
  }
}
