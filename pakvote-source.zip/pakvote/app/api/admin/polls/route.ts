import { NextRequest, NextResponse } from 'next/server';
import { getDb, getPolls, isDemoMode, newId } from '@/lib/db';
import { ApiError, assertSameOrigin, handleApiError, requireAdmin } from '@/lib/security';
import { pollInput } from '@/lib/poll-validation';
import { slugify } from '@/lib/utils';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);
    const db = await getDb();
    const [users, subscribers, pending] = await db.batch(
      [
        { sql: "SELECT COUNT(*) AS n FROM users WHERE email NOT LIKE '%@example.invalid'", args: [] },
        { sql: 'SELECT COUNT(*) AS n FROM subscriptions WHERE unsubscribed_at IS NULL', args: [] },
        {
          sql: 'SELECT COUNT(*) AS n FROM subscriptions WHERE sent_at IS NULL AND unsubscribed_at IS NULL',
          args: [],
        },
      ],
      'read',
    );
    return NextResponse.json(
      {
        polls: await getPolls(true),
        stats: {
          users: Number(users.rows[0]?.n || 0),
          subscribers: Number(subscribers.rows[0]?.n || 0),
          pending: Number(pending.rows[0]?.n || 0),
        },
        demo: isDemoMode(),
      },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req);
    await requireAdmin(req);
    const input = pollInput.parse(await req.json());
    const db = await getDb();
    const base = slugify(input.title);
    if (!base) throw new ApiError('Please provide a title using letters or numbers.');
    let slug = base;
    const found = await db.execute({ sql: 'SELECT 1 FROM polls WHERE slug=?', args: [slug] });
    if (found.rows.length) slug = `${base}-${Math.random().toString(36).slice(2, 7)}`;
    const id = newId('poll');
    const now = new Date().toISOString();
    const statements = [
      ...(input.isFeatured
        ? [{ sql: 'UPDATE polls SET is_featured=0', args: [] as (string | number)[] }]
        : []),
      {
        sql: `INSERT INTO polls (id,slug,title,question,description,kind,starts_at,ends_at,status,is_featured,created_at,updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
        args: [
          id,
          slug,
          input.title,
          input.question,
          input.description,
          input.kind,
          input.startsAt,
          input.endsAt,
          input.status,
          input.isFeatured ? 1 : 0,
          now,
          now,
        ],
      },
      ...input.options.map((option, position) => ({
        sql: 'INSERT INTO options (id,poll_id,label,short_label,color,position) VALUES (?,?,?,?,?,?)',
        args: [newId('option'), id, option.label, option.shortLabel, option.color, position],
      })),
    ];
    await db.batch(statements, 'write');
    return NextResponse.json({ ok: true, id, slug }, { status: 201 });
  } catch (error) {
    return handleApiError(error);
  }
}
