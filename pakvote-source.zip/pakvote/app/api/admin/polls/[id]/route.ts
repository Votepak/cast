import { NextRequest, NextResponse } from 'next/server';
import { getDb, getPollById, newId } from '@/lib/db';
import { ApiError, assertSameOrigin, handleApiError, requireAdmin } from '@/lib/security';
import { pollInput } from '@/lib/poll-validation';
export const runtime = 'nodejs';

interface RouteContext {
  params: Promise<{ id: string }>;
}
export async function PATCH(req: NextRequest, context: RouteContext) {
  try {
    assertSameOrigin(req);
    await requireAdmin(req);
    const { id } = await context.params;
    const poll = await getPollById(id);
    if (!poll) throw new ApiError('Poll not found.', 404);
    const input = pollInput.parse(await req.json());
    if (
      poll.totalVotes &&
      (input.kind !== poll.kind ||
        input.options.length !== poll.options.length ||
        input.options.some(
          (o, i) => o.label !== poll.options[i].label || o.shortLabel !== poll.options[i].shortLabel,
        ))
    )
      throw new ApiError(
        'Ballot options and poll type cannot change after votes have been cast. You can create a new poll instead.',
        409,
      );
    const db = await getDb();
    const statements = [
      ...(input.isFeatured ? [{ sql: 'UPDATE polls SET is_featured=0 WHERE id!=?', args: [id] }] : []),
      {
        sql: `UPDATE polls SET title=?,question=?,description=?,kind=?,starts_at=?,ends_at=?,status=?,is_featured=?,updated_at=? WHERE id=?`,
        args: [
          input.title,
          input.question,
          input.description,
          input.kind,
          input.startsAt,
          input.endsAt,
          input.status,
          input.isFeatured ? 1 : 0,
          new Date().toISOString(),
          id,
        ],
      },
      ...input.options.map((option, i) => ({
        sql: 'UPDATE options SET label=?,short_label=?,color=?,position=? WHERE id=? AND poll_id=?',
        args: [option.label, option.shortLabel, option.color, i, poll.options[i]?.id || '', id],
      })),
      ...(!poll.totalVotes && input.options.length < poll.options.length
        ? poll.options.slice(input.options.length).map((option) => ({
            sql: 'DELETE FROM options WHERE id=? AND poll_id=?',
            args: [option.id, id],
          }))
        : []),
      ...(!poll.totalVotes && input.options.length > poll.options.length
        ? input.options.slice(poll.options.length).map((option, offset) => ({
            sql: 'INSERT INTO options (id,poll_id,label,short_label,color,position) VALUES (?,?,?,?,?,?)',
            args: [
              newId('option'),
              id,
              option.label,
              option.shortLabel,
              option.color,
              poll.options.length + offset,
            ],
          }))
        : []),
    ];
    await db.batch(statements, 'write');
    return NextResponse.json({ ok: true });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest, context: RouteContext) {
  try {
    assertSameOrigin(req);
    await requireAdmin(req);
    const { id } = await context.params;
    const poll = await getPollById(id);
    if (!poll) throw new ApiError('Poll not found.', 404);
    const db = await getDb();
    const subscribed = await db.execute({
      sql: 'SELECT COUNT(*) AS n FROM subscriptions WHERE poll_id=?',
      args: [id],
    });
    if (poll.totalVotes || Number(subscribed.rows[0]?.n))
      throw new ApiError(
        'Polls with votes or subscribers cannot be deleted. Close the poll instead.',
        409,
      );
    if (poll.status !== 'draft') throw new ApiError('Only draft polls can be deleted.', 409);
    await db.batch(
      [
        { sql: 'DELETE FROM options WHERE poll_id=?', args: [id] },
        { sql: 'DELETE FROM polls WHERE id=? AND status=?', args: [id, 'draft'] },
      ],
      'write',
    );
    return NextResponse.json({ ok: true });
  } catch (error) {
    return handleApiError(error);
  }
}
