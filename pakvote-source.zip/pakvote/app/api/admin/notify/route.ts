import { NextRequest, NextResponse } from 'next/server';
import { sendDueResults } from '@/lib/notifications';
import { assertSameOrigin, handleApiError, requireAdmin } from '@/lib/security';
export const runtime = 'nodejs';
export const maxDuration = 60;
export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req);
    await requireAdmin(req);
    return NextResponse.json(await sendDueResults(40));
  } catch (error) {
    return handleApiError(error);
  }
}
