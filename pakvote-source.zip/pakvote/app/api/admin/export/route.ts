import { NextRequest, NextResponse } from 'next/server';
import { getPollById, getResults } from '@/lib/db';
import { buildResultsCsv } from '@/lib/csv';
import { ApiError, handleApiError, requireAdmin } from '@/lib/security';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);
    const poll = await getPollById(req.nextUrl.searchParams.get('pollId') || '');
    if (!poll) throw new ApiError('Poll not found.', 404);
    return new NextResponse(buildResultsCsv(poll, await getResults(poll)), {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="pakvote-${poll.slug}-results.csv"`,
        'Cache-Control': 'no-store',
      },
    });
  } catch (error) {
    return handleApiError(error);
  }
}
