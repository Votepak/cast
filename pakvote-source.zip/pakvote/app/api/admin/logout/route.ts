import { NextRequest, NextResponse } from 'next/server';
import { assertSameOrigin, handleApiError, signOutAdmin } from '@/lib/security';
export const runtime = 'nodejs';
export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req);
    const response = NextResponse.json({ ok: true });
    await signOutAdmin(req, response);
    return response;
  } catch (error) {
    return handleApiError(error);
  }
}
