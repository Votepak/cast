import { NextRequest, NextResponse } from 'next/server';
import { randomInt } from 'node:crypto';
import { z } from 'zod';
import { getDb, isDemoMode } from '@/lib/db';
import {
  ApiError,
  assertSameOrigin,
  clientIp,
  handleApiError,
  hmac,
  rateLimit,
  secret,
} from '@/lib/security';
import { emailShell, escapeHtml, sendEmail } from '@/lib/mailer';
export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req);
    const payload = z.object({ email: z.string().trim().email().max(254) }).parse(await req.json());
    const email = payload.email.toLowerCase();
    await rateLimit(`code-ip:${clientIp(req)}`, 12, 15);
    await rateLimit(`code-email:${email}`, 5, 60);
    const db = await getDb();
    const prior = (
      await db.execute({ sql: 'SELECT created_at FROM auth_codes WHERE email=?', args: [email] })
    ).rows[0];
    if (prior && Date.now() - new Date(String(prior.created_at)).getTime() < 60000) {
      throw new ApiError('Please wait one minute before requesting a new code.', 429);
    }
    const code = String(randomInt(100000, 1000000));
    const now = new Date().toISOString();
    await db.execute({
      sql: `INSERT INTO auth_codes (email,code_hash,expires_at,attempts,created_at) VALUES (?,?,?,?,?)
            ON CONFLICT(email) DO UPDATE SET code_hash=excluded.code_hash, expires_at=excluded.expires_at,
            attempts=0, created_at=excluded.created_at`,
      args: [
        email,
        hmac(`${email}:${code}`, secret('OTP_SECRET')),
        new Date(Date.now() + 10 * 60000).toISOString(),
        0,
        now,
      ],
    });
    const showCode =
      process.env.NODE_ENV === 'development' && (isDemoMode() || process.env.DEV_SHOW_OTP === 'true');
    if (!showCode || process.env.RESEND_API_KEY) {
      try {
        await sendEmail({
          to: email,
          subject: 'Your Pakvote verification code',
          html: emailShell(
            `<h1 style="margin:0 0 12px;font-size:24px">Verify your email</h1><p>Use this code to sign in to Pakvote. It expires in 10 minutes.</p><div style="font-size:32px;letter-spacing:9px;font-weight:bold;color:#0b493c;padding:14px 0">${escapeHtml(code)}</div><p style="color:#6b7f77">If you did not request this code, you can safely ignore this email.</p>`,
          ),
          text: `Your Pakvote verification code is ${code}. It expires in 10 minutes. If this wasn't you, ignore this email.`,
        });
      } catch (error) {
        await db.execute({ sql: 'DELETE FROM auth_codes WHERE email=?', args: [email] });
        throw error;
      }
    }
    return NextResponse.json({ ok: true, ...(showCode ? { devCode: code } : {}) });
  } catch (error) {
    return handleApiError(error);
  }
}
