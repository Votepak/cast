import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { getDb, newId } from '@/lib/db';
import {
  ApiError,
  assertSameOrigin,
  clientIp,
  handleApiError,
  hmac,
  isEqual,
  rateLimit,
  secret,
  startUserSession,
} from '@/lib/security';
export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req);
    const { email: rawEmail, code } = z
      .object({
        email: z.string().trim().email().max(254),
        code: z.string().regex(/^\d{6}$/),
      })
      .parse(await req.json());
    const email = rawEmail.toLowerCase();
    await rateLimit(`verify-ip:${clientIp(req)}`, 25, 15);
    const db = await getDb();
    const found = (await db.execute({ sql: 'SELECT * FROM auth_codes WHERE email=?', args: [email] }))
      .rows[0];
    if (!found || Date.now() > new Date(String(found.expires_at)).getTime())
      throw new ApiError('This code has expired. Request a new one.', 400);
    if (Number(found.attempts) >= 5)
      throw new ApiError('Too many incorrect codes. Request a new one.', 429);
    await db.execute({ sql: 'UPDATE auth_codes SET attempts=attempts+1 WHERE email=?', args: [email] });
    const codeHash = hmac(`${email}:${code}`, secret('OTP_SECRET'));
    if (!isEqual(codeHash, String(found.code_hash)))
      throw new ApiError('Incorrect code. Please try again.');
    const deleted = await db.execute({
      sql: 'DELETE FROM auth_codes WHERE email=? AND code_hash=? AND expires_at>? AND attempts<=5',
      args: [email, codeHash, new Date().toISOString()],
    });
    if (!deleted.rowsAffected) throw new ApiError('This code has already been used or expired.');
    const now = new Date().toISOString();
    await db.execute({
      sql: 'INSERT OR IGNORE INTO users (id,email,created_at,verified_at) VALUES (?,?,?,?)',
      args: [newId('user'), email, now, now],
    });
    const user = (await db.execute({ sql: 'SELECT id FROM users WHERE email=?', args: [email] }))
      .rows[0];
    if (!user) throw new Error('User creation failed.');
    const response = NextResponse.json({ ok: true });
    await startUserSession(String(user.id), req, response);
    return response;
  } catch (error) {
    return handleApiError(error);
  }
}
