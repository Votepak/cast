import { NextRequest, NextResponse } from 'next/server';
import { currentUser, handleApiError } from '@/lib/security';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export async function GET(req: NextRequest) {
  try {
    return NextResponse.json(
      { user: await currentUser(req) },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  } catch (error) {
    return handleApiError(error);
  }
}
