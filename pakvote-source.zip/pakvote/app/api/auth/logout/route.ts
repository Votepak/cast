import { NextRequest, NextResponse } from 'next/server';
import { assertSameOrigin, handleApiError, signOutUser } from '@/lib/security';
export const runtime = 'nodejs';
export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req);
    const response = NextResponse.json({ ok: true });
    await signOutUser(req, response);
    return response;
  } catch (error) {
    return handleApiError(error);
  }
}
