import { NextRequest, NextResponse } from 'next/server';
import { getPollById, getResults, isDemoMode } from '@/lib/db';
import { REGIONS, GENDERS } from '@/lib/regions';
import { ApiError, handleApiError } from '@/lib/security';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export async function GET(req: NextRequest) {
  try {
    const pollId = req.nextUrl.searchParams.get('pollId');
    if (!pollId || pollId.length > 120) throw new ApiError('Please choose a poll.');
    const poll = await getPollById(pollId);
    if (!poll || (poll.status === 'draft' && !poll.isFeatured))
      throw new ApiError('Poll not found.', 404);
    const gender = req.nextUrl.searchParams.get('gender') || '';
    const province = req.nextUrl.searchParams.get('province') || '';
    const district = req.nextUrl.searchParams.get('district') || '';
    if (gender && !GENDERS.includes(gender as (typeof GENDERS)[number]))
      throw new ApiError('Invalid gender filter.');
    if (province && !REGIONS[province]) throw new ApiError('Invalid province filter.');
    if (district && (!province || !REGIONS[province].includes(district)))
      throw new ApiError('Invalid district filter.');
    return NextResponse.json(
      { poll, results: await getResults(poll, { gender, province, district }), demo: isDemoMode() },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  } catch (error) {
    return handleApiError(error);
  }
}
