import { NextRequest, NextResponse } from 'next/server';
import { getPollById, getResults } from '@/lib/db';
import { buildResultsCsv } from '@/lib/csv';
import { ApiError, handleApiError } from '@/lib/security';
import { getPollStatus } from '@/lib/utils';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export async function GET(req: NextRequest) {
  try {
    const poll = await getPollById(req.nextUrl.searchParams.get('pollId') || '');
    if (!poll || poll.status === 'draft') throw new ApiError('Poll not found.', 404);
    if (getPollStatus(poll) !== 'ended')
      throw new ApiError('The results file is available when this poll ends.', 403);
    return new NextResponse(buildResultsCsv(poll, await getResults(poll)), {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="pakvote-${poll.slug}-results.csv"`,
        'Cache-Control': 'no-store',
      },
    });
  } catch (error) {
    return handleApiError(error);
  }
}
