import { NextRequest, NextResponse } from 'next/server';
import { sendDueResults } from '@/lib/notifications';
import { ApiError, handleApiError, isEqual } from '@/lib/security';
export const runtime = 'nodejs';
export const maxDuration = 60;
export const dynamic = 'force-dynamic';
export async function GET(req: NextRequest) {
  try {
    if (
      !process.env.CRON_SECRET ||
      !isEqual(req.headers.get('authorization') || '', `Bearer ${process.env.CRON_SECRET}`)
    ) {
      throw new ApiError('Unauthorized.', 401);
    }
    return NextResponse.json(await sendDueResults(40));
  } catch (error) {
    return handleApiError(error);
  }
}
