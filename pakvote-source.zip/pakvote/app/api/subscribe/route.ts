import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { getDb, getPollById, newId } from '@/lib/db';
import { ApiError, assertSameOrigin, currentUser, handleApiError, token } from '@/lib/security';
export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req);
    const data = z
      .object({
        pollId: z.string().min(1).max(120),
        email: z.string().trim().email().max(254),
        consent: z.literal(true),
      })
      .parse(await req.json());
    const user = await currentUser(req);
    if (!user) throw new ApiError('Please verify your email before subscribing.', 401);
    if (user.email !== data.email.toLowerCase())
      throw new ApiError('Enter the email address you verified when signing in.');
    const poll = await getPollById(data.pollId);
    if (!poll || (poll.status === 'draft' && !poll.isFeatured))
      throw new ApiError('Poll not found.', 404);
    const db = await getDb();
    await db.execute({
      sql: `INSERT INTO subscriptions (id,poll_id,email,unsubscribe_token,created_at)
        VALUES (?,?,?,?,?) ON CONFLICT (poll_id,email) DO UPDATE SET
        unsubscribed_at=NULL, unsubscribe_token=excluded.unsubscribe_token,
        sent_at=CASE WHEN subscriptions.sent_at IS NOT NULL THEN subscriptions.sent_at ELSE NULL END`,
      args: [newId('subscription'), poll.id, user.email, token(), new Date().toISOString()],
    });
    return NextResponse.json({
      ok: true,
      message: 'You are subscribed. We’ll email the results CSV after the poll ends.',
    });
  } catch (error) {
    return handleApiError(error);
  }
}
