import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
export const runtime = 'nodejs';
export async function GET(req: NextRequest) {
  const token = req.nextUrl.searchParams.get('token') || '';
  let status = 'invalid';
  if (/^[a-f0-9]{64}$/.test(token)) {
    try {
      const saved = await (
        await getDb()
      ).execute({
        sql: 'UPDATE subscriptions SET unsubscribed_at=? WHERE unsubscribe_token=?',
        args: [new Date().toISOString(), token],
      });
      status = saved.rowsAffected ? 'success' : 'invalid';
    } catch (error) {
      console.error('[pakvote] unsubscribe:', error);
      status = 'error';
    }
  }
  // Next.js can expose its bind address (0.0.0.0) as req.url in local previews.
  // Redirect to the actual public origin instead of that internal address.
  const forwardedHost = req.headers.get('x-forwarded-host')?.split(',')[0];
  const host = forwardedHost || req.headers.get('host') || 'localhost:3000';
  const protocol = req.headers.get('x-forwarded-proto')?.split(',')[0] || 'http';
  const base =
    process.env.NODE_ENV === 'production' && process.env.NEXT_PUBLIC_SITE_URL
      ? process.env.NEXT_PUBLIC_SITE_URL
      : `${protocol}://${host}`;
  return NextResponse.redirect(new URL(`/unsubscribe?status=${status}`, base));
}
