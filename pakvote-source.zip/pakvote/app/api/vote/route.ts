import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { getDb, getPollById, newId } from '@/lib/db';
import { GENDERS, REGIONS } from '@/lib/regions';
import { ApiError, assertSameOrigin, currentUser, deviceHash, handleApiError } from '@/lib/security';
import { getPollStatus } from '@/lib/utils';
export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req);
    const data = z
      .object({
        pollId: z.string().min(1).max(120),
        optionId: z.string().min(1).max(120),
        gender: z.enum(GENDERS),
        province: z.string().max(70),
        district: z.string().max(90),
      })
      .parse(await req.json());
    const user = await currentUser(req);
    if (!user) throw new ApiError('Please verify your email before voting.', 401);
    const device = deviceHash(req);
    if (!REGIONS[data.province]?.includes(data.district))
      throw new ApiError('Please select a valid province and district.');
    const poll = await getPollById(data.pollId);
    if (!poll || getPollStatus(poll) !== 'active')
      throw new ApiError('Voting is not open for this poll.', 403);
    if (!poll.options.some((o) => o.id === data.optionId))
      throw new ApiError('Please select a valid option.');
    const db = await getDb();
    try {
      const now = new Date().toISOString();
      const saved = await db.execute({
        sql: `INSERT INTO votes (id,poll_id,option_id,user_id,device_hash,gender,province,district,created_at)
          SELECT ?,?,?,?,?,?,?,?,? WHERE EXISTS (
            SELECT 1 FROM polls WHERE id=? AND status='published' AND starts_at<=? AND ends_at>?
          ) AND EXISTS (SELECT 1 FROM options WHERE id=? AND poll_id=?)`,
        args: [
          newId('vote'),
          poll.id,
          data.optionId,
          user.id,
          device,
          data.gender,
          data.province,
          data.district,
          now,
          poll.id,
          now,
          now,
          data.optionId,
          poll.id,
        ],
      });
      if (!saved.rowsAffected)
        throw new ApiError('This poll has closed or the option is unavailable.', 403);
    } catch (error) {
      const existing = await db.execute({
        sql: 'SELECT user_id FROM votes WHERE poll_id=? AND (user_id=? OR device_hash=?) LIMIT 1',
        args: [poll.id, user.id, device],
      });
      if (existing.rows.length)
        throw new ApiError(
          String(existing.rows[0].user_id) === user.id
            ? 'You have already voted in this poll. Every account gets one vote.'
            : 'A vote has already been cast from this browser for this poll.',
          409,
        );
      throw error;
    }
    return NextResponse.json({
      ok: true,
      message: 'Your vote was securely recorded. Thank you for participating!',
    });
  } catch (error) {
    return handleApiError(error);
  }
}
