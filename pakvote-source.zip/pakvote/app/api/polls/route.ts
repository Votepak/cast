import { NextResponse } from 'next/server';
import { getPolls, isDemoMode } from '@/lib/db';
import { handleApiError } from '@/lib/security';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export async function GET() {
  try {
    return NextResponse.json(
      { polls: await getPolls(), demo: isDemoMode() },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  } catch (error) {
    return handleApiError(error);
  }
}
