import type { Metadata } from 'next';
import { getPolls, isDemoMode } from '@/lib/db';
import { ElectionsClient } from '@/components/ElectionsClient';
export const metadata: Metadata = {
  title: 'Elections & polls',
  description:
    'Explore Pakistani public-opinion polls on parties, leadership, government tenures, and everyday priorities.',
};
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
export default async function ElectionsPage() {
  return <ElectionsClient polls={await getPolls()} demo={isDemoMode()} />;
}
