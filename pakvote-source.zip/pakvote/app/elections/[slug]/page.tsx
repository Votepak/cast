import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getPollBySlug, getResults, isDemoMode } from '@/lib/db';
import { PollDetailClient } from '@/components/PollDetailClient';
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
interface Props {
  params: Promise<{ slug: string }>;
}
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const poll = await getPollBySlug(slug);
  return {
    title: poll?.title || 'Poll not found',
    description: poll?.description || 'Explore public-opinion polls on Pakvote.',
  };
}
export default async function PollDetailPage({ params }: Props) {
  const { slug } = await params;
  const poll = await getPollBySlug(slug);
  if (!poll) notFound();
  return <PollDetailClient poll={poll} initialResults={await getResults(poll)} demo={isDemoMode()} />;
}
