import Link from 'next/link';
import { ArrowRight, CheckCircle2, CircleAlert } from 'lucide-react';
interface Props {
  searchParams: Promise<{ status?: string }>;
}
export default async function UnsubscribePage({ searchParams }: Props) {
  const { status } = await searchParams;
  const success = status === 'success';
  return (
    <div className="container page-content unsubscribe-page">
      <div>
        <span className="unsubscribe-icon">
          {success ? <CheckCircle2 size={29} /> : <CircleAlert size={29} />}
        </span>
        <h1>{success ? 'You’re unsubscribed.' : 'We couldn’t update that link.'}</h1>
        <p>
          {success
            ? 'We won’t send a final results file for that subscription. You can still explore public results at any time.'
            : 'The unsubscribe link may be invalid or expired. Please try the link in your email again.'}
        </p>
        <Link href="/results" className="button button-primary">
          View public results <ArrowRight size={16} />
        </Link>
      </div>
    </div>
  );
}
