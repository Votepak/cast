import type { MetadataRoute } from 'next';
import { getPolls } from '@/lib/db';
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = (process.env.NEXT_PUBLIC_SITE_URL || 'https://pakvote.vercel.app').replace(/\/$/, '');
  const pages = ['', '/elections', '/results', '/insights', '/about', '/privacy', '/terms'];
  const staticPages = pages.map((path) => ({
    url: `${base}${path}`,
    changeFrequency: 'daily' as const,
    priority: path ? 0.7 : 1,
  }));
  try {
    const polls = (await getPolls()).filter((poll) => poll.status !== 'draft');
    return [
      ...staticPages,
      ...polls.map((poll) => ({
        url: `${base}/elections/${poll.slug}`,
        changeFrequency: 'daily' as const,
        priority: 0.8,
      })),
    ];
  } catch {
    return staticPages;
  }
}
