'use client';
import { useEffect } from 'react';
import { AlertCircle, RotateCw } from 'lucide-react';
export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);
  return (
    <div className="container page-content not-found">
      <span>
        <AlertCircle size={29} />
      </span>
      <strong>WE HIT A SNAG</strong>
      <h1>Something went wrong.</h1>
      <p>
        We couldn’t load this page. If you’re setting up Pakvote, check the Turso environment variables
        in Vercel.
      </p>
      <button className="button button-primary" onClick={reset}>
        <RotateCw size={16} /> Try again
      </button>
    </div>
  );
}
