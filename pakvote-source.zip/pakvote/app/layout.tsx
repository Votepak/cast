import type { Metadata } from 'next';
import '@fontsource-variable/manrope/index.css';
import './globals.css';
import { AuthProvider } from '@/components/AuthProvider';
import { Header, Footer } from '@/components/SiteChrome';

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://pakvote.vercel.app'),
  title: { default: 'Pakvote — Your voice. Your vote. Your Pakistan.', template: '%s | Pakvote' },
  description:
    'Vote for your favorite party, explore live public-opinion results, and discover the voices shaping the conversation in Pakistan. Unofficial and independent.',
  icons: { icon: '/icon.svg' },
  openGraph: {
    title: 'Pakvote — Your voice matters',
    description: 'An independent public-opinion platform for Pakistan.',
    siteName: 'Pakvote',
    type: 'website',
    images: [
      {
        url: '/images/pakistan-voices.jpg',
        width: 1376,
        height: 768,
        alt: 'The voices of Pakistan on Pakvote',
      },
    ],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>
          <a className="skip-link" href="#main-content">
            Skip to main content
          </a>
          <Header />
          <main id="main-content">{children}</main>
          <Footer />
        </AuthProvider>
      </body>
    </html>
  );
}
