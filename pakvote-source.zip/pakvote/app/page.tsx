import { getPolls, getResults, isDemoMode } from '@/lib/db';
import { HomeClient } from '@/components/HomeClient';
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export default async function HomePage() {
  const polls = await getPolls();
  const featured = polls.find((p) => p.isFeatured) || polls[0] || null;
  const results = featured ? await getResults(featured) : null;
  return <HomeClient polls={polls} featured={featured} initialResults={results} demo={isDemoMode()} />;
}
