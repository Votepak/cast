import Link from 'next/link';
import { ArrowRight, Search } from 'lucide-react';
export default function NotFound() {
  return (
    <div className="container page-content not-found">
      <span>
        <Search size={29} />
      </span>
      <strong>404 / PAGE NOT FOUND</strong>
      <h1>
        We couldn’t find
        <br />
        that conversation.
      </h1>
      <p>The page may have moved or the poll isn’t public yet. There’s plenty more to explore.</p>
      <Link href="/elections" className="button button-primary">
        Explore all polls <ArrowRight size={16} />
      </Link>
    </div>
  );
}
