import type { Metadata } from 'next';
import Link from 'next/link';
import {
  ArrowRight,
  ArrowUpRight,
  CheckCircle2,
  ChevronRight,
  Eye,
  Fingerprint,
  Globe2,
  HeartHandshake,
  Info,
  LockKeyhole,
  Mail,
  ShieldCheck,
  Sparkles,
  UsersRound,
  Vote,
} from 'lucide-react';
import { developerWhatsApp } from '@/components/SiteChrome';
export const metadata: Metadata = {
  title: 'About us',
  description:
    'Learn about Pakvote’s independent, unofficial public-opinion polls, methodology and privacy approach.',
};
export default function AboutPage() {
  return (
    <div className="container page-content editorial-page">
      <div className="breadcrumbs breadcrumb-dark">
        <Link href="/">Home</Link>
        <ChevronRight size={13} /> About us
      </div>
      <section className="editorial-hero">
        <span className="eyebrow">THE IDEA BEHIND PAKVOTE</span>
        <h1>
          A place for <em>every voice.</em>
        </h1>
        <p>
          We believe people deserve a simple, transparent way to share an opinion and see how others are
          thinking — without pretending an online poll is an election.
        </p>
        <div className="editorial-hero-actions">
          <Link className="button button-primary" href="/elections">
            Explore the polls <ArrowUpRight size={16} />
          </Link>
          <Link className="button button-outline" href="/results">
            See live results <ArrowRight size={16} />
          </Link>
        </div>
      </section>
      <section className="about-intro">
        <span className="eyebrow">OUR PURPOSE</span>
        <h2>
          More conversation.
          <br />
          <span>More clarity.</span>
        </h2>
        <div>
          <p>
            Pakvote is an independent public-opinion platform made for people who want their perspectives
            to be heard. We host informal polls on political parties, public personalities, government
            tenures and issues that matter to everyday life in Pakistan.
          </p>
          <p>
            It is not operated by the Election Commission of Pakistan or any political party. Votes here
            have no effect on an official election. Because visitors choose to participate, our results
            are descriptive of participants — not a scientific sample or a prediction.
          </p>
        </div>
      </section>
      <section id="how-it-works" className="about-process">
        <div className="section-heading">
          <div>
            <span className="eyebrow">THE PROCESS</span>
            <h2>
              How it <span className="highlight-text">works.</span>
            </h2>
            <p>Clear steps, straightforward safeguards and results anyone can inspect.</p>
          </div>
        </div>
        <div className="process-grid">
          <div>
            <span className="process-num">01</span>
            <span className="process-icon">
              <Mail size={24} />
            </span>
            <h3>Verify your email</h3>
            <p>
              We send a time-limited code to confirm that the inbox is yours. There’s no public account
              profile.
            </p>
          </div>
          <div>
            <span className="process-num">02</span>
            <span className="process-icon">
              <Vote size={24} />
            </span>
            <h3>Make your choice</h3>
            <p>
              Choose one answer, then select your gender and location so we can present aggregated
              breakdowns. These fields are required to vote, but self-reported.
            </p>
          </div>
          <div>
            <span className="process-num">03</span>
            <span className="process-icon">
              <Fingerprint size={24} />
            </span>
            <h3>One account, one browser</h3>
            <p>
              A verified email and a persistent browser token can each cast only one vote per poll.
              Clearing browser storage or using a different device can weaken device checks; no website
              can reliably identify a physical device.
            </p>
          </div>
          <div>
            <span className="process-num">04</span>
            <span className="process-icon">
              <Eye size={24} />
            </span>
            <h3>See the whole picture</h3>
            <p>
              As ballots arrive, charts and counts update. We show option totals, percentages, gender,
              province, district and a participation trend — never someone’s individual ballot.
            </p>
          </div>
        </div>
      </section>
      <section className="about-values">
        <div>
          <span className="eyebrow eyebrow-light">WHAT GUIDES US</span>
          <h2>
            Built for trust,
            <br />
            <em>not theatrics.</em>
          </h2>
          <p>
            We aim to make civic conversation more accessible while being honest about what an online
            poll can and cannot show.
          </p>
        </div>
        <div className="value-list">
          <div>
            <ShieldCheck size={23} />
            <div>
              <h3>Independent by design</h3>
              <p>No political affiliation or endorsement is implied by a poll or portrait.</p>
            </div>
          </div>
          <div>
            <Globe2 size={23} />
            <div>
              <h3>Context alongside counts</h3>
              <p>Every dashboard explains that results are unweighted and self-selected.</p>
            </div>
          </div>
          <div>
            <LockKeyhole size={23} />
            <div>
              <h3>Privacy first</h3>
              <p>
                Emails are used for verification and optional results delivery, never shown in public
                charts.
              </p>
            </div>
          </div>
        </div>
      </section>
      <section className="about-disclaimer">
        <Info size={21} />
        <div>
          <h3>A necessary distinction</h3>
          <p>
            Pakvote is an unofficial opinion platform. Results are not legally valid election returns, a
            random sample, a census, or proof of public support across Pakistan. They reflect only those
            who voluntarily visited and voted.
          </p>
        </div>
      </section>
      <section className="credits-section">
        <span className="eyebrow">IMAGE ACKNOWLEDGEMENTS</span>
        <h2>The faces and the flags.</h2>
        <p>
          Our hero shows an AI-generated illustrative gathering. It is not an image of a real event.
          Public-figure portraits are shown for neutral identification only and do not imply endorsement.
        </p>
        <div>
          <a
            href="https://commons.wikimedia.org/wiki/File:Imran_Khan_-_UNGA_(48784380531)_-_cropped_enhanced.jpg"
            target="_blank"
            rel="noopener noreferrer"
          >
            Imran Khan — The White House, public domain <ArrowUpRight size={14} />
          </a>
          <a
            href="https://commons.wikimedia.org/wiki/File:Nawaz_Sharif_March_2014.jpg"
            target="_blank"
            rel="noopener noreferrer"
          >
            Nawaz Sharif — U.S. Department of State, public domain <ArrowUpRight size={14} />
          </a>
          <a
            href="https://commons.wikimedia.org/wiki/File:Bilawal_-_2022_(52577074232)_(cropped).jpg"
            target="_blank"
            rel="noopener noreferrer"
          >
            Bilawal Bhutto Zardari — Ron Przysucha / U.S. Department of State, public domain{' '}
            <ArrowUpRight size={14} />
          </a>
        </div>
      </section>
      <section id="contact" className="contact-panel">
        <div>
          <span className="eyebrow">GET IN TOUCH</span>
          <h2>Let’s talk about what’s next.</h2>
          <p>
            Want to discuss building a website or another digital project? Contact the developer directly
            on WhatsApp.
          </p>
        </div>
        <a
          href={developerWhatsApp}
          className="button button-primary"
          target="_blank"
          rel="noopener noreferrer"
        >
          Contact the developer <ArrowUpRight size={16} />
        </a>
      </section>
    </div>
  );
}
