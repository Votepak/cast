import type { Metadata } from 'next';
import Link from 'next/link';
import { ChevronRight, Info } from 'lucide-react';
export const metadata: Metadata = {
  title: 'Terms of use',
  description: 'Rules and important limitations for using Pakvote’s public-opinion polls.',
};
export default function TermsPage() {
  return (
    <div className="container page-content legal-page">
      <div className="breadcrumbs breadcrumb-dark">
        <Link href="/">Home</Link>
        <ChevronRight size={13} /> Terms of use
      </div>
      <div className="legal-head">
        <span className="eyebrow">THE GROUND RULES</span>
        <h1>
          Terms of <em>use.</em>
        </h1>
        <p>Simple rules to keep the conversation useful, fair and transparent.</p>
        <span>Last updated: September 2026</span>
      </div>
      <div className="legal-layout">
        <nav aria-label="On this page">
          <a href="#nature">Nature of the service</a>
          <a href="#participation">Participation rules</a>
          <a href="#results">Results & limitations</a>
          <a href="#availability">Availability</a>
          <a href="#rights">Content & images</a>
          <a href="#contact-terms">Contact</a>
        </nav>
        <div className="legal-content">
          <section id="nature">
            <h2>Nature of the service</h2>
            <p>
              Pakvote is an independent platform for informal online opinion polling. It is not an
              official election authority, not affiliated with the Election Commission of Pakistan and
              not a substitute for lawful voting. Politician images and poll options do not imply support
              or affiliation.
            </p>
          </section>
          <section id="participation">
            <h2>Participation rules</h2>
            <p>
              You must use an email inbox you control to participate. Each verified account and each
              persistent browser identifier may vote once in each poll. Do not use automation, multiple
              accounts or other workarounds to manipulate results. You must provide honest self-reported
              information to the best of your ability. A submitted ballot cannot be changed.
            </p>
          </section>
          <section id="results">
            <h2>What results mean</h2>
            <p>
              Results describe people who voluntarily voted here. They are not a random sample, are not
              weighted for population demographics, and are not official, predictive or legally binding.
              Percentages may differ slightly from 100% because of rounding. We may close or pause a poll
              when needed for safety or integrity.
            </p>
          </section>
          <section id="availability">
            <h2>Availability and email delivery</h2>
            <p>
              We work to keep the site available, but access and email delivery can be interrupted by
              hosting, database or third-party email providers. Results email delivery is offered on an
              opt-in basis and depends on the site administrator configuring a verified sender and
              staying within provider limits. Completed results can also be downloaded from the public
              results dashboard.
            </p>
          </section>
          <section id="rights">
            <h2>Content and imagery</h2>
            <p>
              The Pakvote name, site design and original content belong to the site operator.
              Public-domain figure portraits are credited on the <Link href="/about">About page</Link>.
              The hero artwork is an AI-generated illustration, not a photograph of an actual event.
            </p>
          </section>
          <section id="contact-terms">
            <h2>Questions</h2>
            <p>
              For privacy questions, see our <Link href="/privacy">Privacy policy</Link>. For information
              about the project, visit the <Link href="/about">About page</Link>. By using this site, you
              agree to these terms as presented.
            </p>
          </section>
          <div className="legal-end">
            <Info size={20} />
            <span>Stay curious. Read the context alongside the count.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
