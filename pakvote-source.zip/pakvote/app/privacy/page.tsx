import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowUpRight, ChevronRight, ShieldCheck } from 'lucide-react';
import { developerWhatsApp } from '@/components/SiteChrome';
export const metadata: Metadata = {
  title: 'Privacy policy',
  description:
    'Understand how Pakvote handles your email, votes, browser token and voluntary demographic information.',
};
export default function PrivacyPage() {
  return (
    <div className="container page-content legal-page">
      <div className="breadcrumbs breadcrumb-dark">
        <Link href="/">Home</Link>
        <ChevronRight size={13} /> Privacy policy
      </div>
      <div className="legal-head">
        <span className="eyebrow">YOUR DATA, EXPLAINED</span>
        <h1>
          Privacy <em>policy.</em>
        </h1>
        <p>We want it to be clear what’s recorded when you participate and what the public can see.</p>
        <span>Last updated: September 2026</span>
      </div>
      <div className="legal-layout">
        <nav aria-label="On this page">
          <a href="#data">Information collected</a>
          <a href="#use">How we use it</a>
          <a href="#public">What is public</a>
          <a href="#cookies">Cookies & devices</a>
          <a href="#emails">Results email</a>
          <a href="#security">Security & retention</a>
          <a href="#choices">Your choices</a>
        </nav>
        <div className="legal-content">
          <section id="data">
            <h2>Information we collect</h2>
            <p>
              To vote, you give us an email address, which we verify with a time-limited one-time code.
              When you cast a vote, we record your chosen poll option, self-reported gender, province or
              territory, district, the time and a pseudonymous browser-token hash. We record a user
              identifier associated with your verified email so we can enforce one vote per account per
              poll.
            </p>
            <p>
              We also keep limited, hashed request identifiers for short-term anti-abuse rate limiting.
              If you opt in to a final results email, we store your email address and subscription
              status. We do not ask for a CNIC, phone number or legal name to vote.
            </p>
          </section>
          <section id="use">
            <h2>How we use this information</h2>
            <p>
              We use your email to verify access, prevent an account from voting twice in the same poll,
              and send the final CSV results for a poll if you explicitly request them. Votes and
              voluntary demographics power live aggregate charts and public results files. Request
              identifiers help slow down automated abuse. We do not use your vote choice for targeted
              advertising.
            </p>
          </section>
          <section id="public">
            <h2>What other people can see</h2>
            <p>
              Public dashboards and downloadable results files contain only aggregate counts, shares and
              breakdowns. They do not include your email, user ID, device hash or individual voting
              history. Your account page shows that you participated, but not which option you chose.
            </p>
            <p>
              Be mindful that very small groups or districts can have low counts. The platform shows
              aggregate demographic data even when a count is small; avoid using those figures to make
              assumptions about identifiable people.
            </p>
          </section>
          <section id="cookies">
            <h2>Cookies and the one-browser limit</h2>
            <p>
              Essential HttpOnly cookies keep you signed in and hold a pseudonymous browser identifier.
              The identifier is hashed on the server before being stored with a vote. Each verified
              account and each identifier can submit one vote per poll. If someone deletes cookies, uses
              private browsing or switches devices, a public website cannot reliably prove they are using
              the same physical device. Account verification is an additional safeguard, not a guarantee
              against coordinated abuse.
            </p>
          </section>
          <section id="emails">
            <h2>Optional final results email</h2>
            <p>
              Results emails are opt-in. A completed poll’s downloadable CSV includes the final option
              totals and aggregate gender, province and district counts. Emails are sent through a
              configured email delivery provider, so your address is shared with that provider for
              delivery. A one-click unsubscribe link is included in results emails. Delivery depends on
              provider quotas and the administrator’s setup.
            </p>
          </section>
          <section id="security">
            <h2>Security and retention</h2>
            <p>
              Database access uses Turso server credentials that are not exposed to the browser. Sign-in
              codes expire after ten minutes; sessions have an expiry. We keep vote and subscription
              records for the operation and integrity of the site unless removed by an administrator in
              response to a legitimate request. No online service is perfectly secure, so avoid providing
              sensitive personal details beyond the fields requested.
            </p>
          </section>
          <section id="choices">
            <h2>Your choices and contact</h2>
            <p>
              You can choose not to vote, sign out at any time, and unsubscribe from final results
              emails. For a request about your personal data or a correction, contact the site operator
              through the developer contact route and explain your request. We may need to verify that
              the account is yours before making changes.
            </p>
            <a href={developerWhatsApp} target="_blank" rel="noopener noreferrer">
              Contact the developer <ArrowUpRight size={15} />
            </a>
          </section>
          <div className="legal-end">
            <ShieldCheck size={20} />
            <span>Thank you for trusting Pakvote with your voice.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
