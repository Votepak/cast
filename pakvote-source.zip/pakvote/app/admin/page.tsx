import type { Metadata } from 'next';
import { AdminClient } from '@/components/AdminClient';
export const metadata: Metadata = { title: 'Admin dashboard', robots: { index: false, follow: false } };
export const dynamic = 'force-dynamic';
export default function AdminPage() {
  return <AdminClient />;
}
