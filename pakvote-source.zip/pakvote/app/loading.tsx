import { LoaderCircle } from 'lucide-react';
export default function Loading() {
  return (
    <div className="container loading-page">
      <LoaderCircle size={29} className="spin" />
      <span>Loading Pakvote…</span>
    </div>
  );
}
