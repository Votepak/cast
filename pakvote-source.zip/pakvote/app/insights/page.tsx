import type { Metadata } from 'next';
import { getPolls, getResults, isDemoMode } from '@/lib/db';
import { InsightsClient } from '@/components/InsightsClient';
export const metadata: Metadata = {
  title: 'Public opinion insights',
  description:
    'Interpret the data behind Pakvote polls with regional, demographic and participation insights.',
};
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
interface Props {
  searchParams: Promise<{ poll?: string }>;
}
export default async function InsightsPage({ searchParams }: Props) {
  const { poll: slug } = await searchParams;
  const polls = (await getPolls()).filter((p) => p.status !== 'draft' || p.isFeatured);
  const poll = polls.find((p) => p.slug === slug) || polls.find((p) => p.isFeatured) || polls[0];
  if (!poll)
    return (
      <div className="container page-content">
        <div className="page-empty">
          <h1>Insights are coming soon.</h1>
          <p>The administrator can launch a poll to begin collecting responses.</p>
        </div>
      </div>
    );
  return (
    <InsightsClient
      key={poll.id}
      polls={polls}
      poll={poll}
      results={await getResults(poll)}
      demo={isDemoMode()}
    />
  );
}
