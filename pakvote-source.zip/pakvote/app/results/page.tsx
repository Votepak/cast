import type { Metadata } from 'next';
import { getPolls, getResults, isDemoMode } from '@/lib/db';
import { ResultsExplorer } from '@/components/ResultsExplorer';
export const metadata: Metadata = {
  title: 'Live results & statistics',
  description:
    'Explore live vote counts, option tables, percentages, gender, province and district breakdowns on Pakvote.',
};
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
interface Props {
  searchParams: Promise<{ poll?: string }>;
}
export default async function ResultsPage({ searchParams }: Props) {
  const { poll: slug } = await searchParams;
  const polls = (await getPolls()).filter((p) => p.status !== 'draft' || p.isFeatured);
  const poll = polls.find((p) => p.slug === slug) || polls.find((p) => p.isFeatured) || polls[0];
  if (!poll)
    return (
      <div className="container page-content">
        <div className="page-empty">
          <h1>No polls available yet.</h1>
          <p>The administrator can create an election to get started.</p>
        </div>
      </div>
    );
  return (
    <ResultsExplorer
      key={poll.id}
      polls={polls}
      poll={poll}
      initialResults={await getResults(poll)}
      demo={isDemoMode()}
    />
  );
}
