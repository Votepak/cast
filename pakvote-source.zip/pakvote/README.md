# Pakvote

A responsive, independent **Pakistani public-opinion platform** built with Next.js, Turso (libSQL), and optional Resend email delivery. It includes party elections, leadership polls, government-tenure comparisons, community surveys, a live analytics dashboard, and an administrator control center.

> **Important:** Pakvote is **not** an Election Commission of Pakistan service, an official election, or a representative survey. The demo dataset contains synthetic votes and is prominently marked as illustrative.

## Quick start — live local preview

```bash
cd pakvote
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000). **No credentials are needed for local preview** when `TURSO_DATABASE_URL` is unset: the app creates `data/pakvote-local.db`, seeds four working demonstration polls and illustrative votes, and shows the verification code inside the sign-in dialog. This preview-only behavior is disabled in production.

Local administrator credentials, **only** when no Turso URL is configured and `NODE_ENV` is not production:

```text
Email:    admin@pakvote.local
Password: DemoAdmin2026!
```

Go to `/admin` to edit poll start/end times, publish drafts, create new elections or surveys, close voting and download CSV reports. Never use these demo credentials for a public deployment.

### Useful commands

```bash
npm run lint   # TypeScript check
npm run build  # Production build
npm run start  # Production server (requires Turso and production secrets)
```

## What is included

- **Public pages:** homepage, all polls, individual ballot, live results, insights, about/methodology, account, privacy, terms, unsubscribe, and a friendly 404.
- **Party options, exactly as requested:** Pakistan People's Party; Pakistan Muslim League (N); Pakistan Tehreek e Insaf; OTHERS; I don't Vote.
- **Vote integrity:** email one-time-code verification; one database vote per verified account **and** per persistent browser token, per poll, enforced with unique database constraints. Ballots can be cast only during the administrator-configured open window.
- **Live, incremental results:** overall votes; currently leading / final winning option; counts and percentages; graphs by gender (Male/Female/Other), province/territory, district, daily trend; filterable breakdowns and a separate vote-counting table.
- **Poll administration:** drafts, publishing, scheduling, early close, featured poll, new elections, personality polls, tenure comparisons and surveys. Choice text and poll type lock once ballots exist. Admin CSV export works at any time; public CSV download unlocks after a poll ends.
- **Results file via email:** people explicitly opt in with their verified address. A daily Vercel cron or administrator action sends individual results emails with an attached CSV after completion, when Resend is configured.
- **Sharing:** WhatsApp, Facebook and X web share links; Instagram, TikTok and More use the device's native share sheet when available and otherwise copy a link with clear feedback (those platforms do **not** offer general-purpose website share URLs).
- **Presentation:** generated, clearly disclosed civic hero artwork; public-domain politician portraits; Pakistan flags; responsive mobile navigation; multiple reserved advertisement placements; professional footer and prefilled WhatsApp developer contact.

## Deploy to Vercel + Turso

A Vercel Hobby deployment can run the web app, but **you must provide your own Turso database and an email provider**. The free Vercel subdomain is available only if the project name is free. A custom registered domain, if wanted, may cost money.

### 1. Create the `pakvote` database on Turso

Install/authenticate the [Turso CLI](https://docs.turso.tech/cli/introduction), then run:

```bash
turso db create pakvote
turso db show pakvote --url
turso db tokens create pakvote
```

Save the `libsql://...` URL and generated token securely. The schema and four **draft** starter polls are created automatically when the production app first accesses the database. **Production is not preloaded with fake ballots.** Use `/admin` to choose an opening time, closing time and `Publish · Scheduled` status before votes are accepted.

### 2. Set up results and verification emails

Set up a verified sending domain with [Resend](https://resend.com/). Get an API key and a sender address such as `Pakvote <results@your-verified-domain.com>`. A test-only sender cannot deliver to arbitrary public users; real verification and results emails require a verified sending domain. Email provider limits apply, including on free plans.

### 3. Configure the Vercel project

Import this folder as a Next.js project in [Vercel](https://vercel.com/). If the repository contains the enclosing workspace, set its **Root Directory** to `pakvote`. A project named `pakvote` will generally receive `pakvote.vercel.app` **only if available**; use the actual assigned URL in `NEXT_PUBLIC_SITE_URL`. The bare word `pakvote` is not a complete internet domain; to use, for example, `pakvote.pk`, register it and set up Vercel DNS separately.

Copy `.env.example` into Vercel **Environment Variables**, substituting real values:

| Variable | Purpose |
| --- | --- |
| `TURSO_DATABASE_URL` | Turso `libsql://...` database URL for `pakvote` |
| `TURSO_AUTH_TOKEN` | Turso database access token |
| `SESSION_SECRET` | Independent random string of at least 24 characters |
| `DEVICE_SECRET` | A **different** random string of at least 24 characters |
| `OTP_SECRET` | A **third** random string of at least 24 characters |
| `ADMIN_EMAIL` | Your own administrator email |
| `ADMIN_PASSWORD` | Strong, unique admin password of at least 16 characters |
| `RESEND_API_KEY` | Email provider key for verification and final files |
| `EMAIL_FROM` | Sender on a verified Resend domain |
| `NEXT_PUBLIC_SITE_URL` | Complete deployed origin, e.g. `https://pakvote.vercel.app` |
| `CRON_SECRET` | Another independent, long random value for the Vercel cron |

Generate independent secrets with `openssl rand -hex 32`. **Never commit real secrets.** No secret belongs in a `NEXT_PUBLIC_` variable except the non-sensitive public site URL.

Deploy with the default Next.js build settings. `vercel.json` configures a daily cron at **08:00 UTC / 13:00 PKT**. A run sends up to **40** pending final-result emails, individually and rate-limited. The administrator can use **Send due results now** to process more in batches when provider quotas allow. Delivery is after the poll ends, **not guaranteed to be immediate**; delivery time depends on cron timing, email service and free-tier quotas. The final CSV is also available to the public on the poll's results page once voting ends.

### 4. Open the poll

1. Sign in at `/admin` with the production administrator credentials.
2. Edit the featured party poll (or create a new one).
3. Set the start/end with the date-time fields; they use the **administrator's browser timezone**. Public dates are shown in **Pakistan Standard Time**.
4. Set status to **Publish · Scheduled** and save. The countdown and open/close behavior use server-side timestamps. After the end time, votes stop and final CSV download becomes available.

## Technical design and safeguards

- Route handlers use server-side Turso queries; ballots cannot be inserted by client-side counter manipulation. Vote insertion checks poll timing and valid option again **at insert time**.
- SQLite unique indexes guard `(poll_id, user_id)` and `(poll_id, device_hash)` against duplicate and concurrent submissions.
- Login codes expire after 10 minutes and have five attempts. Login and admin requests have server-backed rate limits. Admin and account sessions use random, database-hashed tokens in `HttpOnly`, `SameSite=Lax`, production `Secure` cookies. API writes check same-origin requests.
- Email addresses and device tokens are never included in the public aggregate API, charts or CSV file. Subscriptions require the signed-in email and explicit consent; emailed files contain an unsubscribe link.
- If a results email fails, its database claim is released for retry on the next cron/admin run. Email work is throttled and capped per run so it fits typical serverless limits.
- Public figures are shown for identification only; the site does not claim affiliation or endorse any option. See `ASSET_CREDITS.md`.

### Honest limitations

No ordinary website can guarantee **one vote per physical device**: cookies can be deleted, browsers or devices switched, and people can verify multiple inboxes. Pakvote enforces one ballot per **verified account and persistent browser token per poll**, not biometric/physical-device identity. Consider dedicated identity verification, abuse monitoring and an external audit before using this for a high-stakes vote. Similarly, these voluntary, unweighted online polls do not represent national election outcomes.

District choices are curated and include an “Other / not listed” fallback. Administrators should review official administrative changes periodically. Reserved ad placements are visual placeholders; an ad network is **not** connected. A free Vercel account does not include domain registration, Turso or Resend provisioning.

## Image sources

See [`ASSET_CREDITS.md`](./ASSET_CREDITS.md) for public-domain portrait attribution and a note about the generated hero illustration. Image assets are stored locally under `public/images`, so the site does not rely on external image hotlinking.

## Folder map

```text
app/                    Next.js pages, metadata and HTTP API routes
components/             Voting UI, charts, sharing, admin and layouts
lib/db.ts               Turso/libSQL schema, seed data and aggregate queries
lib/security.ts         Sessions, admin checks, device hashing and rate limits
lib/notifications.ts    Final-results CSV email delivery
lib/regions.ts          Province / territory and district choices
public/images/          Hero image and credited politician portraits
vercel.json             Daily email-delivery cron schedule
.env.example            Required production environment variables
```

© 2026 **pakvote**. Built to make space for the conversation, not to replace an official election.
