import 'server-only';
import { getDb, getPolls, getResults, isDemoMode } from './db';
import { buildResultsCsv } from './csv';
import { emailShell, escapeHtml, sendEmail } from './mailer';
import { ApiError, token } from './security';
import { getPollStatus } from './utils';

export async function sendDueResults(limit = 40) {
  if (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM) {
    if (isDemoMode())
      throw new ApiError(
        'To send real results emails, add RESEND_API_KEY and EMAIL_FROM to your environment.',
        503,
      );
    throw new ApiError('Email delivery is not configured.', 503);
  }
  const db = await getDb();
  const completed = (await getPolls(true)).filter(
    (p) => p.status !== 'draft' && getPollStatus(p) === 'ended',
  );
  let sent = 0;
  let failed = 0;
  let processed = 0;
  for (const poll of completed) {
    if (processed >= limit) break;
    const pending = await db.execute({
      sql: `SELECT id,email,unsubscribe_token FROM subscriptions WHERE poll_id=?
        AND sent_at IS NULL AND unsubscribed_at IS NULL
        AND (sending_at IS NULL OR sending_at<?) ORDER BY created_at LIMIT ?`,
      args: [poll.id, new Date(Date.now() - 10 * 60000).toISOString(), limit - processed],
    });
    if (!pending.rows.length) continue;
    const csv = buildResultsCsv(poll, await getResults(poll));
    const origin = (
      process.env.NEXT_PUBLIC_SITE_URL ||
      (process.env.VERCEL_URL && `https://${process.env.VERCEL_URL}`) ||
      'http://localhost:3000'
    ).replace(/\/$/, '');
    for (const row of pending.rows) {
      const id = String(row.id);
      const email = String(row.email);
      const claim = token();
      const claimed = await db.execute({
        sql: `UPDATE subscriptions SET sending_at=?,claim_token=? WHERE id=? AND sent_at IS NULL
          AND unsubscribed_at IS NULL AND (sending_at IS NULL OR sending_at<?)`,
        args: [new Date().toISOString(), claim, id, new Date(Date.now() - 10 * 60000).toISOString()],
      });
      if (!claimed.rowsAffected) continue;
      processed++;
      const unsub = `${origin}/api/unsubscribe?token=${encodeURIComponent(String(row.unsubscribe_token))}`;
      try {
        await sendEmail({
          to: email,
          subject: `Your Pakvote results file: ${poll.title}`,
          html: emailShell(
            `<h1 style="font-size:23px;margin:0 0 14px">The results are in.</h1><p>The public-opinion poll <strong>${escapeHtml(poll.title)}</strong> has ended. Your results CSV is attached with vote totals and breakdowns by gender, province and district.</p><p>These are voluntary responses and are <strong>not</strong> official election results or a representative sample.</p><p><a href="${escapeHtml(origin + '/results?poll=' + encodeURIComponent(poll.slug))}" style="color:#0c9168">Explore the interactive dashboard</a></p><p style="font-size:12px;color:#70867b">You requested this one-time results email. <a href="${escapeHtml(unsub)}">Unsubscribe</a>.</p>`,
          ),
          text: `The poll "${poll.title}" has ended. Your results CSV is attached. These are voluntary, unofficial online opinions, not official results. Explore: ${origin}/results?poll=${encodeURIComponent(poll.slug)} . Unsubscribe: ${unsub}`,
          attachment: {
            filename: `pakvote-${poll.slug}-results.csv`,
            content: Buffer.from(csv, 'utf8').toString('base64'),
          },
        });
        await db.execute({
          sql: 'UPDATE subscriptions SET sent_at=?,sending_at=NULL,claim_token=NULL WHERE id=? AND claim_token=?',
          args: [new Date().toISOString(), id, claim],
        });
        sent++;
      } catch (error) {
        console.error('[pakvote] results delivery failed:', email, error);
        await db.execute({
          sql: 'UPDATE subscriptions SET sending_at=NULL,claim_token=NULL WHERE id=? AND claim_token=?',
          args: [id, claim],
        });
        failed++;
      }
      // The default transactional email rate limit is low; avoid 429 bursts.
      await new Promise((resolve) => setTimeout(resolve, 600));
    }
  }
  await db.execute({
    sql: 'DELETE FROM auth_events WHERE created_at<?',
    args: [new Date(Date.now() - 7 * 86400000).toISOString()],
  });
  return { sent, failed, processed, completedPolls: completed.length, batchLimit: limit };
}
