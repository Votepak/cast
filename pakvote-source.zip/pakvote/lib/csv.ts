import 'server-only';
import type { Poll, PollResults } from './types';
import { getPollStatus } from './utils';

function cell(value: string | number) {
  let safe = String(value);
  // Prevent CSV formula injection in administrator-provided poll titles and labels.
  if (/^[=+\-@\t\r]/.test(safe)) safe = `'${safe}`;
  return `"${safe.replace(/"/g, '""')}"`;
}
function row(...parts: (string | number)[]) {
  return parts.map(cell).join(',');
}

export function buildResultsCsv(poll: Poll, results: PollResults) {
  const rows = [
    row('PAKVOTE - PUBLIC OPINION RESULTS'),
    row('Poll', poll.title),
    row('Question', poll.question),
    row('Type', poll.kind),
    row('Status', getPollStatus(poll)),
    row('Voting opened (UTC)', poll.startsAt),
    row('Voting closes (UTC)', poll.endsAt),
    row('Report generated (UTC)', new Date().toISOString()),
    row('Total votes', results.totalVotes),
    row(
      'Methodology',
      'Voluntary, self-selected online opinions. Not a representative or official election result.',
    ),
    '',
    row('OPTION TOTALS'),
    row('Option', 'Votes', 'Percentage'),
    ...results.options.map((o) => row(o.label, o.votes, `${o.percentage}%`)),
    '',
    row('BY GENDER'),
    row('Gender', 'Option', 'Votes'),
    ...results.gender.flatMap((group) =>
      group.options.map((o) =>
        row(group.name, poll.options.find((p) => p.id === o.optionId)?.label || o.optionId, o.votes),
      ),
    ),
    '',
    row('BY PROVINCE / TERRITORY'),
    row('Province / territory', 'Option', 'Votes'),
    ...results.provinces.flatMap((group) =>
      group.options.map((o) =>
        row(group.name, poll.options.find((p) => p.id === o.optionId)?.label || o.optionId, o.votes),
      ),
    ),
    '',
    row('BY DISTRICT'),
    row('District', 'Option', 'Votes'),
    ...results.districts.flatMap((group) =>
      group.options.map((o) =>
        row(group.name, poll.options.find((p) => p.id === o.optionId)?.label || o.optionId, o.votes),
      ),
    ),
  ];
  return '\ufeff' + rows.join('\r\n') + '\r\n';
}
