import 'server-only';
import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';
import { getDb, isDemoMode } from './db';
import type { PublicUser } from './types';

const SESSION_COOKIE = 'pv_session';
const DEVICE_COOKIE = 'pv_device';
const ADMIN_COOKIE = 'pv_admin';
const DAYS_30 = 30 * 24 * 60 * 60;

export function secret(name: 'SESSION_SECRET' | 'DEVICE_SECRET' | 'OTP_SECRET') {
  const value = process.env[name];
  if (value && value.length >= 24) return value;
  if (isDemoMode()) return `local-demo-only-${name}-do-not-use-in-production-2026`;
  throw new Error(`${name} must be configured with a long random value in production.`);
}

export function digest(value: string) {
  return createHash('sha256').update(value).digest('hex');
}
export function hmac(value: string, key: string) {
  return createHmac('sha256', key).update(value).digest('hex');
}
function sessionDigest(value: string) {
  return hmac(value, secret('SESSION_SECRET'));
}
export function token() {
  return randomBytes(32).toString('hex');
}
export function isEqual(a: string, b: string) {
  const left = Buffer.from(digest(a), 'hex');
  const right = Buffer.from(digest(b), 'hex');
  return timingSafeEqual(left, right);
}

export function assertSameOrigin(req: NextRequest) {
  const origin = req.headers.get('origin');
  const target = req.headers.get('x-forwarded-host') || req.headers.get('host');
  if (origin && target && new URL(origin).host !== target)
    throw new ApiError('Cross-origin request blocked.', 403);
  if (!origin && req.headers.get('sec-fetch-site') === 'cross-site')
    throw new ApiError('Cross-site request blocked.', 403);
}

export class ApiError extends Error {
  constructor(
    message: string,
    public status = 400,
  ) {
    super(message);
  }
}

export function handleApiError(error: unknown) {
  if (error instanceof ApiError)
    return NextResponse.json({ error: error.message }, { status: error.status });
  if (error instanceof Error && error.name === 'ZodError')
    return NextResponse.json({ error: 'Please check the information you entered.' }, { status: 400 });
  console.error('[pakvote]', error);
  return NextResponse.json(
    { error: 'Something went wrong. Please try again shortly.' },
    { status: 500 },
  );
}

function setCookie(response: NextResponse, name: string, value: string, maxAge: number) {
  response.cookies.set(name, value, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge,
  });
}

export async function startUserSession(userId: string, req: NextRequest, response: NextResponse) {
  const db = await getDb();
  const value = token();
  await db.execute({
    sql: 'INSERT INTO sessions (token_hash,user_id,expires_at) VALUES (?,?,?)',
    args: [sessionDigest(value), userId, new Date(Date.now() + DAYS_30 * 1000).toISOString()],
  });
  setCookie(response, SESSION_COOKIE, value, DAYS_30);
  // The same device cookie survives sign-outs, so signing in with another account
  // cannot obtain an additional vote in the same browser for this poll.
  if (!req.cookies.get(DEVICE_COOKIE)?.value)
    setCookie(response, DEVICE_COOKIE, token(), 365 * 24 * 60 * 60);
}

export async function currentUser(req: NextRequest): Promise<PublicUser | null> {
  const value = req.cookies.get(SESSION_COOKIE)?.value;
  if (!value || !/^[a-f0-9]{64}$/.test(value)) return null;
  const db = await getDb();
  const row = (
    await db.execute({
      sql: `SELECT u.* FROM users u JOIN sessions s ON s.user_id=u.id
      WHERE s.token_hash=? AND s.expires_at>? LIMIT 1`,
      args: [sessionDigest(value), new Date().toISOString()],
    })
  ).rows[0];
  if (!row) return null;
  const [votes, subscriptions] = await db.batch(
    [
      { sql: 'SELECT poll_id FROM votes WHERE user_id=?', args: [String(row.id)] },
      {
        sql: 'SELECT poll_id FROM subscriptions WHERE email=? AND unsubscribed_at IS NULL',
        args: [String(row.email)],
      },
    ],
    'read',
  );
  return {
    id: String(row.id),
    email: String(row.email),
    createdAt: String(row.created_at),
    votedPollIds: votes.rows.map((v) => String(v.poll_id)),
    subscribedPollIds: subscriptions.rows.map((s) => String(s.poll_id)),
  };
}

export async function signOutUser(req: NextRequest, response: NextResponse) {
  const value = req.cookies.get(SESSION_COOKIE)?.value;
  if (value) {
    await (
      await getDb()
    ).execute({
      sql: 'DELETE FROM sessions WHERE token_hash=?',
      args: [sessionDigest(value)],
    });
  }
  response.cookies.set(SESSION_COOKIE, '', { maxAge: 0, path: '/' });
}

export function deviceHash(req: NextRequest) {
  const value = req.cookies.get(DEVICE_COOKIE)?.value;
  if (!value || !/^[a-f0-9]{64}$/.test(value))
    throw new ApiError(
      'Your device session is missing. Please sign out and verify your email again.',
      401,
    );
  return hmac(value, secret('DEVICE_SECRET'));
}

export function adminCredentials() {
  if (isDemoMode())
    return {
      email: process.env.ADMIN_EMAIL || 'admin@pakvote.local',
      password: process.env.ADMIN_PASSWORD || 'DemoAdmin2026!',
    };
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password || password.length < 16)
    throw new ApiError('Admin credentials are not configured.', 503);
  return { email, password };
}

export async function startAdminSession(response: NextResponse) {
  const db = await getDb();
  const value = token();
  await db.execute({
    sql: 'INSERT INTO admin_sessions (token_hash,expires_at) VALUES (?,?)',
    args: [sessionDigest(value), new Date(Date.now() + 12 * 3600000).toISOString()],
  });
  setCookie(response, ADMIN_COOKIE, value, 12 * 3600);
}

export async function isAdmin(req: NextRequest) {
  const value = req.cookies.get(ADMIN_COOKIE)?.value;
  if (!value || !/^[a-f0-9]{64}$/.test(value)) return false;
  const db = await getDb();
  const found = await db.execute({
    sql: 'SELECT 1 FROM admin_sessions WHERE token_hash=? AND expires_at>? LIMIT 1',
    args: [sessionDigest(value), new Date().toISOString()],
  });
  return found.rows.length > 0;
}

export async function requireAdmin(req: NextRequest) {
  if (!(await isAdmin(req))) throw new ApiError('Admin sign-in required.', 401);
}

export async function signOutAdmin(req: NextRequest, response: NextResponse) {
  const value = req.cookies.get(ADMIN_COOKIE)?.value;
  if (value)
    await (
      await getDb()
    ).execute({ sql: 'DELETE FROM admin_sessions WHERE token_hash=?', args: [sessionDigest(value)] });
  response.cookies.set(ADMIN_COOKIE, '', { maxAge: 0, path: '/' });
}

export async function rateLimit(subject: string, limit: number, minutes: number) {
  const db = await getDb();
  const key = hmac(subject, secret('OTP_SECRET'));
  const result = await db.execute({
    sql: 'SELECT COUNT(*) AS n FROM auth_events WHERE subject=? AND created_at>?',
    args: [key, new Date(Date.now() - minutes * 60000).toISOString()],
  });
  if (Number(result.rows[0]?.n || 0) >= limit)
    throw new ApiError('Too many attempts. Please wait and try again.', 429);
  await db.execute({
    sql: 'INSERT INTO auth_events(id,subject,created_at) VALUES (?,?,?)',
    args: [token(), key, new Date().toISOString()],
  });
}

export function clientIp(req: NextRequest) {
  // Only used for approximate throttling; email and OTP verification are authoritative.
  return (req.headers.get('x-forwarded-for') || '').split(',')[0].trim().slice(0, 80) || 'unknown';
}
