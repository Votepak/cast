import 'server-only';
import { createClient, type Client } from '@libsql/client';
import { mkdirSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { SEED_POLLS } from './seed';
import { REGIONS } from './regions';
import type { BreakdownRow, Poll, PollOption, PollResults } from './types';

export const isDemoMode = () => process.env.NODE_ENV !== 'production' && !process.env.TURSO_DATABASE_URL;

let instance: Client | undefined;
let initialization: Promise<Client> | undefined;

const schema = [
  `CREATE TABLE IF NOT EXISTS polls (
    id TEXT PRIMARY KEY, slug TEXT NOT NULL UNIQUE, title TEXT NOT NULL,
    question TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL, starts_at TEXT NOT NULL, ends_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft', is_featured INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS options (
    id TEXT PRIMARY KEY, poll_id TEXT NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
    label TEXT NOT NULL, short_label TEXT NOT NULL, color TEXT NOT NULL, position INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL,
    verified_at TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS auth_codes (
    email TEXT PRIMARY KEY, code_hash TEXT NOT NULL, expires_at TEXT NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS auth_events (
    id TEXT PRIMARY KEY, subject TEXT NOT NULL, created_at TEXT NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS idx_auth_events_subject ON auth_events(subject, created_at)`,
  `CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), expires_at TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS admin_sessions (
    token_hash TEXT PRIMARY KEY, expires_at TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS votes (
    id TEXT PRIMARY KEY, poll_id TEXT NOT NULL REFERENCES polls(id),
    option_id TEXT NOT NULL REFERENCES options(id), user_id TEXT NOT NULL REFERENCES users(id),
    device_hash TEXT NOT NULL, gender TEXT NOT NULL, province TEXT NOT NULL,
    district TEXT NOT NULL, created_at TEXT NOT NULL,
    UNIQUE (poll_id, user_id), UNIQUE (poll_id, device_hash)
  )`,
  `CREATE INDEX IF NOT EXISTS idx_votes_poll_time ON votes(poll_id, created_at)`,
  `CREATE INDEX IF NOT EXISTS idx_votes_poll_region ON votes(poll_id, province, district)`,
  `CREATE TABLE IF NOT EXISTS subscriptions (
    id TEXT PRIMARY KEY, poll_id TEXT NOT NULL REFERENCES polls(id),
    email TEXT NOT NULL, unsubscribe_token TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL, sent_at TEXT, unsubscribed_at TEXT,
    sending_at TEXT, claim_token TEXT,
    UNIQUE (poll_id, email)
  )`,
  `CREATE INDEX IF NOT EXISTS idx_subscriptions_queue ON subscriptions(poll_id, sent_at, unsubscribed_at)`,
];

async function seedPolls(db: Client) {
  const result = await db.execute('SELECT COUNT(*) AS n FROM polls');
  if (Number(result.rows[0]?.n) !== 0) return;
  const now = Date.now();
  const demo = isDemoMode();
  const statements: { sql: string; args: (string | number)[] }[] = [];
  SEED_POLLS.forEach((poll, index) => {
    const startsAt = new Date(now + (demo ? -8 : 1) * 86400000).toISOString();
    const endsAt = new Date(now + (demo ? 9 : 15) * 86400000).toISOString();
    statements.push({
      sql: `INSERT OR IGNORE INTO polls (id,slug,title,question,description,kind,starts_at,ends_at,status,is_featured,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
      args: [
        poll.id,
        poll.slug,
        poll.title,
        poll.question,
        poll.description,
        poll.kind,
        startsAt,
        endsAt,
        demo ? 'published' : 'draft',
        index === 0 ? 1 : 0,
        new Date(now).toISOString(),
        new Date(now).toISOString(),
      ],
    });
    poll.options.forEach((option, position) =>
      statements.push({
        sql: `INSERT OR IGNORE INTO options (id,poll_id,label,short_label,color,position) VALUES (?,?,?,?,?,?)`,
        args: [
          `${poll.id}-option-${position}`,
          poll.id,
          option.label,
          option.shortLabel,
          option.color,
          position,
        ],
      }),
    );
  });
  await db.batch(statements, 'write');
  if (demo) await seedDemoVotes(db, now);
}

function seededRandom(seed = 69321) {
  let state = seed;
  return () => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    return (state >>> 0) / 4294967296;
  };
}

async function seedDemoVotes(db: Client, now: number) {
  const existing = await db.execute("SELECT COUNT(*) AS n FROM votes WHERE id LIKE 'demo-%'");
  if (Number(existing.rows[0]?.n) > 0) return;
  const random = seededRandom();
  const regions = Object.entries(REGIONS);
  const weightedRegions = [0, 0, 0, 0, 0, 1, 1, 1, 2, 2, 3, 4, 5, 6];
  for (const poll of SEED_POLLS) {
    const users: (string | number)[][] = [];
    const votes: (string | number)[][] = [];
    for (let i = 0; i < poll.votes; i++) {
      const id = `${poll.id}-demo-${i}`;
      const regionIndex = weightedRegions[Math.floor(random() * weightedRegions.length)];
      const [province, districts] = regions[regionIndex];
      const usableDistricts = districts.filter((d) => d !== 'Other / not listed');
      const district = usableDistricts[Math.floor(random() * usableDistricts.length)];
      const genderRoll = random();
      const gender = genderRoll < 0.51 ? 'Male' : genderRoll < 0.95 ? 'Female' : 'Other';
      let roll = random();
      let selected = 0;
      for (let o = 0; o < poll.weights.length; o++) {
        roll -= poll.weights[o];
        if (roll <= 0) {
          selected = o;
          break;
        }
      }
      const at = new Date(now - random() * 7.5 * 86400000).toISOString();
      users.push([id, `sample-${id}@example.invalid`, at, at]);
      votes.push([
        `demo-${id}`,
        poll.id,
        `${poll.id}-option-${selected}`,
        id,
        `demo-device-${id}`,
        gender,
        province,
        district,
        at,
      ]);
    }
    // Batched multi-row inserts keep the local preview fast while remaining illustrative only.
    for (let i = 0; i < users.length; i += 65) {
      const chunk = users.slice(i, i + 65);
      await db.execute({
        sql: `INSERT OR IGNORE INTO users (id,email,created_at,verified_at) VALUES ${chunk.map(() => '(?,?,?,?)').join(',')}`,
        args: chunk.flat(),
      });
    }
    for (let i = 0; i < votes.length; i += 65) {
      const chunk = votes.slice(i, i + 65);
      await db.execute({
        sql: `INSERT OR IGNORE INTO votes (id,poll_id,option_id,user_id,device_hash,gender,province,district,created_at)
          VALUES ${chunk.map(() => '(?,?,?,?,?,?,?,?,?)').join(',')}`,
        args: chunk.flat(),
      });
    }
  }
}

export async function getDb(): Promise<Client> {
  if (initialization) return initialization;
  initialization = (async () => {
    if (!instance) {
      if (isDemoMode()) mkdirSync('data', { recursive: true });
      const url = process.env.TURSO_DATABASE_URL || (isDemoMode() ? 'file:data/pakvote-local.db' : '');
      if (!url) throw new Error('Turso is not configured. Set TURSO_DATABASE_URL and TURSO_AUTH_TOKEN.');
      if (!isDemoMode() && !process.env.TURSO_AUTH_TOKEN && url.startsWith('libsql://')) {
        throw new Error('TURSO_AUTH_TOKEN is required for a remote Turso database.');
      }
      instance = createClient({ url, authToken: process.env.TURSO_AUTH_TOKEN });
    }
    await instance.batch(
      schema.map((sql) => ({ sql, args: [] })),
      'write',
    );
    await seedPolls(instance);
    return instance;
  })().catch((error) => {
    initialization = undefined;
    throw error;
  });
  return initialization;
}

function toOption(row: Record<string, unknown>): PollOption {
  return {
    id: String(row.id),
    pollId: String(row.poll_id),
    label: String(row.label),
    shortLabel: String(row.short_label),
    color: String(row.color),
    position: Number(row.position),
  };
}

function toPoll(row: Record<string, unknown>, options: PollOption[]): Poll {
  return {
    id: String(row.id),
    slug: String(row.slug),
    title: String(row.title),
    question: String(row.question),
    description: String(row.description),
    kind: String(row.kind) as Poll['kind'],
    startsAt: String(row.starts_at),
    endsAt: String(row.ends_at),
    status: String(row.status) as Poll['status'],
    isFeatured: Boolean(row.is_featured),
    createdAt: String(row.created_at),
    options,
    totalVotes: Number(row.total_votes || 0),
    subscriberCount: Number(row.subscriber_count || 0),
  };
}

export async function getPolls(includeDraft = false): Promise<Poll[]> {
  const db = await getDb();
  const [pollRows, optionRows] = await db.batch(
    [
      {
        sql: `SELECT p.*, (SELECT COUNT(*) FROM votes v WHERE v.poll_id=p.id) AS total_votes,
        (SELECT COUNT(*) FROM subscriptions s WHERE s.poll_id=p.id AND s.unsubscribed_at IS NULL) AS subscriber_count
        FROM polls p ${includeDraft ? '' : 'WHERE p.status != ? OR p.is_featured = 1'}
        ORDER BY p.is_featured DESC, p.created_at DESC`,
        args: includeDraft ? [] : ['draft'],
      },
      { sql: 'SELECT * FROM options ORDER BY position ASC', args: [] },
    ],
    'read',
  );
  const options = optionRows.rows.map((r) => toOption(r));
  return pollRows.rows.map((row) =>
    toPoll(
      row,
      options.filter((option) => option.pollId === String(row.id)),
    ),
  );
}

export async function getPollBySlug(slug: string, includeDraft = false): Promise<Poll | null> {
  const db = await getDb();
  const row = (
    await db.execute({
      sql: `SELECT p.*, (SELECT COUNT(*) FROM votes WHERE poll_id=p.id) AS total_votes
      FROM polls p WHERE p.slug=? ${includeDraft ? '' : "AND (p.status!='draft' OR p.is_featured=1)"} LIMIT 1`,
      args: [slug],
    })
  ).rows[0];
  if (!row) return null;
  const options = (
    await db.execute({
      sql: 'SELECT * FROM options WHERE poll_id=? ORDER BY position',
      args: [String(row.id)],
    })
  ).rows;
  return toPoll(
    row,
    options.map((r) => toOption(r)),
  );
}

export async function getPollById(id: string): Promise<Poll | null> {
  const db = await getDb();
  const row = (
    await db.execute({
      sql: 'SELECT p.*, (SELECT COUNT(*) FROM votes WHERE poll_id=p.id) AS total_votes FROM polls p WHERE p.id=? LIMIT 1',
      args: [id],
    })
  ).rows[0];
  if (!row) return null;
  const options = (
    await db.execute({ sql: 'SELECT * FROM options WHERE poll_id=? ORDER BY position', args: [id] })
  ).rows;
  return toPoll(
    row,
    options.map((r) => toOption(r)),
  );
}

export interface ResultFilter {
  gender?: string;
  province?: string;
  district?: string;
}

export async function getResults(poll: Poll, filter: ResultFilter = {}): Promise<PollResults> {
  const db = await getDb();
  const clauses = ['poll_id=?'];
  const args: string[] = [poll.id];
  if (filter.gender) {
    clauses.push('gender=?');
    args.push(filter.gender);
  }
  if (filter.province) {
    clauses.push('province=?');
    args.push(filter.province);
  }
  if (filter.district) {
    clauses.push('district=?');
    args.push(filter.district);
  }
  const where = clauses.join(' AND ');
  const results = await db.batch(
    [
      { sql: 'SELECT COUNT(*) AS n FROM votes WHERE poll_id=?', args: [poll.id] },
      { sql: `SELECT option_id,COUNT(*) AS n FROM votes WHERE ${where} GROUP BY option_id`, args },
      {
        sql: `SELECT gender AS name,option_id,COUNT(*) AS n FROM votes WHERE ${where} GROUP BY gender,option_id`,
        args,
      },
      {
        sql: `SELECT province AS name,option_id,COUNT(*) AS n FROM votes WHERE ${where} GROUP BY province,option_id`,
        args,
      },
      {
        sql: `SELECT district AS name,option_id,COUNT(*) AS n FROM votes WHERE ${where} GROUP BY district,option_id`,
        args,
      },
      {
        sql: `SELECT substr(created_at,1,10) AS date,COUNT(*) AS n FROM votes WHERE ${where} AND created_at>=? GROUP BY substr(created_at,1,10) ORDER BY date`,
        args: [...args, new Date(Date.now() - 13 * 86400000).toISOString()],
      },
    ],
    'read',
  );
  const counts = new Map(results[1].rows.map((row) => [String(row.option_id), Number(row.n)]));
  const filteredVotes = [...counts.values()].reduce((sum, count) => sum + count, 0);
  const options = poll.options.map((option) => ({
    ...option,
    votes: counts.get(option.id) || 0,
    percentage: filteredVotes
      ? Math.round(((counts.get(option.id) || 0) / filteredVotes) * 1000) / 10
      : 0,
  }));
  const ranked = [...options].sort((a, b) => b.votes - a.votes);
  const convertRows = (rows: (typeof results)[2]['rows']): BreakdownRow[] => {
    const groups = new Map<string, BreakdownRow>();
    for (const row of rows) {
      const name = String(row.name);
      if (!groups.has(name)) groups.set(name, { name, total: 0, options: [] });
      const group = groups.get(name)!;
      group.total += Number(row.n);
      group.options.push({ optionId: String(row.option_id), votes: Number(row.n) });
    }
    return [...groups.values()].sort((a, b) => b.total - a.total);
  };
  return {
    pollId: poll.id,
    totalVotes: Number(results[0].rows[0]?.n || 0),
    filteredVotes,
    options,
    leader: filteredVotes ? ranked[0] : null,
    isTie: filteredVotes > 0 && ranked.length > 1 && ranked[0].votes === ranked[1].votes,
    gender: convertRows(results[2].rows),
    provinces: convertRows(results[3].rows),
    districts: convertRows(results[4].rows),
    daily: results[5].rows.map((row) => ({ date: String(row.date), votes: Number(row.n) })),
    filter: {
      gender: filter.gender || '',
      province: filter.province || '',
      district: filter.district || '',
    },
    updatedAt: new Date().toISOString(),
  };
}

export function newId(prefix: string) {
  return `${prefix}-${randomUUID()}`;
}
