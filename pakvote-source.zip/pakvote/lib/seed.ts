import type { PollKind } from './types';

export interface SeedPoll {
  id: string;
  slug: string;
  title: string;
  question: string;
  description: string;
  kind: PollKind;
  options: { label: string; shortLabel: string; color: string }[];
  votes: number;
  weights: number[];
}

export const SEED_POLLS: SeedPoll[] = [
  {
    id: 'poll-pakistan-party',
    slug: 'vote-for-your-favorite-party',
    title: 'Vote for your favorite party',
    question: 'Which political party has your support?',
    description:
      'An independent public-opinion poll. This is not an official election or a scientifically representative survey.',
    kind: 'election',
    votes: 1284,
    weights: [0.21, 0.27, 0.34, 0.12, 0.06],
    options: [
      { label: "Pakistan People's Party", shortLabel: 'PPP', color: '#ed6a6a' },
      { label: 'Pakistan Muslim League (N)', shortLabel: 'PML-N', color: '#76ab68' },
      { label: 'Pakistan Tehreek e Insaf', shortLabel: 'PTI', color: '#37b7a0' },
      { label: 'OTHERS', shortLabel: 'OTHERS', color: '#f3b957' },
      { label: "I don't Vote", shortLabel: 'NO VOTE', color: '#9faeb2' },
    ],
  },
  {
    id: 'poll-leadership',
    slug: 'public-leadership-pulse',
    title: 'Public leadership pulse',
    question: 'Which public figure do you connect with most?',
    description:
      'A snapshot of public preference about well-known political personalities, not an endorsement.',
    kind: 'personality',
    votes: 417,
    weights: [0.36, 0.29, 0.23, 0.12],
    options: [
      { label: 'Imran Khan', shortLabel: 'Imran Khan', color: '#37b7a0' },
      { label: 'Nawaz Sharif', shortLabel: 'Nawaz Sharif', color: '#76ab68' },
      { label: 'Bilawal Bhutto Zardari', shortLabel: 'Bilawal Bhutto', color: '#ed6a6a' },
      { label: 'Another leader', shortLabel: 'Another', color: '#f3b957' },
    ],
  },
  {
    id: 'poll-tenure',
    slug: 'government-tenure-reflections',
    title: 'Government tenure reflections',
    question: 'Which recent government tenure served your priorities best?',
    description: 'A comparison of personal perceptions, not a measure of government performance.',
    kind: 'comparison',
    votes: 306,
    weights: [0.31, 0.38, 0.16, 0.15],
    options: [
      { label: '2013–2018', shortLabel: '2013–18', color: '#76ab68' },
      { label: '2018–2022', shortLabel: '2018–22', color: '#37b7a0' },
      { label: '2022–2024', shortLabel: '2022–24', color: '#ed6a6a' },
      { label: 'Unsure / none', shortLabel: 'Unsure', color: '#9faeb2' },
    ],
  },
  {
    id: 'poll-issues',
    slug: 'what-matters-most',
    title: 'What matters most?',
    question: 'Which issue should leaders prioritize first?',
    description: 'Help surface the everyday issues on people’s minds across Pakistan.',
    kind: 'survey',
    votes: 254,
    weights: [0.37, 0.23, 0.17, 0.14, 0.09],
    options: [
      { label: 'Cost of living', shortLabel: 'Cost of living', color: '#ed6a6a' },
      { label: 'Jobs and opportunity', shortLabel: 'Jobs', color: '#f3b957' },
      { label: 'Education', shortLabel: 'Education', color: '#37b7a0' },
      { label: 'Healthcare', shortLabel: 'Healthcare', color: '#76ab68' },
      { label: 'Climate resilience', shortLabel: 'Climate', color: '#8495df' },
    ],
  },
];
