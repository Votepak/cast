export type PollKind = 'election' | 'personality' | 'comparison' | 'survey';
export type PollStatus = 'draft' | 'published' | 'closed';
export type EffectiveStatus = 'draft' | 'scheduled' | 'active' | 'ended';

export interface PollOption {
  id: string;
  pollId: string;
  label: string;
  shortLabel: string;
  color: string;
  position: number;
}

export interface Poll {
  id: string;
  slug: string;
  title: string;
  question: string;
  description: string;
  kind: PollKind;
  startsAt: string;
  endsAt: string;
  status: PollStatus;
  isFeatured: boolean;
  createdAt: string;
  options: PollOption[];
  totalVotes?: number;
  subscriberCount?: number;
}

export interface OptionResult extends PollOption {
  votes: number;
  percentage: number;
}

export interface BreakdownRow {
  name: string;
  total: number;
  options: { optionId: string; votes: number }[];
}

export interface PollResults {
  pollId: string;
  totalVotes: number;
  filteredVotes: number;
  options: OptionResult[];
  leader: OptionResult | null;
  isTie: boolean;
  gender: BreakdownRow[];
  provinces: BreakdownRow[];
  districts: BreakdownRow[];
  daily: { date: string; votes: number }[];
  filter: { gender: string; province: string; district: string };
  updatedAt: string;
}

export interface PublicUser {
  id: string;
  email: string;
  createdAt: string;
  votedPollIds: string[];
  subscribedPollIds: string[];
}
