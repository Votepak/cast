import { z } from 'zod';

export const pollInput = z
  .object({
    title: z.string().trim().min(5).max(100),
    question: z.string().trim().min(10).max(200),
    description: z.string().trim().max(600).default(''),
    kind: z.enum(['election', 'personality', 'comparison', 'survey']),
    status: z.enum(['draft', 'published', 'closed']),
    isFeatured: z.boolean(),
    startsAt: z.string().datetime({ offset: true }),
    endsAt: z.string().datetime({ offset: true }),
    options: z
      .array(
        z.object({
          label: z.string().trim().min(1).max(100),
          shortLabel: z.string().trim().min(1).max(32),
          color: z.string().regex(/^#[0-9a-fA-F]{6}$/),
        }),
      )
      .min(2)
      .max(12),
  })
  .refine((data) => Date.parse(data.endsAt) > Date.parse(data.startsAt), {
    message: 'End time must come after start time.',
    path: ['endsAt'],
  })
  .refine(
    (data) => new Set(data.options.map((o) => o.label.toLowerCase())).size === data.options.length,
    {
      message: 'Each answer must have a unique label.',
      path: ['options'],
    },
  );
