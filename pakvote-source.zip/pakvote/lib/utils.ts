import type { EffectiveStatus, Poll } from './types';

export function getPollStatus(
  poll: Pick<Poll, 'status' | 'startsAt' | 'endsAt'>,
  now = Date.now(),
): EffectiveStatus {
  if (poll.status === 'draft') return 'draft';
  if (poll.status === 'closed' || now >= new Date(poll.endsAt).getTime()) return 'ended';
  if (now < new Date(poll.startsAt).getTime()) return 'scheduled';
  return 'active';
}

export const number = (value: number) => new Intl.NumberFormat('en-PK').format(value);
export const percent = (value: number) => `${value.toFixed(1)}%`;

export function localDate(value: string, options: Intl.DateTimeFormatOptions = {}) {
  return new Intl.DateTimeFormat('en-PK', {
    timeZone: 'Asia/Karachi',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
    ...options,
  }).format(new Date(value));
}

export const kindLabels = {
  election: 'Party election',
  personality: 'Personalities',
  comparison: 'Tenure comparison',
  survey: 'Community survey',
} as const;

export const kindDescriptions = {
  election: 'Make your political preference heard.',
  personality: 'See how public figures compare.',
  comparison: 'Reflect on different government tenures.',
  survey: 'Share what matters most to you.',
} as const;

export function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 80);
}

export function relativeTime(value: string) {
  const seconds = Math.max(0, Math.floor((new Date(value).getTime() - Date.now()) / 1000));
  return {
    days: Math.floor(seconds / 86400),
    hours: Math.floor((seconds % 86400) / 3600),
    minutes: Math.floor((seconds % 3600) / 60),
    seconds: seconds % 60,
  };
}
