import 'server-only';
import { ApiError } from './security';

interface MailOptions {
  to: string;
  subject: string;
  html: string;
  text: string;
  attachment?: { filename: string; content: string };
}

export async function sendEmail({ to, subject, html, text, attachment }: MailOptions) {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  if (!key || !from)
    throw new ApiError('Email delivery is not configured yet. Please contact the administrator.', 503);
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from,
      to: [to],
      subject,
      html,
      text,
      ...(attachment ? { attachments: [attachment] } : {}),
    }),
    cache: 'no-store',
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 500);
    console.error('[pakvote] Email provider error:', response.status, detail);
    throw new ApiError('Email could not be sent. Please try again shortly.', 503);
  }
  return response.json();
}

export function escapeHtml(value: string) {
  return value.replace(
    /[&<>"']/g,
    (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]!,
  );
}

export function emailShell(body: string) {
  return `<div style="background:#f5f8f4;padding:32px;font-family:Arial,sans-serif;color:#17352f"><div style="max-width:560px;margin:auto;background:#fff;border:1px solid #e4ede7;border-radius:16px;padding:36px"><div style="font-size:23px;font-weight:800;color:#0b493c;margin-bottom:28px">pak<span style="color:#16ad76">vote.</span></div>${body}<hr style="border:0;border-top:1px solid #e8eeea;margin:30px 0 18px"><p style="font-size:12px;line-height:1.6;color:#748981">Pakvote is an independent, unofficial public-opinion platform. No affiliation with the Election Commission of Pakistan.</p></div></div>`;
}
