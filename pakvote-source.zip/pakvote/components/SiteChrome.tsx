'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  CheckCheck,
  ChevronDown,
  Instagram,
  Mail,
  Menu,
  MessageCircle,
  ShieldCheck,
  Vote,
  X,
} from 'lucide-react';
import { useAuth } from './AuthProvider';
import type { Poll } from '@/lib/types';
import { getPollStatus } from '@/lib/utils';

const navItems = [
  { href: '/', label: 'Home' },
  { href: '/elections', label: 'Elections & polls' },
  { href: '/results', label: 'Live results' },
  { href: '/insights', label: 'Insights' },
  { href: '/about', label: 'About us' },
];
const waMessage = encodeURIComponent(
  'Hello! I found Pakvote and I would like to discuss a professional website or digital project with you. Could you share your availability, process, and an estimated timeline? Thank you.',
);
export const developerWhatsApp = `https://wa.me/923217809101?text=${waMessage}`;

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link href="/" aria-label="Pakvote home" className={`site-logo ${light ? 'site-logo-light' : ''}`}>
      <span className="logo-mark">
        <Vote size={23} strokeWidth={2.6} />
      </span>
      <span className="logo-type">
        pak<span>vote</span>
        <b>.</b>
      </span>
    </Link>
  );
}

export function Header() {
  const pathname = usePathname();
  const { user, loading, openAuth } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [voteTarget, setVoteTarget] = useState({ href: '/elections', label: 'Explore polls' });
  useEffect(() => {
    setMenuOpen(false);
    let cancelled = false;
    fetch('/api/polls', { cache: 'no-store' })
      .then((response) => response.json())
      .then((data: { polls?: Poll[] }) => {
        const available = data.polls || [];
        const active =
          available.find((poll) => poll.isFeatured && getPollStatus(poll) === 'active') ||
          available.find((poll) => getPollStatus(poll) === 'active');
        if (!cancelled) {
          setVoteTarget(
            active
              ? { href: `/elections/${active.slug}`, label: 'Vote now' }
              : { href: '/elections', label: 'Explore polls' },
          );
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [pathname]);
  return (
    <>
      <div className="topline">
        <div className="container topline-inner">
          <span>
            <span className="topline-dot" /> An independent space for every Pakistani voice
          </span>
          <Link href="/about">
            Not an official election platform <ArrowUpRight size={12} />
          </Link>
        </div>
      </div>
      <header className="site-header">
        <div className="container nav-inner">
          <Logo />
          <nav className={`main-nav ${menuOpen ? 'nav-open' : ''}`} aria-label="Main navigation">
            {navItems.map((item) => (
              <Link
                key={item.href}
                className={
                  pathname === item.href ||
                  (item.href === '/elections' && pathname.startsWith('/elections/'))
                    ? 'nav-active'
                    : ''
                }
                href={item.href}
              >
                {item.label}
              </Link>
            ))}
            <Link href="/account" className="mobile-only">
              My account
            </Link>
            <Link href="/admin" className="mobile-only">
              Admin dashboard
            </Link>
          </nav>
          <div className="nav-actions">
            {!loading &&
              (user ? (
                <Link className="nav-account" href="/account" title={user.email}>
                  <span className="account-avatar">{user.email[0].toUpperCase()}</span>
                  <span>My account</span>
                  <ChevronDown size={13} />
                </Link>
              ) : (
                <button className="nav-signin" onClick={() => openAuth()}>
                  Sign in
                </button>
              ))}
            <Link href={voteTarget.href} className="button button-primary nav-cta">
              {voteTarget.label} <ArrowUpRight size={16} />
            </Link>
            <button
              className="menu-toggle"
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={menuOpen}
              onClick={() => setMenuOpen((value) => !value)}
            >
              {menuOpen ? <X size={25} /> : <Menu size={25} />}
            </button>
          </div>
        </div>
      </header>
    </>
  );
}

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-cta">
          <div>
            <div className="eyebrow eyebrow-light">LET'S MAKE AN IMPACT</div>
            <h2>
              Have a digital idea?
              <br />
              <span>Let’s build it beautifully.</span>
            </h2>
            <p>
              Need a website or another digital project? Speak directly with the developer behind
              Pakvote.
            </p>
          </div>
          <a
            className="button button-lime footer-cta-button"
            href={developerWhatsApp}
            target="_blank"
            rel="noopener noreferrer"
          >
            <MessageCircle size={19} /> Contact the developer <ArrowUpRight size={17} />
          </a>
        </div>
        <div className="footer-main">
          <div className="footer-brand">
            <Logo light />
            <p>
              A fresh space for open conversation, transparent results, and the voices of Pakistan. Every
              perspective belongs here.
            </p>
            <div className="footer-brand-icons">
              <span>
                <ShieldCheck size={16} /> Independent
              </span>
              <span>
                <BarChart3 size={16} /> Data-led
              </span>
            </div>
          </div>
          <div className="footer-column">
            <h3>Explore</h3>
            <Link href="/elections">All elections & polls</Link>
            <Link href="/results">Live results</Link>
            <Link href="/insights">Data insights</Link>
            <Link href="/account">My account</Link>
          </div>
          <div className="footer-column">
            <h3>About Pakvote</h3>
            <Link href="/about">Our mission</Link>
            <Link href="/about#how-it-works">How voting works</Link>
            <Link href="/privacy">Privacy policy</Link>
            <Link href="/terms">Terms of use</Link>
          </div>
          <div className="footer-column">
            <h3>Connect</h3>
            <a href={developerWhatsApp} target="_blank" rel="noopener noreferrer">
              <MessageCircle size={16} /> WhatsApp developer
            </a>
            <Link href="/about#contact">
              <Mail size={16} /> Get in touch
            </Link>
            <Link href="/admin">Admin area</Link>
            <span className="footer-small">Made for conversations that matter.</span>
          </div>
        </div>
        <div className="footer-bottom">
          <span>
            © {new Date().getFullYear()} <strong>pakvote</strong>. All rights reserved.
          </span>
          <span>
            Independent public opinion — <strong>not an official election</strong> or representative
            survey.
          </span>
          <span>
            Crafted with purpose in Pakistan <span aria-label="Pakistan flag">🇵🇰</span>
          </span>
        </div>
      </div>
    </footer>
  );
}
