'use client';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Bell,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronRight,
  CirclePlus,
  Clock3,
  Download,
  FileDown,
  Fingerprint,
  LayoutDashboard,
  LoaderCircle,
  LockKeyhole,
  Mail,
  MoreHorizontal,
  Plus,
  Save,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Trash2,
  UsersRound,
  Vote,
  X,
} from 'lucide-react';
import type { Poll, PollKind, PollStatus } from '@/lib/types';
import { getPollStatus, kindLabels, localDate, number } from '@/lib/utils';
import { SEED_POLLS } from '@/lib/seed';
import { api, useAuth } from './AuthProvider';

interface FormData {
  title: string;
  question: string;
  description: string;
  kind: PollKind;
  status: PollStatus;
  isFeatured: boolean;
  startsAt: string;
  endsAt: string;
  options: { label: string; shortLabel: string; color: string }[];
}
const swatches = [
  '#37b7a0',
  '#76ab68',
  '#ed6a6a',
  '#f3b957',
  '#8495df',
  '#9faeb2',
  '#d98dc6',
  '#5bb6df',
];
function toLocalInput(iso: string) {
  const date = new Date(iso);
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
}
function blankForm(): FormData {
  return {
    title: '',
    question: '',
    description: '',
    kind: 'election',
    status: 'draft',
    isFeatured: false,
    startsAt: toLocalInput(new Date(Date.now() + 3600000).toISOString()),
    endsAt: toLocalInput(new Date(Date.now() + 14 * 86400000).toISOString()),
    options: [
      { label: '', shortLabel: '', color: swatches[0] },
      { label: '', shortLabel: '', color: swatches[1] },
    ],
  };
}
function fromPoll(poll: Poll): FormData {
  return {
    title: poll.title,
    question: poll.question,
    description: poll.description,
    kind: poll.kind,
    status: poll.status,
    isFeatured: poll.isFeatured,
    startsAt: toLocalInput(poll.startsAt),
    endsAt: toLocalInput(poll.endsAt),
    options: poll.options.map((o) => ({ label: o.label, shortLabel: o.shortLabel, color: o.color })),
  };
}
function toPayload(form: FormData) {
  return {
    ...form,
    startsAt: new Date(form.startsAt).toISOString(),
    endsAt: new Date(form.endsAt).toISOString(),
    options: form.options.map((o) => ({
      label: o.label.trim(),
      shortLabel: o.shortLabel.trim() || o.label.trim().slice(0, 32),
      color: o.color,
    })),
  };
}

export function AdminClient() {
  const { toast } = useAuth();
  const [checking, setChecking] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);
  const [demo, setDemo] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginBusy, setLoginBusy] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [polls, setPolls] = useState<Poll[]>([]);
  const [stats, setStats] = useState({ users: 0, subscribers: 0, pending: 0 });
  const [view, setView] = useState<'list' | 'form'>('list');
  const [editing, setEditing] = useState<Poll | null>(null);
  const [form, setForm] = useState<FormData>(blankForm);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');
  const [notifyBusy, setNotifyBusy] = useState(false);

  const reload = useCallback(async () => {
    const data = await api<{ polls: Poll[]; stats: typeof stats; demo: boolean }>('/api/admin/polls');
    setPolls(data.polls);
    setStats(data.stats);
    setDemo(data.demo);
  }, []);
  useEffect(() => {
    api<{ authenticated: boolean; demo: boolean }>('/api/admin/login')
      .then(async (data) => {
        setAuthenticated(data.authenticated);
        setDemo(data.demo);
        if (data.authenticated) await reload();
      })
      .catch(() => {})
      .finally(() => setChecking(false));
  }, [reload]);
  useEffect(() => {
    if (!authenticated || view !== 'list') return;
    const timer = window.setInterval(() => {
      if (!document.hidden) void reload().catch(() => {});
    }, 30000);
    return () => window.clearInterval(timer);
  }, [authenticated, view, reload]);

  const login = async (event: React.FormEvent) => {
    event.preventDefault();
    setLoginBusy(true);
    setLoginError('');
    try {
      await api('/api/admin/login', { method: 'POST', body: JSON.stringify({ email, password }) });
      setAuthenticated(true);
      setPassword('');
      await reload();
      toast('Admin dashboard unlocked.');
    } catch (error) {
      setLoginError(error instanceof Error ? error.message : 'Unable to sign in.');
    } finally {
      setLoginBusy(false);
    }
  };
  const logout = async () => {
    await api('/api/admin/logout', { method: 'POST' });
    setAuthenticated(false);
    setPolls([]);
    setView('list');
    toast('You have signed out of the admin area.');
  };
  const openCreate = () => {
    setEditing(null);
    setForm(blankForm());
    setFormError('');
    setView('form');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const openEdit = (poll: Poll) => {
    setEditing(poll);
    setForm(fromPoll(poll));
    setFormError('');
    setView('form');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const setField = <K extends keyof FormData>(key: K, value: FormData[K]) =>
    setForm((current) => ({ ...current, [key]: value }));
  const updateOption = (index: number, key: 'label' | 'shortLabel' | 'color', value: string) =>
    setForm((current) => ({
      ...current,
      options: current.options.map((o, i) => (i === index ? { ...o, [key]: value } : o)),
    }));
  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      if (Date.parse(form.endsAt) <= Date.parse(form.startsAt))
        throw new Error('The end time must come after the start time.');
      if (form.options.some((o) => !o.label.trim())) throw new Error('Please name every ballot choice.');
      const url = editing ? `/api/admin/polls/${editing.id}` : '/api/admin/polls';
      await api(url, { method: editing ? 'PATCH' : 'POST', body: JSON.stringify(toPayload(form)) });
      toast(editing ? 'Poll updated successfully.' : 'New poll created successfully.');
      setView('list');
      setEditing(null);
      await reload();
    } catch (error) {
      setFormError(error instanceof Error ? error.message : 'Could not save your poll.');
    } finally {
      setSaving(false);
    }
  };
  const closeNow = async (poll: Poll) => {
    if (!window.confirm(`Close "${poll.title}" now? Voting will stop, but results remain visible.`))
      return;
    try {
      await api(`/api/admin/polls/${poll.id}`, {
        method: 'PATCH',
        body: JSON.stringify({
          ...fromPoll(poll),
          status: 'closed',
          startsAt: poll.startsAt,
          endsAt: poll.endsAt,
          options: poll.options.map((o) => ({
            label: o.label,
            shortLabel: o.shortLabel,
            color: o.color,
          })),
        }),
      });
      toast('Poll closed. Voting is no longer open.');
      await reload();
    } catch (error) {
      toast(error instanceof Error ? error.message : 'Could not close poll.');
    }
  };
  const removePoll = async (poll: Poll) => {
    if (!window.confirm(`Permanently delete the draft "${poll.title}"?`)) return;
    try {
      await api(`/api/admin/polls/${poll.id}`, { method: 'DELETE' });
      toast('Draft poll deleted.');
      await reload();
    } catch (error) {
      toast(error instanceof Error ? error.message : 'Could not delete poll.');
    }
  };
  const notify = async () => {
    setNotifyBusy(true);
    try {
      const data = await api<{ sent: number; failed: number; completedPolls: number }>(
        '/api/admin/notify',
        { method: 'POST' },
      );
      toast(`Results emails: ${data.sent} sent${data.failed ? `, ${data.failed} failed` : ''}.`);
      await reload();
    } catch (error) {
      toast(error instanceof Error ? error.message : 'Results could not be sent.');
    } finally {
      setNotifyBusy(false);
    }
  };
  if (checking)
    return (
      <div className="container page-content">
        <div className="admin-checking">
          <LoaderCircle size={24} className="spin" /> Checking administrator access…
        </div>
      </div>
    );
  if (!authenticated)
    return (
      <div className="admin-login-page">
        <div className="admin-login-card">
          <span className="admin-login-icon">
            <LockKeyhole size={25} />
          </span>
          <span className="eyebrow">PAKVOTE / ADMINISTRATOR ACCESS</span>
          <h1>
            Welcome back,
            <br />
            <span>administrator.</span>
          </h1>
          <p>Secure access to elections, surveys, timelines and results.</p>
          {loginError && (
            <div className="form-error" role="alert">
              {loginError}
            </div>
          )}
          <form onSubmit={login}>
            <div className="field">
              <label htmlFor="admin-email">Admin email</label>
              <input
                id="admin-email"
                autoComplete="username"
                type="email"
                required
                placeholder="admin@example.com"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
            </div>
            <div className="field">
              <label htmlFor="admin-password">Password</label>
              <input
                id="admin-password"
                autoComplete="current-password"
                type="password"
                required
                placeholder="Your secure password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
              />
            </div>
            <button className="button button-primary button-full" disabled={loginBusy}>
              {loginBusy ? (
                <LoaderCircle className="spin" size={18} />
              ) : (
                <>
                  Access dashboard <ArrowRight size={17} />
                </>
              )}
            </button>
          </form>
          {demo && (
            <div className="admin-demo-tip">
              <strong>Local preview access</strong>
              <span>Email: admin@pakvote.local</span>
              <span>Password: DemoAdmin2026!</span>
              <small>Demo credentials only work locally. Set your own credentials in Vercel.</small>
            </div>
          )}
          <Link href="/" className="admin-back">
            <ArrowLeft size={15} /> Back to Pakvote
          </Link>
        </div>
        <div className="admin-login-art">
          <span>PAKVOTE / CONTROL CENTER</span>
          <div className="admin-art-icon">
            <Vote size={85} strokeWidth={1.1} />
          </div>
          <h2>
            Thoughtful tools for
            <br />
            meaningful conversations.
          </h2>
          <p>Launch, manage and interpret each poll with confidence.</p>
        </div>
      </div>
    );
  const liveCount = polls.filter((p) => getPollStatus(p) === 'active').length;
  const totalVotes = polls.reduce((sum, poll) => sum + (poll.totalVotes || 0), 0);
  return (
    <div className="container page-content admin-page">
      <div className="admin-heading">
        <div>
          <div className="breadcrumbs breadcrumb-dark">
            <Link href="/">Home</Link>
            <ChevronRight size={13} /> Admin dashboard
          </div>
          <span className="eyebrow">PAKVOTE / CONTROL CENTER</span>
          <h1>
            {view === 'form' ? (editing ? 'Edit poll.' : 'Create a new poll.') : 'Good to see you.'}
          </h1>
          <p>
            {view === 'form'
              ? 'Configure your question, answers and voting schedule.'
              : 'Everything you need to manage the conversation, in one place.'}
          </p>
        </div>
        <div className="admin-heading-actions">
          {view === 'form' ? (
            <button className="button button-outline" onClick={() => setView('list')}>
              <ArrowLeft size={17} /> Dashboard
            </button>
          ) : (
            <button className="button button-primary" onClick={openCreate}>
              <Plus size={18} /> New election or survey
            </button>
          )}
          <button className="admin-signout" onClick={() => void logout()}>
            Sign out
          </button>
        </div>
      </div>
      {demo && (
        <div className="admin-demo-banner">
          <ShieldCheck size={18} />
          <p>
            <strong>Preview workspace.</strong> Changes are saved to a local SQLite file. Production uses
            your Turso database and sends emails only after Resend is configured.
          </p>
        </div>
      )}
      {view === 'list' ? (
        <>
          <div className="admin-stat-grid">
            <div>
              <span>
                <Vote size={20} />
              </span>
              <strong>{number(totalVotes)}</strong>
              <p>Total votes cast</p>
            </div>
            <div>
              <span>
                <LayoutDashboard size={20} />
              </span>
              <strong>{number(polls.length)}</strong>
              <p>Polls created</p>
            </div>
            <div>
              <span>
                <CirclePlus size={20} />
              </span>
              <strong>{number(liveCount)}</strong>
              <p>Live now</p>
            </div>
            <div>
              <span>
                <Mail size={20} />
              </span>
              <strong>{number(stats.subscribers)}</strong>
              <p>Results subscribers</p>
            </div>
          </div>
          <div className="admin-list-layout">
            <div className="admin-list-main">
              <div className="admin-section-head">
                <div>
                  <span className="eyebrow">MANAGE CONVERSATIONS</span>
                  <h2>Your polls</h2>
                </div>
                <span>{polls.length} TOTAL</span>
              </div>
              {polls.map((poll) => (
                <div className="admin-poll-card" key={poll.id}>
                  <div className={`admin-poll-kind admin-kind-${poll.kind}`}>
                    <Vote size={22} />
                  </div>
                  <div className="admin-poll-copy">
                    <div>
                      <span className={`status-tag status-${getPollStatus(poll)}`}>
                        <span className="live-dot" />
                        {getPollStatus(poll)}
                      </span>
                      {poll.isFeatured && <span className="featured-tag">FEATURED</span>}
                    </div>
                    <h3>{poll.title}</h3>
                    <p>
                      {kindLabels[poll.kind]} · {number(poll.totalVotes || 0)} votes · Closes{' '}
                      {localDate(poll.endsAt)}
                    </p>
                    <div className="admin-poll-actions">
                      <button onClick={() => openEdit(poll)}>Edit & schedule</button>
                      <a href={`/api/admin/export?pollId=${encodeURIComponent(poll.id)}`}>
                        Download CSV <FileDown size={14} />
                      </a>
                      {poll.status === 'published' && getPollStatus(poll) !== 'ended' && (
                        <button onClick={() => void closeNow(poll)}>Close poll</button>
                      )}
                      {poll.status === 'draft' && !poll.totalVotes && (
                        <button className="admin-delete" onClick={() => void removePoll(poll)}>
                          Delete draft
                        </button>
                      )}
                    </div>
                  </div>
                  <Link
                    href={`/elections/${poll.slug}`}
                    className="admin-poll-link"
                    aria-label={`View ${poll.title}`}
                  >
                    <ArrowUpRight size={19} />
                  </Link>
                </div>
              ))}
              <button className="admin-create-row" onClick={openCreate}>
                <Plus size={19} /> Start a new election, personality poll or survey{' '}
                <ArrowRight size={16} />
              </button>
            </div>
            <aside className="admin-side">
              <div className="admin-side-card">
                <span className="eyebrow">RESULTS DELIVERY</span>
                <h3>Keep your promise.</h3>
                <p>
                  When polls close, subscribers can receive the final CSV with totals and demographic
                  breakdowns.
                </p>
                <div className="admin-side-line">
                  <span>Results subscribers</span>
                  <strong>{stats.subscribers}</strong>
                </div>
                <div className="admin-side-line">
                  <span>Awaiting delivery*</span>
                  <strong>{stats.pending}</strong>
                </div>
                <button
                  className="button button-primary button-full"
                  onClick={() => void notify()}
                  disabled={notifyBusy}
                >
                  {notifyBusy ? (
                    <LoaderCircle size={17} className="spin" />
                  ) : (
                    <>
                      <Bell size={17} /> Send due results now
                    </>
                  )}
                </button>
                <small>
                  *Includes sign-ups for polls that have not closed yet. Automated delivery runs daily on
                  Vercel after configuration.
                </small>
              </div>
              <div className="admin-side-card admin-tip">
                <ShieldCheck size={23} />
                <h3>Integrity matters.</h3>
                <p>
                  Ballot options lock once a poll receives votes. Account and browser limits are enforced
                  in the database for each poll.
                </p>
                <Link href="/about#how-it-works">
                  Read our process <ArrowRight size={15} />
                </Link>
              </div>
            </aside>
          </div>
        </>
      ) : (
        <form className="admin-form-layout" onSubmit={save}>
          <div className="admin-form-main">
            <section className="admin-form-section">
              <div className="admin-form-title">
                <span>01</span>
                <div>
                  <h2>The conversation</h2>
                  <p>Give your poll a clear, neutral title and a question people can answer.</p>
                </div>
              </div>
              <div className="admin-fields">
                <div className="field">
                  <label htmlFor="poll-title">
                    Poll title <b>*</b>
                  </label>
                  <input
                    id="poll-title"
                    value={form.title}
                    required
                    minLength={5}
                    maxLength={100}
                    onChange={(event) => setField('title', event.target.value)}
                    placeholder="e.g. Vote for your favorite party"
                  />
                </div>
                <div className="field">
                  <label htmlFor="poll-question">
                    Ballot question <b>*</b>
                  </label>
                  <input
                    id="poll-question"
                    value={form.question}
                    required
                    minLength={10}
                    maxLength={200}
                    onChange={(event) => setField('question', event.target.value)}
                    placeholder="e.g. Which party has your support?"
                  />
                </div>
                <div className="field">
                  <label htmlFor="poll-description">Description</label>
                  <textarea
                    id="poll-description"
                    rows={3}
                    maxLength={600}
                    value={form.description}
                    onChange={(event) => setField('description', event.target.value)}
                    placeholder="A short, balanced introduction to this poll."
                  />
                </div>
                <div className="field">
                  <label htmlFor="poll-kind">
                    Poll type <b>*</b>
                  </label>
                  <div className="select-wrap">
                    <select
                      id="poll-kind"
                      value={form.kind}
                      onChange={(event) => setField('kind', event.target.value as PollKind)}
                      disabled={Boolean(editing?.totalVotes)}
                    >
                      <option value="election">Party election</option>
                      <option value="personality">Personality survey</option>
                      <option value="comparison">Government tenure comparison</option>
                      <option value="survey">General survey</option>
                    </select>
                    <ChevronDown size={16} />
                  </div>
                </div>
              </div>
            </section>
            <section className="admin-form-section">
              <div className="admin-form-title">
                <span>02</span>
                <div>
                  <h2>Ballot choices</h2>
                  <p>Add between 2 and 12 answer options. Choice text locks after the first vote.</p>
                </div>
              </div>
              <div className="admin-option-list">
                {form.options.map((option, index) => (
                  <div className="admin-option-row" key={index}>
                    <span className="admin-option-index">{String(index + 1).padStart(2, '0')}</span>
                    <input
                      type="color"
                      aria-label={`Color for option ${index + 1}`}
                      value={option.color}
                      onChange={(event) => updateOption(index, 'color', event.target.value)}
                    />
                    <div className="field">
                      <label htmlFor={`option-label-${index}`}>Option name</label>
                      <input
                        id={`option-label-${index}`}
                        value={option.label}
                        required
                        maxLength={100}
                        disabled={Boolean(editing?.totalVotes)}
                        onChange={(event) => updateOption(index, 'label', event.target.value)}
                        placeholder="Answer shown on the ballot"
                      />
                    </div>
                    <div className="field">
                      <label htmlFor={`option-short-${index}`}>Short label</label>
                      <input
                        id={`option-short-${index}`}
                        value={option.shortLabel}
                        maxLength={32}
                        disabled={Boolean(editing?.totalVotes)}
                        onChange={(event) => updateOption(index, 'shortLabel', event.target.value)}
                        placeholder="For charts"
                      />
                    </div>
                    {form.options.length > 2 && !editing?.totalVotes && (
                      <button
                        type="button"
                        className="remove-option"
                        aria-label={`Remove option ${index + 1}`}
                        onClick={() =>
                          setField(
                            'options',
                            form.options.filter((_, i) => i !== index),
                          )
                        }
                      >
                        <X size={18} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              {form.options.length < 12 && !editing?.totalVotes && (
                <button
                  type="button"
                  className="add-option"
                  onClick={() =>
                    setField('options', [
                      ...form.options,
                      {
                        label: '',
                        shortLabel: '',
                        color: swatches[form.options.length % swatches.length],
                      },
                    ])
                  }
                >
                  <Plus size={16} /> Add another option
                </button>
              )}
            </section>
            <section className="admin-form-section">
              <div className="admin-form-title">
                <span>03</span>
                <div>
                  <h2>Voting window</h2>
                  <p>Set exactly when participation opens and closes.</p>
                </div>
              </div>
              <div className="admin-date-grid">
                <div className="field">
                  <label htmlFor="poll-start">
                    Start date & time <b>*</b>
                  </label>
                  <input
                    id="poll-start"
                    type="datetime-local"
                    required
                    value={form.startsAt}
                    onChange={(event) => setField('startsAt', event.target.value)}
                  />
                </div>
                <div className="field">
                  <label htmlFor="poll-end">
                    End date & time <b>*</b>
                  </label>
                  <input
                    id="poll-end"
                    type="datetime-local"
                    required
                    value={form.endsAt}
                    onChange={(event) => setField('endsAt', event.target.value)}
                  />
                </div>
              </div>
              <p className="admin-time-note">
                <Clock3 size={15} /> Times are entered in your browser’s local timezone. On the public
                site, they appear in Pakistan Standard Time (PKT).
              </p>
            </section>
            {formError && (
              <div role="alert" className="form-error">
                {formError}
              </div>
            )}
            <div className="admin-form-actions">
              <button type="submit" className="button button-primary" disabled={saving}>
                {saving ? <LoaderCircle size={17} className="spin" /> : <Save size={17} />}{' '}
                {saving ? 'Saving…' : editing ? 'Save changes' : 'Create poll'}
              </button>
              <button type="button" className="button button-outline" onClick={() => setView('list')}>
                Cancel
              </button>
            </div>
          </div>
          <aside className="admin-form-aside">
            <div className="admin-side-card">
              <span className="eyebrow">PUBLISHING SETTINGS</span>
              <h3>Make it live.</h3>
              <p>A published poll opens automatically at the start time you choose.</p>
              <div className="field">
                <label htmlFor="poll-status">Publication status</label>
                <div className="select-wrap">
                  <select
                    id="poll-status"
                    value={form.status}
                    onChange={(event) => setField('status', event.target.value as PollStatus)}
                  >
                    <option value="draft">Draft · Hidden</option>
                    <option value="published">Publish · Scheduled</option>
                    <option value="closed">Closed · Results only</option>
                  </select>
                  <ChevronDown size={16} />
                </div>
              </div>
              <label className="admin-featured-check">
                <input
                  type="checkbox"
                  checked={form.isFeatured}
                  onChange={(event) => setField('isFeatured', event.target.checked)}
                />
                <span>
                  <strong>Feature on the homepage</strong>
                  <small>One poll can be featured at a time.</small>
                </span>
              </label>
            </div>
            <div className="admin-side-card admin-tip">
              <CalendarDays size={24} />
              <h3>What happens next?</h3>
              <p>
                When published, the poll begins at your selected time. A live countdown appears
                automatically; voting closes at your end time.
              </p>
              <p>
                To email a final CSV, configure Resend and use the daily Vercel cron or “Send due results
                now”.
              </p>
            </div>
          </aside>
        </form>
      )}
    </div>
  );
}
