'use client';
import { useEffect, useState } from 'react';
import {
  ArrowUpRight,
  BarChart3,
  Check,
  Copy,
  Instagram,
  Link2,
  MessageCircle,
  Music2,
  Share2,
  Timer,
} from 'lucide-react';
import { useAuth } from './AuthProvider';
import { getPollStatus, relativeTime } from '@/lib/utils';
import type { Poll } from '@/lib/types';

export function Countdown({ poll, compact = false }: { poll: Poll; compact?: boolean }) {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    setNow(Date.now());
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);
  const status = getPollStatus(poll, now || Date.now());
  if (status === 'draft')
    return (
      <div className={`countdown-empty ${compact ? 'countdown-compact' : ''}`}>
        <Timer size={19} /> Schedule coming soon
      </div>
    );
  if (status === 'ended')
    return (
      <div className={`countdown-empty ${compact ? 'countdown-compact' : ''}`}>
        <Check size={19} /> Poll closed · Results available
      </div>
    );
  const time = relativeTime(status === 'scheduled' ? poll.startsAt : poll.endsAt);
  return (
    <div className={`countdown ${compact ? 'countdown-compact' : ''}`}>
      <div className="countdown-label">
        <span className="live-dot" /> {status === 'scheduled' ? 'VOTING STARTS IN' : 'VOTING CLOSES IN'}
      </div>
      <div className="countdown-numbers">
        {(
          [
            ['days', time.days],
            ['hours', time.hours],
            ['minutes', time.minutes],
          ] as const
        ).map(([label, value]) => (
          <div className="countdown-unit" key={label}>
            <strong>{String(value).padStart(2, '0')}</strong>
            <span>{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function AdSlot({
  size = 'horizontal',
  label = 'Advertising space',
}: {
  size?: 'horizontal' | 'square' | 'slim';
  label?: string;
}) {
  return (
    <div className={`ad-slot ad-${size}`} aria-label="Reserved advertisement placement">
      <span className="ad-top">
        AD SPACE <span>✳</span>
      </span>
      <div className="ad-copy">
        {label}
        <small>Your brand could be here.</small>
      </div>
      <span className="ad-bottom">RESERVED PLACEMENT</span>
    </div>
  );
}

export function ShareBar({
  title,
  url,
  compact = false,
}: {
  title: string;
  url?: string;
  compact?: boolean;
}) {
  const { toast } = useAuth();
  const shareUrl =
    typeof window !== 'undefined'
      ? new URL(url || window.location.pathname, window.location.origin).toString()
      : url || '';
  const text = `Have your say on Pakvote: ${title}. Explore the results and join the conversation.`;
  const open = (target: string) =>
    window.open(target, '_blank', 'noopener,noreferrer,width=650,height=580');
  const copy = async (platform?: string) => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast(
        platform
          ? `Link copied! Paste it into ${platform} to share.`
          : 'Poll link copied to your clipboard.',
      );
    } catch {
      toast(`Copy this link to share: ${shareUrl}`);
    }
  };
  const nativeShare = async (platform?: string) => {
    if (navigator.share) {
      try {
        await navigator.share({ title, text, url: shareUrl });
        return;
      } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') return;
      }
    }
    await copy(platform);
  };
  return (
    <div className={`share-row ${compact ? 'share-row-compact' : ''}`}>
      {!compact && <span className="share-label">Share this poll</span>}
      <div className="share-buttons">
        <button
          type="button"
          className="share-circle share-wa"
          aria-label="Share on WhatsApp"
          title="WhatsApp"
          onClick={() => open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + shareUrl)}`)}
        >
          <MessageCircle size={17} />
        </button>
        <button
          type="button"
          className="share-circle share-fb"
          aria-label="Share on Facebook"
          title="Facebook"
          onClick={() =>
            open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`)
          }
        >
          <strong>f</strong>
        </button>
        <button
          type="button"
          className="share-circle share-x"
          aria-label="Share on X"
          title="X"
          onClick={() =>
            open(
              `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(shareUrl)}`,
            )
          }
        >
          <strong>𝕏</strong>
        </button>
        <button
          type="button"
          className="share-circle share-ig"
          aria-label="Share through Instagram or copy link"
          title="Instagram (native share or copy link)"
          onClick={() => nativeShare('Instagram')}
        >
          <Instagram size={17} />
        </button>
        <button
          type="button"
          className="share-circle share-tt"
          aria-label="Share through TikTok or copy link"
          title="TikTok (native share or copy link)"
          onClick={() => nativeShare('TikTok')}
        >
          <Music2 size={17} />
        </button>
        <button
          type="button"
          className="share-circle share-more"
          aria-label="More sharing options"
          title="More sharing options"
          onClick={() => nativeShare()}
        >
          <Share2 size={17} />
        </button>
        {!compact && (
          <button
            type="button"
            className="share-circle share-copy"
            aria-label="Copy link"
            title="Copy link"
            onClick={() => copy()}
          >
            <Link2 size={17} />
          </button>
        )}
      </div>
    </div>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  text,
  action,
}: {
  eyebrow: string;
  title: React.ReactNode;
  text?: string;
  action?: { href: string; label: string };
}) {
  return (
    <div className="section-heading">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h2>{title}</h2>
        {text && <p>{text}</p>}
      </div>
      {action && (
        <a className="section-action" href={action.href}>
          {action.label} <ArrowUpRight size={17} />
        </a>
      )}
    </div>
  );
}

export function DemoNotice({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`demo-notice ${compact ? 'demo-notice-compact' : ''}`}>
      <span className="demo-pulse" />
      <strong>Preview data</strong> The ballots and statistics shown here are illustrative, not real
      public votes. New votes you cast in this preview are saved locally.
    </div>
  );
}

export function TrendChart({ daily }: { daily: { date: string; votes: number }[] }) {
  const days = Array.from({ length: 14 }, (_, index) => {
    const d = new Date();
    d.setUTCHours(0, 0, 0, 0);
    d.setUTCDate(d.getUTCDate() - 13 + index);
    const date = d.toISOString().slice(0, 10);
    return { date, votes: daily.find((row) => row.date === date)?.votes || 0 };
  });
  const max = Math.max(1, ...days.map((row) => row.votes));
  const points = days.map((row, index) => ({
    x: 15 + index * (770 / 13),
    y: 168 - (row.votes / max) * 139,
  }));
  const line = points.map((p, i) => `${i ? 'L' : 'M'}${p.x},${p.y}`).join(' ');
  const area = `${line} L785,176 L15,176 Z`;
  return (
    <div
      className="trend-chart"
      role="img"
      aria-label={`Daily participation over 14 days; maximum ${max} votes per day`}
    >
      <svg viewBox="0 0 800 200" preserveAspectRatio="none" aria-hidden="true">
        <defs>
          <linearGradient id="chartFill" x1="0" x2="0" y1="0" y2="1">
            <stop stopColor="#46c590" stopOpacity="0.26" />
            <stop offset="1" stopColor="#46c590" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path
          d="M15 42 H785 M15 101 H785 M15 176 H785"
          stroke="#e8efea"
          strokeDasharray="4 5"
          fill="none"
        />
        <path d={area} fill="url(#chartFill)" />
        <path
          d={line}
          fill="none"
          stroke="#16a972"
          strokeWidth="3"
          strokeLinejoin="round"
          strokeLinecap="round"
          vectorEffect="non-scaling-stroke"
        />
        {points
          .filter((_, index) => index === points.length - 1)
          .map((p, i) => (
            <circle key={i} cx={p.x} cy={p.y} r="5" fill="#16a972" stroke="white" strokeWidth="3" />
          ))}
      </svg>
      <div className="chart-axis">
        <span>14 days ago</span>
        <span>7 days ago</span>
        <span>Today</span>
      </div>
    </div>
  );
}
