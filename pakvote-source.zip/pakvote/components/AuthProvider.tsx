'use client';
import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  KeyRound,
  LoaderCircle,
  LockKeyhole,
  Mail,
  ShieldCheck,
  X,
} from 'lucide-react';
import type { PublicUser } from '@/lib/types';

interface AuthContextValue {
  user: PublicUser | null;
  loading: boolean;
  openAuth: (onSuccess?: () => void, email?: string) => void;
  refreshUser: () => Promise<void>;
  logout: () => Promise<void>;
  toast: (message: string) => void;
}
const AuthContext = createContext<AuthContextValue | null>(null);
export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used inside AuthProvider');
  return value;
}

export async function api<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...options,
    cache: 'no-store',
    headers: { 'Content-Type': 'application/json', ...options?.headers },
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'We could not complete your request.');
  return data as T;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<PublicUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [devCode, setDevCode] = useState('');
  const [stage, setStage] = useState<'email' | 'code'>('email');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [toastMessage, setToastMessage] = useState('');
  const callback = useRef<(() => void) | undefined>(undefined);

  const refreshUser = useCallback(async () => {
    try {
      const data = await api<{ user: PublicUser | null }>('/api/auth/me');
      setUser(data.user);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void refreshUser();
  }, [refreshUser]);
  useEffect(() => {
    if (!toastMessage) return;
    const id = window.setTimeout(() => setToastMessage(''), 4500);
    return () => window.clearTimeout(id);
  }, [toastMessage]);
  useEffect(() => {
    if (!open) return;
    const onEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false);
    };
    document.addEventListener('keydown', onEscape);
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onEscape);
      document.body.style.overflow = previous;
    };
  }, [open]);

  const openAuth = (onSuccess?: () => void, initialEmail = '') => {
    callback.current = onSuccess;
    setEmail(initialEmail || user?.email || '');
    setCode('');
    setStage('email');
    setDevCode('');
    setError('');
    setNotice('');
    setOpen(true);
  };
  const logout = async () => {
    await api('/api/auth/logout', { method: 'POST' });
    setUser(null);
    setToastMessage('You have signed out.');
  };
  const requestCode = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const data = await api<{ ok: boolean; devCode?: string }>('/api/auth/request-code', {
        method: 'POST',
        body: JSON.stringify({ email }),
      });
      setDevCode(data.devCode || '');
      setStage('code');
      setNotice(
        data.devCode
          ? 'Preview mode: use the test code shown below.'
          : 'We sent a six-digit code to your inbox.',
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to send code.');
    } finally {
      setBusy(false);
    }
  };
  const verifyCode = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      await api('/api/auth/verify-code', { method: 'POST', body: JSON.stringify({ email, code }) });
      await refreshUser();
      setOpen(false);
      setToastMessage('Welcome to Pakvote. Your email is verified!');
      callback.current?.();
      callback.current = undefined;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invalid verification code.');
    } finally {
      setBusy(false);
    }
  };
  return (
    <AuthContext.Provider
      value={{ user, loading, openAuth, refreshUser, logout, toast: setToastMessage }}
    >
      {children}
      {toastMessage && (
        <div role="status" className="toast">
          <span className="toast-check">
            <Check size={16} />
          </span>
          {toastMessage}
          <button aria-label="Dismiss" onClick={() => setToastMessage('')}>
            <X size={15} />
          </button>
        </div>
      )}
      {open && (
        <div
          className="modal-scrim"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setOpen(false);
          }}
        >
          <div className="auth-modal" role="dialog" aria-modal="true" aria-labelledby="auth-heading">
            <button className="modal-close" aria-label="Close" onClick={() => setOpen(false)}>
              <X size={19} />
            </button>
            <div className="auth-emblem">
              <LockKeyhole size={23} strokeWidth={2.1} />
            </div>
            <div className="eyebrow">SECURE ACCESS</div>
            <h2 id="auth-heading">
              {stage === 'email' ? 'Your voice starts here.' : 'Check your inbox.'}
            </h2>
            <p className="muted">
              {stage === 'email' ? (
                'Verify your email to participate. One verified account and one browser can vote once in each poll.'
              ) : (
                <>
                  Enter the six-digit code sent to <strong>{email}</strong>.
                </>
              )}
            </p>
            {error && (
              <div className="form-error" role="alert">
                {error}
              </div>
            )}
            {notice && <div className="form-notice">{notice}</div>}
            {stage === 'email' ? (
              <form onSubmit={requestCode} className="auth-form">
                <label htmlFor="auth-email">Email address</label>
                <div className="input-icon">
                  <Mail size={18} />
                  <input
                    id="auth-email"
                    autoFocus
                    type="email"
                    required
                    autoComplete="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                  />
                </div>
                <button className="button button-primary button-full" disabled={busy}>
                  {busy ? (
                    <LoaderCircle className="spin" size={18} />
                  ) : (
                    <>
                      Send verification code <ArrowRight size={18} />
                    </>
                  )}
                </button>
              </form>
            ) : (
              <form onSubmit={verifyCode} className="auth-form">
                <label htmlFor="auth-code">Verification code</label>
                <div className="input-icon">
                  <KeyRound size={18} />
                  <input
                    id="auth-code"
                    autoFocus
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]{6}"
                    maxLength={6}
                    required
                    autoComplete="one-time-code"
                    placeholder="000000"
                    value={code}
                    onChange={(event) => setCode(event.target.value.replace(/\D/g, ''))}
                    className="code-input"
                  />
                </div>
                {devCode && (
                  <div className="dev-code">
                    DEMO CODE <strong>{devCode}</strong>
                    <button type="button" onClick={() => setCode(devCode)}>
                      Use code
                    </button>
                  </div>
                )}
                <button className="button button-primary button-full" disabled={busy}>
                  {busy ? (
                    <LoaderCircle className="spin" size={18} />
                  ) : (
                    <>
                      Verify & continue <ArrowRight size={18} />
                    </>
                  )}
                </button>
                <button
                  type="button"
                  className="text-button"
                  onClick={() => {
                    setStage('email');
                    setError('');
                    setNotice('');
                  }}
                >
                  <ArrowLeft size={15} /> Use a different email
                </button>
              </form>
            )}
            <div className="auth-bottom">
              <ShieldCheck size={17} /> No passwords to remember. We never publish your email.
            </div>
          </div>
        </div>
      )}
    </AuthContext.Provider>
  );
}
