'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  CalendarDays,
  ChartColumnIncreasing,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Fingerprint,
  Globe2,
  HeartHandshake,
  Info,
  Lightbulb,
  MapPin,
  MapPinned,
  PieChart,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UsersRound,
  Vote,
} from 'lucide-react';
import type { Poll, PollResults } from '@/lib/types';
import { getPollStatus, kindLabels, number, percent } from '@/lib/utils';
import { AdSlot, DemoNotice, SectionHeading } from './Shared';

export function InsightsClient({
  polls,
  poll,
  results: initialResults,
  demo,
}: {
  polls: Poll[];
  poll: Poll;
  results: PollResults;
  demo: boolean;
}) {
  const router = useRouter();
  const [results, setResults] = useState(initialResults);
  useEffect(() => {
    const refresh = async () => {
      if (document.hidden) return;
      try {
        const response = await fetch(`/api/results?pollId=${encodeURIComponent(poll.id)}`, {
          cache: 'no-store',
        });
        if (response.ok) setResults((await response.json()).results);
      } catch {
        /* Keep the last available analysis. */
      }
    };
    const timer = window.setInterval(() => void refresh(), 30000);
    return () => window.clearInterval(timer);
  }, [poll.id]);
  const total = results.totalVotes;
  const sorted = [...results.options].sort((a, b) => b.votes - a.votes);
  const leader = sorted[0];
  const runner = sorted[1];
  const margin = total ? (leader?.votes || 0) - (runner?.votes || 0) : 0;
  const highestRegion = results.provinces[0];
  const topDistricts = results.districts.slice(0, 7);
  const maxDistrict = topDistricts[0]?.total || 1;
  const maxRegion = highestRegion?.total || 1;
  return (
    <div className="container page-content insights-page">
      <div className="breadcrumbs breadcrumb-dark">
        <Link href="/">Home</Link>
        <ChevronRight size={13} /> Data insights
      </div>
      <section className="insights-hero">
        <div>
          <span className="eyebrow">THE STORY BEHIND THE DATA</span>
          <h1>
            Data with
            <br />
            <em>perspective.</em>
          </h1>
          <p>
            Numbers can start a conversation — but context makes it meaningful. Explore patterns in
            participation while keeping the limitations in view.
          </p>
          <Link href="/results" className="button button-primary">
            Open live dashboard <ArrowUpRight size={17} />
          </Link>
        </div>
        <div className="insights-hero-graphic">
          <span className="insight-graphic-small">PUBLIC OPINION / PAKISTAN</span>
          <div className="insight-graphic-bars">
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
          </div>
          <span className="insight-graphic-quote">
            Behind every number
            <br />
            is a voice.
          </span>
        </div>
      </section>
      {demo && <DemoNotice compact />}
      <div className="insight-poll-picker">
        <div>
          <span className="eyebrow">CURRENTLY ANALYSING</span>
          <strong>{poll.title}</strong>
        </div>
        <div className="select-wrap">
          <select
            aria-label="Select poll to analyse"
            value={poll.slug}
            onChange={(event) => router.push(`/insights?poll=${encodeURIComponent(event.target.value)}`)}
          >
            {polls.map((item) => (
              <option key={item.id} value={item.slug}>
                {item.title}
              </option>
            ))}
          </select>
          <ChevronDown size={17} />
        </div>
      </div>
      <section className="insight-stat-grid">
        <div className="insight-stat">
          <span>
            <UsersRound size={21} />
          </span>
          <strong>{number(total)}</strong>
          <p>Total responses</p>
          <small>Across all regions</small>
        </div>
        <div className="insight-stat">
          <span>
            <MapPinned size={21} />
          </span>
          <strong>
            {number(results.provinces.length)}
            <em> / 7</em>
          </strong>
          <p>Regions heard from</p>
          <small>Self-reported locations</small>
        </div>
        <div className="insight-stat">
          <span>
            <BarChart3 size={21} />
          </span>
          <strong>{total ? percent(leader.percentage) : '—'}</strong>
          <p>Largest option share</p>
          <small>{total ? leader.shortLabel : 'Awaiting responses'}</small>
        </div>
        <div className="insight-stat">
          <span>
            <MapPin size={21} />
          </span>
          <strong>{number(results.districts.length)}</strong>
          <p>Participating districts</p>
          <small>By voluntary reporting</small>
        </div>
      </section>
      <div className="section-heading insight-section-head">
        <div>
          <span className="eyebrow">01 / THE KEY TAKEAWAYS</span>
          <h2>
            Here’s what we’re <span className="highlight-text">seeing.</span>
          </h2>
          <p>An honest read of the results, as submitted by visitors to this platform.</p>
        </div>
      </div>
      <div className="takeaways-grid">
        <div className="takeaway-card takeaway-lead">
          <span className="takeaway-number">01 / THE LEAD</span>
          <span className="takeaway-icon">
            <TrendingUp size={21} />
          </span>
          <h3>
            {total && leader
              ? results.isTie && runner
                ? `${leader.shortLabel} and ${runner.shortLabel} share the lead.`
                : `${leader.shortLabel} has the most responses.`
              : 'The conversation is just beginning.'}
          </h3>
          <p>
            {total && leader
              ? results.isTie && runner
                ? `${leader.label} and ${runner.label} are tied at ${number(leader.votes)} responses each. There is no sole leader. These counts describe participants, not a forecast.`
                : `${leader.label} currently has ${number(leader.votes)} of ${number(total)} responses (${percent(leader.percentage)}). ${runner ? `That’s a margin of ${number(margin)} over ${runner.shortLabel}.` : ''} This is a count of participants, not a forecast.`
              : 'As soon as people submit votes, you’ll see the leading choice and margin here.'}
          </p>
        </div>
        <div className="takeaway-card">
          <span className="takeaway-number">02 / PARTICIPATION</span>
          <span className="takeaway-icon">
            <Globe2 size={21} />
          </span>
          <h3>
            {highestRegion
              ? `${highestRegion.name} is most active.`
              : 'Where will the first voices come from?'}
          </h3>
          <p>
            {highestRegion
              ? `${number(highestRegion.total)} submitted votes list ${highestRegion.name} as their region — ${percent(total ? (highestRegion.total / total) * 100 : 0)} of all responses. More responses do not necessarily mean greater population support.`
              : 'Region-level participation appears as visitors tell us where they are based.'}
          </p>
        </div>
        <div className="takeaway-card">
          <span className="takeaway-number">03 / THE BIG PICTURE</span>
          <span className="takeaway-icon">
            <Lightbulb size={21} />
          </span>
          <h3>Context is everything.</h3>
          <p>
            Pakvote responses are self-selected, voluntary and unweighted. Gender and location fields
            help describe this audience, but they don’t represent how all Pakistanis feel.
          </p>
        </div>
      </div>
      <section className="insight-breakdowns">
        <div className="insight-region-card">
          <div className="analytics-card-header">
            <div>
              <span className="eyebrow">02 / A CLOSER LOOK</span>
              <h2>The regional picture</h2>
              <p>Number of participants by self-reported province or territory.</p>
            </div>
            <Globe2 size={23} />
          </div>
          <div className="insight-region-list">
            {results.provinces.length ? (
              results.provinces.map((region, index) => (
                <div key={region.name} className="insight-region-row">
                  <span className="region-rank">{String(index + 1).padStart(2, '0')}</span>
                  <div>
                    <div>
                      <strong>{region.name}</strong>
                      <span>{number(region.total)} votes</span>
                    </div>
                    <i>
                      <b style={{ width: `${(region.total / maxRegion) * 100}%` }} />
                    </i>
                  </div>
                </div>
              ))
            ) : (
              <p>No regional responses yet.</p>
            )}
          </div>
        </div>
        <div className="insight-gender-card">
          <div className="analytics-card-header">
            <div>
              <span className="eyebrow">WHO PARTICIPATED</span>
              <h2>By gender</h2>
              <p>Voluntary demographic profile of this poll’s participants.</p>
            </div>
            <UsersRound size={23} />
          </div>
          <div className="gender-visual">
            <div className="gender-visual-big">
              <strong>{number(total)}</strong>
              <span>responses</span>
            </div>
            {['Male', 'Female', 'Other'].map((name, index) => {
              const row = results.gender.find((item) => item.name === name);
              return (
                <div className="gender-visual-row" key={name}>
                  <span>
                    <i className={`gender-dot gender-dot-${index}`} />
                    {name}
                  </span>
                  <strong>{number(row?.total || 0)}</strong>
                  <div>
                    <b
                      className={`gender-bar gender-bar-${index}`}
                      style={{ width: `${total ? ((row?.total || 0) / total) * 100 : 0}%` }}
                    />
                  </div>
                  <small>{percent(total ? ((row?.total || 0) / total) * 100 : 0)}</small>
                </div>
              );
            })}
          </div>
        </div>
      </section>
      <section className="insight-district">
        <div className="analytics-card-header">
          <div>
            <span className="eyebrow">03 / HYPERLOCAL PULSE</span>
            <h2>Districts in focus</h2>
            <p>Districts with the most responses, from across the selected poll.</p>
          </div>
          <MapPin size={23} />
        </div>
        <div className="district-grid">
          {topDistricts.length ? (
            topDistricts.map((district, i) => (
              <div className="district-tile" key={district.name}>
                <div>
                  <span>{String(i + 1).padStart(2, '0')}</span>
                  <strong>{district.name}</strong>
                  <em>{number(district.total)} votes</em>
                </div>
                <i>
                  <b style={{ width: `${(district.total / maxDistrict) * 100}%` }} />
                </i>
              </div>
            ))
          ) : (
            <p>District data will appear here after people vote.</p>
          )}
        </div>
        <Link href={`/results?poll=${encodeURIComponent(poll.slug)}`} className="text-link">
          Explore the full district breakdown <ArrowUpRight size={17} />
        </Link>
      </section>
      <div className="insights-ad">
        <AdSlot size="horizontal" label="A place for your message" />
      </div>
      <section className="other-conversations">
        <div className="section-heading">
          <div>
            <span className="eyebrow">04 / EXPLORE MORE</span>
            <h2>
              One country. <span className="highlight-text">Many conversations.</span>
            </h2>
            <p>Compare the scale of participation across topics; each poll asks a different question.</p>
          </div>
          <Link href="/elections" className="section-action">
            See every poll <ArrowUpRight size={17} />
          </Link>
        </div>
        <div className="other-insight-grid">
          {polls
            .filter((item) => item.status !== 'draft')
            .map((item) => (
              <Link
                key={item.id}
                href={`/insights?poll=${encodeURIComponent(item.slug)}`}
                className={`other-insight-card ${item.id === poll.id ? 'other-insight-current' : ''}`}
              >
                <span>{kindLabels[item.kind]}</span>
                <h3>{item.title}</h3>
                <div>
                  <strong>{number(item.totalVotes || 0)}</strong>
                  <small>voices heard</small>
                  <ArrowUpRight size={18} />
                </div>
              </Link>
            ))}
        </div>
      </section>
      <section className="analysis-note">
        <Info size={22} />
        <div>
          <h3>A note on interpretation</h3>
          <p>
            These are voluntary online responses from people who visited Pakvote. Results are not
            adjusted for age, gender, region or turnout, and can’t be generalized to the Pakistani
            population. We show aggregated counts, not individual ballots or contact information. The
            comparison of survey responses is descriptive, not causal.
          </p>
          <Link href="/about#how-it-works">
            Read how Pakvote works <ArrowRight size={15} />
          </Link>
        </div>
      </section>
    </div>
  );
}
