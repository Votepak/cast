'use client';
import Link from 'next/link';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  ChartNoAxesCombined,
  Check,
  ChevronDown,
  ChevronRight,
  CircleDot,
  Clock3,
  Download,
  Filter,
  Globe2,
  Info,
  ListFilter,
  MapPin,
  MoveUpRight,
  PieChart,
  RefreshCcw,
  Sparkles,
  Table2,
  TrendingUp,
  Trophy,
  UsersRound,
} from 'lucide-react';
import type { BreakdownRow, OptionResult, Poll, PollResults } from '@/lib/types';
import { GENDERS, REGIONS } from '@/lib/regions';
import { getPollStatus, kindLabels, localDate, number, percent } from '@/lib/utils';
import { AdSlot, DemoNotice, ShareBar, TrendChart } from './Shared';

type ChartMode = 'total' | 'gender' | 'province' | 'district' | 'percentage';
const chartModes: { key: ChartMode; label: string }[] = [
  { key: 'total', label: 'Total votes' },
  { key: 'gender', label: 'By gender' },
  { key: 'province', label: 'By province' },
  { key: 'district', label: 'By district' },
  { key: 'percentage', label: 'Percentages' },
];

function GraphLegend({ options }: { options: OptionResult[] }) {
  return (
    <div className="graph-legend">
      {options.map((option) => (
        <span key={option.id}>
          <i style={{ background: option.color }} />
          {option.shortLabel}
        </span>
      ))}
    </div>
  );
}

function StackedGraph({
  rows,
  options,
  limit,
}: {
  rows: BreakdownRow[];
  options: OptionResult[];
  limit?: number;
}) {
  const visible = limit ? rows.slice(0, limit) : rows;
  if (!visible.length)
    return (
      <div className="chart-empty">
        <BarChart3 size={29} />
        <strong>Nothing to chart just yet.</strong>
        <span>Results will appear as people cast their votes.</span>
      </div>
    );
  return (
    <div className="stacked-graph">
      {visible.map((row) => (
        <div className="stacked-row" key={row.name}>
          <div className="stacked-label">
            <span title={row.name}>{row.name}</span>
            <strong>{number(row.total)} votes</strong>
          </div>
          <div className="stacked-track">
            {options.map((option) => {
              const count = row.options.find((item) => item.optionId === option.id)?.votes || 0;
              return count > 0 ? (
                <span
                  key={option.id}
                  title={`${option.label}: ${number(count)} votes`}
                  style={{ background: option.color, width: `${(count / row.total) * 100}%` }}
                />
              ) : null;
            })}
          </div>
        </div>
      ))}
      <GraphLegend options={options} />
    </div>
  );
}

export function ResultsExplorer({
  polls,
  poll,
  initialResults,
  demo,
}: {
  polls: Poll[];
  poll: Poll;
  initialResults: PollResults;
  demo: boolean;
}) {
  const router = useRouter();
  const [results, setResults] = useState(initialResults);
  const [gender, setGender] = useState('');
  const [province, setProvince] = useState('');
  const [district, setDistrict] = useState('');
  const [mode, setMode] = useState<ChartMode>('total');
  const [showDistricts, setShowDistricts] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [loadError, setLoadError] = useState('');
  const load = useCallback(
    async (signal?: AbortSignal) => {
      try {
        const params = new URLSearchParams({ pollId: poll.id });
        if (gender) params.set('gender', gender);
        if (province) params.set('province', province);
        if (district) params.set('district', district);
        const response = await fetch(`/api/results?${params}`, { cache: 'no-store', signal });
        if (!response.ok) throw new Error('Could not refresh results. Please try again.');
        const data = await response.json();
        setResults(data.results);
        setLoadError('');
      } catch (error) {
        if (error instanceof Error && error.name !== 'AbortError') setLoadError(error.message);
      }
    },
    [poll.id, gender, province, district],
  );
  useEffect(() => {
    const controller = new AbortController();
    if (gender || province || district) void load(controller.signal);
    const id = window.setInterval(() => {
      if (!document.hidden) void load();
    }, 20000);
    return () => {
      controller.abort();
      window.clearInterval(id);
    };
  }, [load, gender, province, district]);
  const sorted = useMemo(
    () => [...results.options].sort((a, b) => b.votes - a.votes),
    [results.options],
  );
  const top = results.leader;
  const second = sorted[1];
  const hasFilter = Boolean(gender || province || district);
  const displayRows =
    mode === 'gender'
      ? ['Male', 'Female', 'Other']
          .map(
            (name) => results.gender.find((row) => row.name === name) || { name, total: 0, options: [] },
          )
          .filter((row) => row.total)
      : mode === 'province'
        ? results.provinces
        : results.districts;
  const conic = (() => {
    let start = 0;
    return (
      sorted
        .map((option) => {
          const end = start + option.percentage;
          const part = `${option.color} ${start}% ${end}%`;
          start = end;
          return part;
        })
        .join(', ') || '#e5ede7 0% 100%'
    );
  })();
  const status = getPollStatus(poll);
  return (
    <div className="container page-content results-page">
      <div className="breadcrumbs breadcrumb-dark">
        <Link href="/">Home</Link>
        <ChevronRight size={13} /> Live results
      </div>
      <div className="results-hero">
        <div>
          <span className="eyebrow">THE NUMBERS SPEAK</span>
          <h1>
            Every voice.
            <br />
            <span>Every angle.</span>
          </h1>
          <p>
            Follow the live count and explore what people are saying — by option, gender, province and
            district.
          </p>
          <span className="results-caveat">
            <Info size={15} /> Unofficial, self-selected public opinion. Not election results.
          </span>
        </div>
        <div className="results-hero-icon">
          <ChartNoAxesCombined size={92} strokeWidth={1} />
          <span>PAKVOTE / ANALYTICS</span>
        </div>
      </div>
      {demo && <DemoNotice compact />}
      <div className="results-toolbar">
        <div className="poll-select-wrap">
          <label htmlFor="results-poll">EXPLORE RESULTS FOR</label>
          <div className="select-wrap">
            <select
              id="results-poll"
              value={poll.slug}
              onChange={(event) =>
                router.push(`/results?poll=${encodeURIComponent(event.target.value)}`)
              }
            >
              {polls.map((item) => (
                <option key={item.id} value={item.slug}>
                  {item.title}
                </option>
              ))}
            </select>
            <ChevronDown size={17} />
          </div>
        </div>
        <div className="results-toolbar-meta">
          <span className={`status-tag status-${status}`}>
            <span className="live-dot" /> {status === 'active' ? 'LIVE POLL' : status.toUpperCase()}
          </span>
          <span className="refreshed-text">
            <RefreshCcw size={14} /> Refreshes every 20 seconds
          </span>
        </div>
      </div>
      <div className="results-summary">
        <div className="results-leader-card">
          <div className="leader-card-top">
            <span>
              {poll.kind === 'election'
                ? status === 'ended'
                  ? 'WINNING PARTY'
                  : 'CURRENTLY LEADING PARTY'
                : status === 'ended'
                  ? 'TOP CHOICE · FINAL'
                  : 'CURRENTLY LEADING'}
            </span>
            <Trophy size={22} />
          </div>
          <strong>{results.isTie ? 'It’s a tie' : top?.label || 'Awaiting votes'}</strong>
          <div className="leader-card-bottom">
            <span>{hasFilter ? 'In this selection' : 'Across all responses'}</span>
            <span>
              {top
                ? `${number(top.votes)} votes · ${percent(top.percentage)}`
                : 'Be the first to participate'}
            </span>
          </div>
          <div className="leader-accent" />
        </div>
        <div className="summary-small">
          <span className="summary-small-icon green">
            <UsersRound size={24} />
          </span>
          <small>TOTAL VOTES CAST</small>
          <strong>{number(results.totalVotes)}</strong>
          <span>In this poll, across all regions</span>
        </div>
        <div className="summary-small">
          <span className="summary-small-icon amber">
            <PieChart size={24} />
          </span>
          <small>{hasFilter ? 'MATCHING RESPONSES' : 'LEADING SHARE'}</small>
          <strong>
            {hasFilter ? number(results.filteredVotes) : top ? percent(top.percentage) : '—'}
          </strong>
          <span>
            {hasFilter ? 'Based on your filters' : top ? `For ${top.shortLabel}` : 'No votes yet'}
          </span>
        </div>
      </div>
      <div className="filter-panel">
        <div className="filter-panel-title">
          <span>
            <ListFilter size={18} /> Refine the data
          </span>
          <p>Filter results to see perspectives from a specific group or place.</p>
        </div>
        <div className="filter-controls">
          <div className="field">
            <label htmlFor="filter-gender">Gender</label>
            <div className="select-wrap">
              <select
                id="filter-gender"
                value={gender}
                onChange={(event) => setGender(event.target.value)}
              >
                <option value="">All genders</option>
                {GENDERS.map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </select>
              <ChevronDown size={15} />
            </div>
          </div>
          <div className="field">
            <label htmlFor="filter-province">Province / territory</label>
            <div className="select-wrap">
              <select
                id="filter-province"
                value={province}
                onChange={(event) => {
                  setProvince(event.target.value);
                  setDistrict('');
                }}
              >
                <option value="">All regions</option>
                {Object.keys(REGIONS).map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </select>
              <ChevronDown size={15} />
            </div>
          </div>
          <div className="field">
            <label htmlFor="filter-district">District</label>
            <div className="select-wrap">
              <select
                id="filter-district"
                value={district}
                onChange={(event) => setDistrict(event.target.value)}
                disabled={!province}
              >
                <option value="">{province ? 'All districts' : 'Select region first'}</option>
                {(REGIONS[province] || []).map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </select>
              <ChevronDown size={15} />
            </div>
          </div>
          {hasFilter && (
            <button
              className="clear-filters"
              onClick={() => {
                setGender('');
                setProvince('');
                setDistrict('');
                setResults(initialResults);
              }}
            >
              Clear filters <ArrowRight size={14} />
            </button>
          )}
        </div>
        {loadError && (
          <div role="alert" className="form-error">
            {loadError}
          </div>
        )}
      </div>
      <div className="analytics-layout">
        <div className="analytics-main">
          <section className="analytics-card graph-card">
            <div className="analytics-card-header">
              <div>
                <span className="eyebrow">VISUAL BREAKDOWN</span>
                <h2>
                  {mode === 'total'
                    ? 'Votes at a glance'
                    : mode === 'gender'
                      ? 'By gender'
                      : mode === 'province'
                        ? 'By province & territory'
                        : mode === 'district'
                          ? 'By district'
                          : 'Share of responses'}
                </h2>
                <p>
                  {number(results.filteredVotes)} {hasFilter ? 'matching responses' : 'total responses'}{' '}
                  in this view
                </p>
              </div>
              <BarChart3 size={23} />
            </div>
            <div className="chart-tabs" role="tablist" aria-label="Choose chart breakdown">
              {chartModes.map((item) => (
                <button
                  type="button"
                  key={item.key}
                  role="tab"
                  aria-selected={mode === item.key}
                  className={mode === item.key ? 'chart-tab-active' : ''}
                  onClick={() => setMode(item.key)}
                >
                  {item.label}
                </button>
              ))}
            </div>
            {mode === 'total' && (
              <div className="total-graph">
                {sorted.map((option, index) => (
                  <div className="total-graph-row" key={option.id}>
                    <div className="total-graph-label">
                      <span>
                        <i style={{ background: option.color }} />
                        {option.label}
                      </span>
                      <strong>
                        {number(option.votes)} <small>votes</small>
                      </strong>
                    </div>
                    <div className="total-track">
                      <span style={{ width: `${option.percentage}%`, background: option.color }} />
                    </div>
                    <div className="total-graph-percent">{percent(option.percentage)}</div>
                  </div>
                ))}
                {!results.filteredVotes && (
                  <p className="no-votes-caption">The first vote will bring this chart to life.</p>
                )}
              </div>
            )}
            {mode === 'gender' && (
              <>
                <p className="graph-explanation">
                  How each group’s responses are distributed across the options.
                </p>
                <StackedGraph rows={displayRows} options={results.options} />
              </>
            )}
            {mode === 'province' && (
              <>
                <p className="graph-explanation">
                  Where participants say they are based. These are self-reported locations.
                </p>
                <StackedGraph rows={displayRows} options={results.options} />
              </>
            )}
            {mode === 'district' && (
              <>
                <p className="graph-explanation">
                  {province
                    ? `Districts within ${province}`
                    : 'Top participating districts nationwide. Select a province to explore its districts.'}
                </p>
                <StackedGraph
                  rows={displayRows}
                  options={results.options}
                  limit={showDistricts ? undefined : 12}
                />
                {displayRows.length > 12 && (
                  <button className="chart-more" onClick={() => setShowDistricts((value) => !value)}>
                    {showDistricts
                      ? 'Show fewer districts'
                      : `Show all ${number(displayRows.length)} districts`}{' '}
                    <ChevronDown size={15} />
                  </button>
                )}
              </>
            )}
            {mode === 'percentage' && (
              <div className="donut-layout">
                <div
                  className="donut-graph"
                  style={{ background: results.filteredVotes ? `conic-gradient(${conic})` : '#e8efea' }}
                >
                  <div>
                    <strong>{number(results.filteredVotes)}</strong>
                    <span>responses</span>
                  </div>
                </div>
                <div className="donut-list">
                  {sorted.map((option) => (
                    <div key={option.id}>
                      <span>
                        <i style={{ background: option.color }} />
                        {option.label}
                      </span>
                      <strong>{percent(option.percentage)}</strong>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div className="graph-footnote">
              <Info size={16} /> Percentages are calculated for the responses shown after filters. Totals
              may not add to exactly 100% due to rounding.
            </div>
          </section>
          <section className="analytics-card vote-table-card">
            <div className="analytics-card-header">
              <div>
                <span className="eyebrow">THE TRANSPARENT PAKVOTE COUNT</span>
                <h2>
                  {poll.kind === 'election' ? 'Vote counting by party' : 'Vote counting by option'}
                </h2>
                <p>A clear look at every option, counted as votes are submitted.</p>
              </div>
              <Table2 size={22} />
            </div>
            <div className="table-scroll">
              <table className="results-table">
                <thead>
                  <tr>
                    <th scope="col">RANK</th>
                    <th scope="col">
                      {poll.kind === 'election' ? 'PARTY / OPTION' : 'ANSWER / OPTION'}
                    </th>
                    <th scope="col">VOTES</th>
                    <th scope="col">SHARE</th>
                  </tr>
                </thead>
                <tbody>
                  {sorted.map((option, index) => (
                    <tr key={option.id}>
                      <td>
                        <span
                          className={`table-rank ${index === 0 && results.filteredVotes ? 'rank-first' : ''}`}
                        >
                          {String(index + 1).padStart(2, '0')}
                        </span>
                      </td>
                      <td>
                        <span className="table-option-dot" style={{ background: option.color }} />
                        {option.label}
                      </td>
                      <td className="table-count">{number(option.votes)}</td>
                      <td>
                        <div className="table-share">
                          <span>{percent(option.percentage)}</span>
                          <i>
                            <b style={{ width: `${option.percentage}%`, background: option.color }} />
                          </i>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan={2}>TOTAL RESPONSES {hasFilter ? '(FILTERED)' : ''}</td>
                    <td className="table-count">{number(results.filteredVotes)}</td>
                    <td>100%</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </section>
          <section className="analytics-card trend-card">
            <div className="analytics-card-header">
              <div>
                <span className="eyebrow">PARTICIPATION OVER TIME</span>
                <h2>Momentum of the conversation</h2>
                <p>Daily responses across the past two weeks, based on your current filters.</p>
              </div>
              <TrendingUp size={23} />
            </div>
            <TrendChart daily={results.daily} />
          </section>
        </div>
        <aside className="analytics-aside">
          <div className="insight-summary">
            <span className="eyebrow eyebrow-light">READING THE DATA</span>
            <h3>What do these numbers say?</h3>
            {results.filteredVotes && top ? (
              <>
                <p>
                  {results.isTie && second ? (
                    <>
                      <strong>{top.shortLabel}</strong> and <strong>{second.shortLabel}</strong> are tied
                      for the lead with <strong>{number(top.votes)} votes</strong> each. There is no sole
                      leading choice.
                    </>
                  ) : (
                    <>
                      <strong>{top.label}</strong> is currently{' '}
                      {status === 'ended' ? 'the top choice' : 'leading'} with{' '}
                      <strong>{number(top.votes)} votes</strong> ({percent(top.percentage)}).
                      {second
                        ? ` The margin over ${second.shortLabel} is ${number(top.votes - second.votes)} votes.`
                        : ''}
                    </>
                  )}
                </p>
                {results.provinces.length > 0 && (
                  <p>
                    The most participation in this view comes from{' '}
                    <strong>{results.provinces[0].name}</strong> ({number(results.provinces[0].total)}{' '}
                    votes).
                  </p>
                )}
                {results.gender.length > 0 && (
                  <p>
                    Responses include{' '}
                    <strong>
                      {results.gender
                        .map((row) => `${number(row.total)} ${row.name.toLowerCase()}`)
                        .join(', ')}
                    </strong>{' '}
                    participants.
                  </p>
                )}
              </>
            ) : (
              <p>
                There are no responses for this selection yet. Choose different filters or check back as
                the conversation grows.
              </p>
            )}
            <div className="insight-summary-note">
              <Info size={16} />
              <span>These insights describe visitors who voted, not all residents of Pakistan.</span>
            </div>
          </div>
          <div className="region-highlight">
            <span className="eyebrow">REGION SPOTLIGHT</span>
            <h3>Where people are participating</h3>
            {results.provinces.slice(0, 4).map((row, index) => (
              <div className="region-item" key={row.name}>
                <span>0{index + 1}</span>
                <strong>{row.name}</strong>
                <em>{number(row.total)}</em>
              </div>
            ))}
            {!results.provinces.length && <p>Location data will appear as people vote.</p>}
          </div>
          <div className="share-results">
            <span className="eyebrow">SPREAD THE WORD</span>
            <h3>Invite more perspectives.</h3>
            <p>The more people participate, the more interesting the picture gets.</p>
            <ShareBar title={poll.title} url={`/elections/${poll.slug}`} compact />
          </div>
          <AdSlot size="square" label="Your message belongs here" />
        </aside>
      </div>
      <div className="results-bottom">
        <div>
          <span className="eyebrow">KEEP THE CONVERSATION GROWING</span>
          <h2>Know someone with an opinion?</h2>
          <p>Share this poll and invite them to make their own choice.</p>
          <ShareBar title={poll.title} url={`/elections/${poll.slug}`} />
        </div>
        <div>
          <Link href={`/elections/${poll.slug}`} className="button button-primary">
            Go to the ballot <ArrowUpRight size={17} />
          </Link>
          {status === 'ended' && poll.status !== 'draft' && (
            <a
              className="button button-outline"
              href={`/api/results/download?pollId=${encodeURIComponent(poll.id)}`}
            >
              <Download size={17} /> Download final CSV
            </a>
          )}
        </div>
      </div>
      <div className="methodology-note">
        <Info size={17} />
        <span>
          <strong>Important context:</strong> Pakvote runs independent, voluntary online opinion polls.
          Results are not official election returns, are not weighted, and should not be treated as
          representative of Pakistan’s population. We publish aggregate counts only.
        </span>
      </div>
    </div>
  );
}
