'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Fingerprint,
  LockKeyhole,
  Mail,
  ShieldCheck,
  UsersRound,
  Vote,
} from 'lucide-react';
import type { Poll } from '@/lib/types';
import { getPollStatus, localDate } from '@/lib/utils';
import { useAuth } from './AuthProvider';

export function AccountClient() {
  const { user, loading, openAuth, logout } = useAuth();
  const [polls, setPolls] = useState<Poll[]>([]);
  useEffect(() => {
    fetch('/api/polls')
      .then((r) => r.json())
      .then((data) => setPolls(data.polls || []))
      .catch(() => {});
  }, []);
  return (
    <div className="container page-content account-page">
      <div className="breadcrumbs breadcrumb-dark">
        <Link href="/">Home</Link>
        <ChevronRight size={13} /> My account
      </div>
      <div className="account-page-head">
        <span className="eyebrow">YOUR PAKVOTE SPACE</span>
        <h1>
          My account<span>.</span>
        </h1>
        <p>A home for the conversations you’ve joined and the results you’ve asked for.</p>
      </div>
      {loading ? (
        <div className="account-loading">Checking your account…</div>
      ) : !user ? (
        <div className="account-signin">
          <span className="account-signin-icon">
            <LockKeyhole size={28} />
          </span>
          <h2>Your voice is one step away.</h2>
          <p>
            Verify your email to cast your vote, track participation and receive final results files.
          </p>
          <button className="button button-primary" onClick={() => openAuth()}>
            Sign in with email <ArrowRight size={17} />
          </button>
          <div className="account-perks">
            <span>
              <ShieldCheck size={16} /> Email verified
            </span>
            <span>
              <Fingerprint size={16} /> One vote per poll
            </span>
            <span>
              <Mail size={16} /> Final results by request
            </span>
          </div>
        </div>
      ) : (
        <div className="account-grid">
          <div className="account-profile">
            <div className="profile-avatar">{user.email.slice(0, 1).toUpperCase()}</div>
            <span className="eyebrow">VERIFIED ACCOUNT</span>
            <h2>Welcome back.</h2>
            <p>{user.email}</p>
            <span className="verified-pill">
              <CheckCircle2 size={15} /> Verified email
            </span>
            <div className="profile-divider" />
            <div className="profile-stat">
              <span>Joined</span>
              <strong>{localDate(user.createdAt, { hour: undefined, minute: undefined })}</strong>
            </div>
            <div className="profile-stat">
              <span>Polls you’ve voted in</span>
              <strong>{user.votedPollIds.length}</strong>
            </div>
            <div className="profile-stat">
              <span>Results emails requested</span>
              <strong>{user.subscribedPollIds.length}</strong>
            </div>
            <button className="button button-outline button-full" onClick={() => void logout()}>
              Sign out <ArrowRight size={17} />
            </button>
            <p className="account-security">
              Your individual votes aren’t shown here or to other visitors. We only show that you
              participated.
            </p>
          </div>
          <div className="account-activity">
            <div className="account-section">
              <div className="account-section-title">
                <div>
                  <span className="eyebrow">YOUR PARTICIPATION</span>
                  <h2>Polls you’ve joined</h2>
                </div>
                <Vote size={23} />
              </div>
              {user.votedPollIds.length ? (
                user.votedPollIds.map((id) => {
                  const poll = polls.find((item) => item.id === id);
                  return poll ? (
                    <div className="account-poll" key={id}>
                      <div>
                        <span className="account-voted-label">
                          <Check size={13} /> VOTED
                        </span>
                        <h3>{poll.title}</h3>
                        <p>{poll.question}</p>
                      </div>
                      <Link href={`/results?poll=${poll.slug}`} className="account-poll-link">
                        See results <ArrowUpRight size={16} />
                      </Link>
                    </div>
                  ) : null;
                })
              ) : (
                <div className="account-empty">
                  <Vote size={25} />
                  <strong>No ballots cast yet</strong>
                  <p>Make your first choice in a live poll.</p>
                  <Link href="/elections">
                    Explore polls <ArrowUpRight size={15} />
                  </Link>
                </div>
              )}
            </div>
            <div className="account-section">
              <div className="account-section-title">
                <div>
                  <span className="eyebrow">RESULTS IN YOUR INBOX</span>
                  <h2>Email subscriptions</h2>
                </div>
                <Mail size={23} />
              </div>
              {user.subscribedPollIds.length ? (
                user.subscribedPollIds.map((id) => {
                  const poll = polls.find((item) => item.id === id);
                  return poll ? (
                    <div className="account-poll" key={id}>
                      <div>
                        <span className="account-voted-label">
                          <Mail size={13} /> SUBSCRIBED
                        </span>
                        <h3>{poll.title}</h3>
                        <p>
                          {getPollStatus(poll) === 'ended'
                            ? 'This poll has ended. The results file is available to download.'
                            : 'We’ll email you the final results file when this poll ends.'}
                        </p>
                      </div>
                      {getPollStatus(poll) === 'ended' && (
                        <a href={`/api/results/download?pollId=${id}`} className="account-poll-link">
                          Download CSV <ArrowUpRight size={16} />
                        </a>
                      )}
                    </div>
                  ) : null;
                })
              ) : (
                <div className="account-empty">
                  <Mail size={25} />
                  <strong>No results emails requested</strong>
                  <p>Choose a poll and sign up to receive its final CSV results.</p>
                  <Link href="/elections">
                    Find a poll <ArrowUpRight size={15} />
                  </Link>
                </div>
              )}
            </div>
            <div className="account-privacy">
              <ShieldCheck size={20} />
              <p>
                We keep your email for verification and any results file you request. We never display
                how you voted. <Link href="/privacy">Read our privacy policy →</Link>
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
