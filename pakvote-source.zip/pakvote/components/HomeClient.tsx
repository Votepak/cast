'use client';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  ChartNoAxesCombined,
  Check,
  ChevronRight,
  CircleDot,
  Fingerprint,
  Flag,
  Globe2,
  HeartHandshake,
  Landmark,
  LockKeyhole,
  Mail,
  MapPinned,
  MessageCircle,
  MoveUpRight,
  ShieldCheck,
  Sparkles,
  UsersRound,
  Vote,
} from 'lucide-react';
import type { Poll, PollResults } from '@/lib/types';
import { getPollStatus, kindDescriptions, kindLabels, number, percent } from '@/lib/utils';
import { Ballot, ResultsMini, SubscribeForm } from './Ballot';
import { AdSlot, Countdown, DemoNotice, SectionHeading, ShareBar } from './Shared';

export function HomeClient({
  polls,
  featured,
  initialResults,
  demo,
}: {
  polls: Poll[];
  featured: Poll | null;
  initialResults: PollResults | null;
  demo: boolean;
}) {
  const [results, setResults] = useState(initialResults);
  const [total, setTotal] = useState(polls.reduce((count, poll) => count + (poll.totalVotes || 0), 0));
  const [activeCount, setActiveCount] = useState(
    polls.filter((p) => getPollStatus(p) === 'active').length,
  );
  const refresh = useCallback(async () => {
    if (!featured) return;
    try {
      const [resultsResponse, pollsResponse] = await Promise.all([
        fetch(`/api/results?pollId=${encodeURIComponent(featured.id)}`, { cache: 'no-store' }),
        fetch('/api/polls', { cache: 'no-store' }),
      ]);
      if (resultsResponse.ok) setResults((await resultsResponse.json()).results);
      if (pollsResponse.ok) {
        const data: { polls: Poll[] } = await pollsResponse.json();
        setTotal(data.polls.reduce((count, item) => count + (item.totalVotes || 0), 0));
        setActiveCount(data.polls.filter((item) => getPollStatus(item) === 'active').length);
      }
    } catch {
      /* Keep the last available counts until the next update. */
    }
  }, [featured?.id]);
  useEffect(() => {
    if (!featured) return;
    const timer = window.setInterval(() => {
      if (!document.hidden) void refresh();
    }, 20000);
    return () => window.clearInterval(timer);
  }, [featured, refresh]);
  const otherPolls = polls.filter((p) => p.id !== featured?.id && p.status !== 'draft').slice(0, 3);
  const status = featured ? getPollStatus(featured) : 'draft';
  const provinces = results?.provinces.slice(0, 5) || [];
  const maxProvince = Math.max(...provinces.map((row) => row.total), 1);
  return (
    <>
      <div className="container home-container">
        <section className="hero" aria-labelledby="hero-title">
          <div className="hero-content">
            <div className="hero-kicker">
              <span className="hero-kicker-icon">
                <Sparkles size={14} />
              </span>{' '}
              A BETTER WAY TO BE HEARD <span className="kicker-line" />
            </div>
            <h1 id="hero-title">
              Your voice.
              <br />
              Your vote.
              <br />
              <em>Your Pakistan.</em>
            </h1>
            <p>
              Make your choice. See the bigger picture. Join an open conversation about the future of
              Pakistan — one voice at a time.
            </p>
            <div className="hero-buttons">
              <a href={featured ? '#vote-section' : '/elections'} className="button button-lime">
                <Vote size={19} /> {status === 'active' ? 'Cast your vote' : 'Explore the ballot'}{' '}
                <ArrowUpRight size={17} />
              </a>
              <Link href="/results" className="hero-link">
                Explore live results <ArrowRight size={17} />
              </Link>
            </div>
            <div className="hero-trust">
              <span>
                <ShieldCheck size={17} /> Verified email
              </span>
              <i />
              <span>
                <Fingerprint size={17} /> One vote per browser
              </span>
              <i />
              <span>
                <LockKeyhole size={17} /> Private by design
              </span>
            </div>
          </div>
          <div className="hero-art">
            <img
              src="/images/pakistan-voices.jpg"
              alt="Illustrative scene of Pakistani people with national flags"
              className="hero-photo"
            />
            <div className="hero-photo-tint" />
            <div className="hero-art-top">
              <span className="flag-icon">🇵🇰</span>
              <span>MADE FOR EVERY PAKISTANI</span>
            </div>
            <div className="hero-portrait-panel">
              <span>THE PUBLIC CONVERSATION</span>
              <div className="hero-face-row">
                <img src="/images/imran.jpg" alt="Imran Khan" />
                <img src="/images/nawaz.jpg" alt="Nawaz Sharif" />
                <img src="/images/bilawal.jpg" alt="Bilawal Bhutto Zardari" />
                <span>+ you</span>
              </div>
            </div>
            <div className="hero-bottom-stamp">
              <span className="stamp-ring">✳</span>
              <div>
                <strong>
                  Every perspective
                  <br />
                  belongs here.
                </strong>
                <small>Independent · Inclusive · Open</small>
              </div>
            </div>
          </div>
        </section>
        <div className="hero-stats">
          <div className="hero-stat">
            <div className="stat-icon green">
              <Vote size={20} />
            </div>
            <div>
              <strong>{number(total)}</strong>
              <span>Voices counted</span>
            </div>
          </div>
          <div className="hero-stat">
            <div className="stat-icon purple">
              <CircleDot size={21} />
            </div>
            <div>
              <strong>{number(activeCount).padStart(2, '0')}</strong>
              <span>Live conversations</span>
            </div>
          </div>
          <div className="hero-stat">
            <div className="stat-icon orange">
              <MapPinned size={21} />
            </div>
            <div>
              <strong>{number(results?.provinces.length || 0).padStart(2, '0')}</strong>
              <span>Regions heard from</span>
            </div>
          </div>
          <div className="hero-stat hero-stat-value">
            <div className="stat-icon teal">
              <HeartHandshake size={21} />
            </div>
            <div>
              <strong>Your say matters.</strong>
              <span>Every single vote counts</span>
            </div>
          </div>
        </div>
        {demo && <DemoNotice />}
        <div className="home-ad">
          <AdSlot size="slim" label="Place your message here" />
        </div>
        {featured && results && (
          <section className="section vote-section" id="vote-section">
            <SectionHeading
              eyebrow="01 / THE MAIN BALLOT"
              title={
                <>
                  The choice is <span className="highlight-text">yours.</span>
                </>
              }
              text="A few simple steps. A meaningful place in the conversation."
              action={{ href: `/elections/${featured.slug}`, label: 'About this poll' }}
            />
            <div className="vote-grid">
              <Ballot poll={featured} onVoted={refresh} />
              <div className="vote-sidebar">
                <div className="time-panel">
                  <div className="time-panel-top">
                    <span className="time-panel-icon">
                      <ClockIcon />
                    </span>
                    <span>
                      {status === 'active'
                        ? 'The window is open'
                        : status === 'scheduled'
                          ? 'Coming up soon'
                          : status === 'draft'
                            ? 'Awaiting launch'
                            : 'Poll complete'}
                    </span>
                  </div>
                  <h3>
                    {status === 'active'
                      ? 'The clock is ticking.'
                      : status === 'scheduled'
                        ? 'Get ready to be heard.'
                        : status === 'draft'
                          ? 'The conversation begins soon.'
                          : 'The results are in.'}
                  </h3>
                  <Countdown poll={featured} compact />
                </div>
                <ResultsMini poll={featured} results={results} />
                <AdSlot size="square" label="Space for your brand" />
              </div>
            </div>
          </section>
        )}
        <section className="section discover-section">
          <SectionHeading
            eyebrow="02 / MORE WAYS TO PARTICIPATE"
            title={
              <>
                There’s more to the <span className="highlight-text">conversation.</span>
              </>
            }
            text="Explore perspectives on people, priorities, and the issues shaping everyday life."
            action={{ href: '/elections', label: 'Explore all polls' }}
          />
          <div className="discover-grid">
            {otherPolls.length ? (
              otherPolls.map((poll, index) => (
                <Link
                  key={poll.id}
                  href={`/elections/${poll.slug}`}
                  className={`discover-card discover-card-${index + 1}`}
                >
                  <div className="discover-top">
                    <span className="pill">{kindLabels[poll.kind]}</span>
                    <span className="discover-arrow">
                      <ArrowUpRight size={19} />
                    </span>
                  </div>
                  <div className={`discover-visual discover-${poll.kind}`}>
                    {poll.kind === 'personality' ? (
                      <div className="face-stack">
                        <img src="/images/imran.jpg" alt="Imran Khan" />
                        <img src="/images/nawaz.jpg" alt="Nawaz Sharif" />
                        <img src="/images/bilawal.jpg" alt="Bilawal Bhutto Zardari" />
                      </div>
                    ) : poll.kind === 'comparison' ? (
                      <div className="tenure-visual">
                        <span>2013</span>
                        <i />
                        <span>2018</span>
                        <i />
                        <span>2022</span>
                        <i />
                        <span>NOW</span>
                      </div>
                    ) : (
                      <div className="survey-visual">
                        <span>
                          <BarChart3 size={28} />
                        </span>
                        <span>
                          <Globe2 size={27} />
                        </span>
                        <span>
                          <UsersRound size={26} />
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="discover-bottom">
                    <span className="discover-number">0{index + 1} / POLL</span>
                    <h3>{poll.title}</h3>
                    <p>{kindDescriptions[poll.kind]}</p>
                    <div className="discover-meta">
                      <span>
                        <UsersRound size={15} /> {number(poll.totalVotes || 0)} voices
                      </span>
                      <span>
                        Join in <ArrowRight size={15} />
                      </span>
                    </div>
                  </div>
                </Link>
              ))
            ) : (
              <div className="empty-discover">
                <Vote size={28} />
                <h3>More conversations are on the way.</h3>
                <p>The administrator can launch new surveys, leadership polls and tenure comparisons.</p>
              </div>
            )}
          </div>
        </section>
      </div>
      <section className="insight-teaser">
        <div className="container insight-teaser-grid">
          <div className="insight-teaser-copy">
            <span className="eyebrow">03 / SEE BEYOND THE NUMBERS</span>
            <h2>
              More than votes.
              <br />
              <span>A clearer picture.</span>
            </h2>
            <p>
              Explore every choice from more angles: by gender, province, district, and percentage.
              Follow live counts and understand what the data can — and can’t — tell us.
            </p>
            <div className="insight-checks">
              <span>
                <Check size={15} /> Live, incremental updates
              </span>
              <span>
                <Check size={15} /> Transparent vote counting
              </span>
              <span>
                <Check size={15} /> Interactive demographic breakdowns
              </span>
            </div>
            <Link href="/results" className="button button-dark">
              Explore the dashboard <ArrowUpRight size={17} />
            </Link>
          </div>
          <div className="insight-mock">
            <div className="mock-head">
              <div>
                <span>LIVE ANALYTICS</span>
                <strong>Where the voices are coming from</strong>
              </div>
              <span className="mock-dots">
                <i />
                <i />
                <i />
              </span>
            </div>
            <div className="mock-body">
              <span className="mock-subtitle">Votes by province & territory</span>
              {provinces.length ? (
                provinces.map((row) => (
                  <div className="mock-row" key={row.name}>
                    <span>
                      {row.name === 'Islamabad Capital Territory'
                        ? 'Islamabad'
                        : row.name === 'Khyber Pakhtunkhwa'
                          ? 'Khyber Pakhtunkhwa'
                          : row.name}
                    </span>
                    <div>
                      <i style={{ width: `${Math.max(5, (row.total / maxProvince) * 100)}%` }} />
                    </div>
                    <strong>{number(row.total)}</strong>
                  </div>
                ))
              ) : (
                <div className="mock-empty">Participation breakdowns appear as votes arrive.</div>
              )}
              <div className="mock-foot">
                <span>
                  <span className="live-dot" /> Updating with every vote
                </span>
                <span>7 regions · 1 country</span>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div className="container">
        <div className="home-ad home-ad-late">
          <AdSlot size="horizontal" label="Visibility for great ideas" />
        </div>
        {featured && (
          <section className="newsletter-section">
            <div className="newsletter-decor newsletter-decor-one" />
            <div className="newsletter-decor newsletter-decor-two" />
            <div className="newsletter-icon">
              <Mail size={26} />
            </div>
            <div className="newsletter-copy">
              <span className="eyebrow eyebrow-light">THE FINAL WORD, IN YOUR INBOX</span>
              <h2>
                Get the full story
                <br />
                <em>when voting ends.</em>
              </h2>
              <p>
                Sign up to receive a downloadable CSV of the final totals and demographic breakdowns once
                this poll closes. No noise, just the results.
              </p>
              <SubscribeForm poll={featured} />
            </div>
            <div className="newsletter-aside">
              <div className="file-stack">
                <div />
                <div />
                <div className="file-front">
                  <span className="file-top">PAKVOTE / FINAL REPORT</span>
                  <span className="file-line" />
                  <span className="file-line medium" />
                  <span className="file-line short" />
                  <span className="file-chart">
                    <i />
                    <i />
                    <i />
                    <i />
                    <i />
                  </span>
                  <strong>YOUR RESULTS FILE</strong>
                  <small>CSV · After the poll closes</small>
                </div>
              </div>
            </div>
          </section>
        )}
        <section className="last-section">
          <div>
            <span className="eyebrow">YOUR VOICE HAS A PLACE</span>
            <h2>Be part of the bigger picture.</h2>
            <p>No matter your choice, the conversation is stronger with you in it.</p>
          </div>
          <Link href="/elections" className="button button-primary">
            Find your poll <ArrowUpRight size={17} />
          </Link>
        </section>
      </div>
    </>
  );
}

function ClockIcon() {
  return <span aria-hidden="true">⏱</span>;
}
