'use client';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  ChevronRight,
  CircleHelp,
  Clock3,
  Download,
  Info,
  LockKeyhole,
  MapPin,
  ShieldCheck,
  Sparkles,
  UsersRound,
  Vote,
} from 'lucide-react';
import type { Poll, PollResults } from '@/lib/types';
import { getPollStatus, kindLabels, localDate, number, percent } from '@/lib/utils';
import { Ballot, ResultsMini, SubscribeForm } from './Ballot';
import { AdSlot, Countdown, DemoNotice, ShareBar } from './Shared';

export function PollDetailClient({
  poll,
  initialResults,
  demo,
}: {
  poll: Poll;
  initialResults: PollResults;
  demo: boolean;
}) {
  const [results, setResults] = useState(initialResults);
  const refresh = useCallback(async () => {
    try {
      const response = await fetch(`/api/results?pollId=${encodeURIComponent(poll.id)}`, {
        cache: 'no-store',
      });
      if (response.ok) setResults((await response.json()).results);
    } catch {
      /* Retain the last available result. */
    }
  }, [poll.id]);
  useEffect(() => {
    const timer = window.setInterval(refresh, 20000);
    return () => window.clearInterval(timer);
  }, [refresh]);
  const status = getPollStatus(poll);
  return (
    <div className="container page-content">
      <div className="breadcrumbs breadcrumb-dark">
        <Link href="/">Home</Link>
        <ChevronRight size={13} />
        <Link href="/elections">Elections & polls</Link>
        <ChevronRight size={13} /> {poll.title}
      </div>
      {demo && <DemoNotice compact />}
      <div className="detail-hero">
        <div>
          <span className="eyebrow">{kindLabels[poll.kind].toUpperCase()} / PAKVOTE</span>
          <h1>
            {poll.title}
            <span>.</span>
          </h1>
          <p>{poll.description}</p>
          <div className="detail-meta">
            <span className={`status-tag status-${status}`}>
              <span className="live-dot" /> {status === 'active' ? 'LIVE NOW' : status.toUpperCase()}
            </span>
            <span>
              <UsersRound size={16} /> {number(results.totalVotes)} votes cast
            </span>
            <span>
              <CalendarDays size={16} /> {localDate(poll.endsAt)} PKT
            </span>
          </div>
        </div>
        <div className="detail-hero-mark">
          <Vote size={70} strokeWidth={1.2} />
          <span>YOUR SAY / YOUR WAY</span>
        </div>
      </div>
      <div className="detail-layout">
        <div className="detail-main">
          <Ballot poll={poll} onVoted={refresh} spacious />
          <div className="detail-explainer">
            <span className="eyebrow">GOOD TO KNOW</span>
            <h2>How your vote works</h2>
            <div className="explain-steps">
              <div>
                <span>
                  <ShieldCheck size={21} />
                </span>
                <h3>Verified email</h3>
                <p>A six-digit code helps ensure every account belongs to a real inbox.</p>
              </div>
              <div>
                <span>
                  <LockKeyhole size={21} />
                </span>
                <h3>One choice per poll</h3>
                <p>Your account and browser can each submit only one ballot per poll.</p>
              </div>
              <div>
                <span>
                  <MapPin size={21} />
                </span>
                <h3>Only aggregate data</h3>
                <p>Region and gender power the charts. Your individual choice is never shown.</p>
              </div>
            </div>
          </div>
          <div className="detail-method">
            <Info size={19} />
            <p>
              This is a voluntary online public-opinion poll, not a nationally representative survey or
              an official election. Votes reflect participants who chose to visit Pakvote.
            </p>
          </div>
        </div>
        <aside className="detail-aside">
          <div className="detail-countdown">
            <span className="eyebrow">THE VOTING WINDOW</span>
            <Countdown poll={poll} compact />
            <div className="detail-timing">
              <span>
                Opens <strong>{localDate(poll.startsAt)} PKT</strong>
              </span>
              <span>
                Closes <strong>{localDate(poll.endsAt)} PKT</strong>
              </span>
            </div>
          </div>
          <ResultsMini poll={poll} results={results} />
          <div className="detail-share">
            <h3>Pass the mic.</h3>
            <p>Invite people to share their own perspective.</p>
            <ShareBar title={poll.title} url={`/elections/${poll.slug}`} />
          </div>
          <AdSlot size="square" label="An opportunity to be seen" />
        </aside>
      </div>
      <section className="detail-results-link">
        <div>
          <span className="eyebrow">FOLLOW THE CONVERSATION</span>
          <h2>The numbers, from every angle.</h2>
          <p>
            Explore party totals, percentages, gender, province and district in the results dashboard.
          </p>
        </div>
        <Link href={`/results?poll=${encodeURIComponent(poll.slug)}`} className="button button-primary">
          View full results <ArrowUpRight size={17} />
        </Link>
      </section>
      <div className="detail-subscribe">
        <div>
          <span className="eyebrow">RESULTS IN YOUR INBOX</span>
          <h2>Get the final results file.</h2>
          <p>We’ll send a CSV of the final totals and regional breakdowns after this poll closes.</p>
        </div>
        <SubscribeForm poll={poll} standalone />
      </div>
    </div>
  );
}
