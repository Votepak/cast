'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleHelp,
  Clock3,
  Fingerprint,
  LoaderCircle,
  LockKeyhole,
  MapPin,
  ShieldCheck,
  Vote,
} from 'lucide-react';
import type { Poll, PollResults } from '@/lib/types';
import { GENDERS, REGIONS } from '@/lib/regions';
import { getPollStatus, localDate, number, percent } from '@/lib/utils';
import { api, useAuth } from './AuthProvider';
import { Countdown, ShareBar } from './Shared';

export function Ballot({
  poll,
  onVoted,
  spacious = false,
}: {
  poll: Poll;
  onVoted?: () => void;
  spacious?: boolean;
}) {
  const { user, openAuth, refreshUser, toast } = useAuth();
  const [selection, setSelection] = useState('');
  const [gender, setGender] = useState('');
  const [province, setProvince] = useState('');
  const [district, setDistrict] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [clock, setClock] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setClock(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);
  const status = getPollStatus(poll, clock || Date.now());
  const voted = submitted || Boolean(user?.votedPollIds.includes(poll.id));
  const resultUrl = `/results?poll=${encodeURIComponent(poll.slug)}`;

  const castVote = async () => {
    setBusy(true);
    setError('');
    try {
      const result = await api<{ message: string }>('/api/vote', {
        method: 'POST',
        body: JSON.stringify({ pollId: poll.id, optionId: selection, gender, province, district }),
      });
      setSubmitted(true);
      await refreshUser();
      onVoted?.();
      toast(result.message);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save your vote.');
    } finally {
      setBusy(false);
    }
  };
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (!selection) {
      setError('Please choose an option before submitting.');
      return;
    }
    if (!gender || !province || !district) {
      setError('Please select your gender, province and district.');
      return;
    }
    if (status !== 'active') {
      setError('Voting is not open right now.');
      return;
    }
    if (!user)
      openAuth(() => {
        void castVote();
      });
    else void castVote();
  };
  return (
    <div className={`ballot-card ${spacious ? 'ballot-spacious' : ''}`} id="vote">
      <div className="ballot-top">
        <span className="eyebrow">YOUR BALLOT · {poll.kind.toUpperCase()}</span>
        <span className="ballot-secure">
          <LockKeyhole size={14} /> Private & secure
        </span>
      </div>
      <h3>{poll.question}</h3>
      <p className="ballot-description">
        Select one option. Your vote is final and cannot be changed after submission.
      </p>
      {voted ? (
        <div className="voted-state">
          <span className="voted-icon">
            <CheckCircle2 size={34} />
          </span>
          <h4>Your voice has been counted.</h4>
          <p>
            Thank you for taking part. Your choice stays private; only combined results are published.
          </p>
          <Link href={resultUrl} className="button button-primary">
            Explore live results <ArrowUpRight size={16} />
          </Link>
          <ShareBar title={poll.title} url={`/elections/${poll.slug}`} compact />
        </div>
      ) : (
        <>
          <form onSubmit={submit}>
            <div className="ballot-options" role="radiogroup" aria-label={poll.question}>
              {poll.options.map((option, index) => (
                <label
                  key={option.id}
                  className={`option-row ${selection === option.id ? 'option-selected' : ''}`}
                  style={{ '--option-color': option.color } as React.CSSProperties}
                >
                  <input
                    type="radio"
                    name={`poll-${poll.id}`}
                    value={option.id}
                    checked={selection === option.id}
                    onChange={() => {
                      setSelection(option.id);
                      setError('');
                    }}
                    disabled={status !== 'active'}
                  />
                  <span className="option-number">{String(index + 1).padStart(2, '0')}</span>
                  <span
                    className="option-symbol"
                    style={{ background: `${option.color}23`, color: option.color }}
                  >
                    {option.shortLabel.slice(0, 2).toUpperCase()}
                  </span>
                  <span className="option-name">{option.label}</span>
                  <span className="option-radio">
                    <Check size={13} />
                  </span>
                </label>
              ))}
            </div>
            <div className="voter-details">
              <div className="voter-details-head">
                <span className="details-icon">
                  <MapPin size={16} />
                </span>
                <div>
                  <strong>A little about you</strong>
                  <span>Only used for aggregate statistics</span>
                </div>
              </div>
              <div className="details-grid">
                <div className="field">
                  <label htmlFor={`gender-${poll.id}`}>Gender</label>
                  <div className="select-wrap">
                    <select
                      id={`gender-${poll.id}`}
                      value={gender}
                      onChange={(event) => setGender(event.target.value)}
                      disabled={status !== 'active'}
                      required
                    >
                      <option value="">Select gender</option>
                      {GENDERS.map((item) => (
                        <option key={item}>{item}</option>
                      ))}
                    </select>
                    <ChevronDown size={16} />
                  </div>
                </div>
                <div className="field">
                  <label htmlFor={`province-${poll.id}`}>Province / territory</label>
                  <div className="select-wrap">
                    <select
                      id={`province-${poll.id}`}
                      value={province}
                      onChange={(event) => {
                        setProvince(event.target.value);
                        setDistrict('');
                      }}
                      disabled={status !== 'active'}
                      required
                    >
                      <option value="">Select province</option>
                      {Object.keys(REGIONS).map((item) => (
                        <option key={item}>{item}</option>
                      ))}
                    </select>
                    <ChevronDown size={16} />
                  </div>
                </div>
                <div className="field full-field">
                  <label htmlFor={`district-${poll.id}`}>District</label>
                  <div className="select-wrap">
                    <select
                      id={`district-${poll.id}`}
                      value={district}
                      onChange={(event) => setDistrict(event.target.value)}
                      disabled={status !== 'active' || !province}
                      required
                    >
                      <option value="">{province ? 'Select district' : 'First select province'}</option>
                      {(REGIONS[province] || []).map((item) => (
                        <option key={item}>{item}</option>
                      ))}
                    </select>
                    <ChevronDown size={16} />
                  </div>
                </div>
              </div>
            </div>
            {error && (
              <div className="form-error" role="alert">
                {error}
              </div>
            )}
            {status === 'active' ? (
              <button
                type="submit"
                className="button button-primary button-full vote-button"
                disabled={busy}
              >
                {busy ? (
                  <>
                    <LoaderCircle size={18} className="spin" /> Recording your vote...
                  </>
                ) : (
                  <>
                    <Vote size={19} /> {user ? 'Cast my vote' : 'Verify email & cast my vote'}{' '}
                    <ArrowRight size={18} />
                  </>
                )}
              </button>
            ) : (
              <div className="ballot-unavailable">
                <Clock3 size={20} />
                <span>
                  {status === 'scheduled'
                    ? `Voting opens ${localDate(poll.startsAt)} (PKT).`
                    : status === 'draft'
                      ? 'The administrator has not opened this poll yet.'
                      : 'This poll has closed. You can still explore its results.'}
                </span>
                <Link href={resultUrl}>
                  View results <ArrowRight size={14} />
                </Link>
              </div>
            )}
          </form>
          <p className="ballot-footnote">
            <Fingerprint size={15} /> One verified email and one browser vote per poll.{' '}
            <Link href="/privacy">How we protect your data</Link>
          </p>
        </>
      )}
    </div>
  );
}

export function ResultsMini({ poll, results }: { poll: Poll; results: PollResults }) {
  const ranked = [...results.options].sort((a, b) => b.votes - a.votes);
  const status = getPollStatus(poll);
  return (
    <div className="mini-results-card">
      <div className="mini-results-head">
        <div>
          <span className="eyebrow eyebrow-light">THE PEOPLE'S PULSE</span>
          <h3>Results{status === 'active' && <span className="live-dot" />}</h3>
        </div>
        <span className="mini-live">
          {status === 'active'
            ? 'LIVE'
            : status === 'ended'
              ? 'FINAL'
              : status === 'scheduled'
                ? 'SOON'
                : 'PREVIEW'}
        </span>
      </div>
      <div className="mini-winner">
        <span>{getPollStatus(poll) === 'ended' ? 'TOP CHOICE · FINAL' : 'CURRENTLY LEADING'}</span>
        <strong>
          {results.isTie ? 'A close tie' : results.leader?.shortLabel || 'Your voice is next'}
        </strong>
        <small>
          {results.leader
            ? `${number(results.leader.votes)} votes · ${percent(results.leader.percentage)} of responses`
            : 'Be among the first to participate'}
        </small>
      </div>
      <div className="mini-bars">
        {ranked.map((option) => (
          <div className="mini-bar-row" key={option.id}>
            <div>
              <span className="mini-bar-name">{option.shortLabel}</span>
              <span>{percent(option.percentage)}</span>
            </div>
            <div className="mini-bar-track">
              <span style={{ width: `${option.percentage}%`, background: option.color }} />
            </div>
          </div>
        ))}
      </div>
      <div className="mini-bottom">
        <div>
          <span>Total votes cast</span>
          <strong>{number(results.totalVotes)}</strong>
        </div>
        <Link href={`/results?poll=${encodeURIComponent(poll.slug)}`}>
          Full analysis <ArrowUpRight size={16} />
        </Link>
      </div>
      <div className="mini-disclaimer">Voluntary public opinion · Not official election results</div>
    </div>
  );
}

export function SubscribeForm({ poll, standalone = false }: { poll: Poll; standalone?: boolean }) {
  const { user, openAuth, refreshUser, toast } = useAuth();
  const [email, setEmail] = useState('');
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);
  useEffect(() => {
    if (user?.email && !email) setEmail(user.email);
  }, [user?.email, email]);
  const alreadySubscribed = done || Boolean(user?.subscribedPollIds.includes(poll.id));
  const subscribe = async (address: string) => {
    setBusy(true);
    setError('');
    try {
      const result = await api<{ message: string }>('/api/subscribe', {
        method: 'POST',
        body: JSON.stringify({ pollId: poll.id, email: address, consent: true }),
      });
      setDone(true);
      await refreshUser();
      toast(result.message);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not subscribe.');
    } finally {
      setBusy(false);
    }
  };
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (!consent) {
      setError('Please check the consent box first.');
      return;
    }
    if (user && user.email !== email.trim().toLowerCase()) {
      setError('Please use your verified account email.');
      return;
    }
    if (!user)
      openAuth(() => {
        void subscribe(email.trim().toLowerCase());
      }, email.trim());
    else void subscribe(email.trim().toLowerCase());
  };
  return (
    <div className={`subscribe-form-wrap ${standalone ? 'subscribe-standalone' : ''}`}>
      {alreadySubscribed ? (
        <div className="subscribed-status">
          <CheckCircle2 size={21} /> You’re on the list. We’ll send the final CSV to{' '}
          <strong>{user?.email || email}</strong>.
        </div>
      ) : (
        <form onSubmit={submit}>
          <div className="subscribe-inline">
            <label className="sr-only" htmlFor={`subscribe-email-${poll.id}`}>
              Email for final results file
            </label>
            <input
              id={`subscribe-email-${poll.id}`}
              type="email"
              required
              autoComplete="email"
              placeholder="Enter your email address"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
            <button type="submit" className="button button-primary" disabled={busy}>
              {busy ? (
                <LoaderCircle className="spin" size={17} />
              ) : (
                <>
                  Send me the results <ArrowRight size={16} />
                </>
              )}
            </button>
          </div>
          <label className="consent-line">
            <input
              type="checkbox"
              checked={consent}
              onChange={(event) => setConsent(event.target.checked)}
            />
            <span>
              I agree to receive this poll’s final results file by email.{' '}
              <Link href="/privacy">Privacy details</Link>.
            </span>
          </label>
          {error && (
            <div className="form-error" role="alert">
              {error}
            </div>
          )}
        </form>
      )}
    </div>
  );
}
