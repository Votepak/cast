'use client';
import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  CalendarDays,
  ChevronRight,
  ClipboardList,
  Clock3,
  Filter,
  Flame,
  Landmark,
  Search,
  Sparkles,
  UsersRound,
  Vote,
} from 'lucide-react';
import type { Poll, PollKind } from '@/lib/types';
import { getPollStatus, kindLabels, localDate, number } from '@/lib/utils';
import { AdSlot, DemoNotice, SectionHeading } from './Shared';

const kindFilters: { name: string; value: PollKind | 'all' }[] = [
  { name: 'All polls', value: 'all' },
  { name: 'Party elections', value: 'election' },
  { name: 'Personalities', value: 'personality' },
  { name: 'Govt. comparisons', value: 'comparison' },
  { name: 'Surveys', value: 'survey' },
];
function KindIcon({ kind, size = 21 }: { kind: PollKind; size?: number }) {
  if (kind === 'election') return <Vote size={size} />;
  if (kind === 'personality') return <UsersRound size={size} />;
  if (kind === 'comparison') return <Landmark size={size} />;
  return <ClipboardList size={size} />;
}

export function ElectionsClient({ polls: initialPolls, demo }: { polls: Poll[]; demo: boolean }) {
  const [polls, setPolls] = useState(initialPolls);
  const [kind, setKind] = useState<PollKind | 'all'>('all');
  const [status, setStatus] = useState('all');
  const [query, setQuery] = useState('');
  useEffect(() => {
    const refresh = async () => {
      if (document.hidden) return;
      try {
        const response = await fetch('/api/polls', { cache: 'no-store' });
        if (response.ok) setPolls((await response.json()).polls);
      } catch {
        /* Keep the last available counts. */
      }
    };
    const timer = window.setInterval(() => void refresh(), 30000);
    return () => window.clearInterval(timer);
  }, []);
  const publicPolls = polls.filter((p) => p.status !== 'draft');
  const featured = polls.find((p) => p.isFeatured);
  const visible = useMemo(
    () =>
      publicPolls.filter(
        (p) =>
          (kind === 'all' || p.kind === kind) &&
          (status === 'all' || getPollStatus(p) === status) &&
          (p.title + p.question + p.description).toLowerCase().includes(query.toLowerCase().trim()),
      ),
    [publicPolls, kind, status, query],
  );
  return (
    <div className="container page-content">
      <section className="sub-hero elections-hero">
        <div className="sub-hero-decoration">✳</div>
        <div className="breadcrumbs">
          <Link href="/">Home</Link>
          <ChevronRight size={13} /> Elections & polls
        </div>
        <span className="eyebrow eyebrow-light">THE SPACE TO HAVE YOUR SAY</span>
        <h1>
          Every opinion has
          <br />
          <em>a place here.</em>
        </h1>
        <p>
          Explore independent polls on the people, policies and priorities shaping Pakistan. Choose a
          conversation that speaks to you.
        </p>
        <div className="hero-mini-stats">
          <span>
            <Vote size={16} /> {number(publicPolls.length)} public polls
          </span>
          <span>
            <UsersRound size={16} />{' '}
            {number(publicPolls.reduce((sum, poll) => sum + (poll.totalVotes || 0), 0))} votes cast
          </span>
        </div>
      </section>
      {demo && <DemoNotice />}
      {featured && (
        <section className="featured-poll-card">
          <div className="featured-copy">
            <span className="eyebrow">FEATURED CONVERSATION</span>
            <h2>
              {featured.title}
              <span>.</span>
            </h2>
            <p>{featured.description}</p>
            <div className="featured-metrics">
              <span>
                <span className="live-dot" />{' '}
                {getPollStatus(featured) === 'active'
                  ? 'LIVE NOW'
                  : getPollStatus(featured).toUpperCase()}
              </span>
              <span>
                <UsersRound size={15} /> {number(featured.totalVotes || 0)} voices
              </span>
            </div>
            <Link href={`/elections/${featured.slug}`} className="button button-primary">
              Open the ballot <ArrowUpRight size={16} />
            </Link>
          </div>
          <div className="featured-photo">
            <img
              src="/images/pakistan-voices.jpg"
              alt="Illustrative group of Pakistani people with national flags"
            />
            <div>
              <span>PAKVOTE / 01</span>
              <strong>
                Your voice.
                <br />
                Your Pakistan.
              </strong>
            </div>
          </div>
        </section>
      )}
      <div className="section-heading poll-list-heading">
        <div>
          <span className="eyebrow">EXPLORE THE CONVERSATIONS</span>
          <h2>
            Find your <span className="highlight-text">poll.</span>
          </h2>
          <p>A place for every perspective. Which question will you answer today?</p>
        </div>
      </div>
      <div className="poll-toolbar">
        <div className="filter-chips" aria-label="Filter by poll type">
          {kindFilters.map((item) => (
            <button
              type="button"
              key={item.value}
              className={kind === item.value ? 'chip-active' : ''}
              onClick={() => setKind(item.value)}
            >
              {item.name}
            </button>
          ))}
        </div>
        <div className="poll-toolbar-right">
          <label className="search-field">
            <Search size={18} />
            <input
              type="search"
              placeholder="Search polls"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              aria-label="Search polls"
            />
          </label>
          <div className="select-wrap toolbar-select">
            <Filter size={15} />
            <select
              value={status}
              onChange={(event) => setStatus(event.target.value)}
              aria-label="Filter by status"
            >
              <option value="all">All statuses</option>
              <option value="active">Live now</option>
              <option value="scheduled">Upcoming</option>
              <option value="ended">Completed</option>
            </select>
          </div>
        </div>
      </div>
      {visible.length ? (
        <div className="poll-list-grid">
          {visible.map((poll, index) => (
            <Link className="poll-list-card" href={`/elections/${poll.slug}`} key={poll.id}>
              <div className="poll-list-top">
                <span className={`poll-kind-icon poll-icon-${poll.kind}`}>
                  <KindIcon kind={poll.kind} />
                </span>
                <span className={`status-tag status-${getPollStatus(poll)}`}>
                  <span className="live-dot" />{' '}
                  {getPollStatus(poll) === 'active'
                    ? 'Live now'
                    : getPollStatus(poll) === 'scheduled'
                      ? 'Upcoming'
                      : 'Completed'}
                </span>
              </div>
              <span className="poll-kind-name">{kindLabels[poll.kind]}</span>
              <h3>{poll.title}</h3>
              <p>{poll.question}</p>
              <div className="poll-list-details">
                <span>
                  <UsersRound size={16} /> {number(poll.totalVotes || 0)} votes
                </span>
                <span>
                  <CalendarDays size={16} />{' '}
                  {getPollStatus(poll) === 'ended'
                    ? `Closed ${localDate(poll.endsAt, { year: undefined, hour: undefined, minute: undefined })}`
                    : `Ends ${localDate(poll.endsAt, { year: undefined, hour: undefined, minute: undefined })}`}
                </span>
              </div>
              <div className="poll-list-footer">
                <span>
                  {getPollStatus(poll) === 'ended' ? 'Explore the results' : 'Make your choice'}
                </span>
                <span>
                  <ArrowUpRight size={18} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="poll-empty">
          <Search size={27} />
          <h3>No polls found</h3>
          <p>Try another search or adjust the filters to see more conversations.</p>
          <button
            className="button button-outline"
            onClick={() => {
              setKind('all');
              setStatus('all');
              setQuery('');
            }}
          >
            Clear all filters
          </button>
        </div>
      )}
      <div className="poll-ad">
        <AdSlot size="horizontal" label="Connect with an engaged audience" />
      </div>
      <section className="participate-banner">
        <div>
          <span className="eyebrow">THE WAY WE VOTE</span>
          <h2>Simple. Secure. Yours.</h2>
          <p>Verify your email, choose your answer, and follow the results as the conversation grows.</p>
        </div>
        <div className="participate-steps">
          <span>
            <strong>01</strong> Verify your email
          </span>
          <span>
            <strong>02</strong> Cast your vote
          </span>
          <span>
            <strong>03</strong> Explore the data
          </span>
        </div>
      </section>
    </div>
  );
}
