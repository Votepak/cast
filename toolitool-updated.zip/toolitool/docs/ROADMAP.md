# Toolitool development roadmap

## Status: initial foundation, not the full platform
The workspace was empty. This source is a dependency-free Node.js foundation, with 24 category entry points and 17 working browser tools, including five PDF tools. No accounts, backend AI, premium features, Excel editor, native apps, or distribution packages are implemented. Categories with no tools are explicitly marked coming soon. The service worker caches the shell and pages after first visit; it is not a verified offline application and there is no offline label or install button. Browser installation support varies; an SVG-only manifest is not a substitute for tested installable builds.

## Next phases
1. Foundation hardening: add accessible keyboard and screen-reader testing, automated browser tests, privacy policy/contact details, i18n/RTL, richer structured data, production domain-specific canonical URLs and sitemap, proper raster PWA icons and offline testing. Only publish claims verified on actual devices. Avoid indexing empty categories as tool pages.
2. Expand to 30 real tools, prioritizing local text, image, calculator and conversion workflows. Evaluate PDF and QR libraries for functionality, licenses, security, performance and offline packaging; test every tool against known cases. Do not publish placeholders.
3. Office apps: prototype spreadsheet editing with a vetted workbook parser/writer and formula engine, measure fidelity and performance against XLS/XLSX fixtures; implement versioned IndexedDB recovery and explicit import/export. Full Excel compatibility requires substantial separate engineering, and many workbook features cannot be assumed to round-trip. Similar separate investigations are needed for PDF, DOCX and media, including licensing and fidelity.
4. Add tools incrementally by category with tests, documentation and real unique pages. Make external dependencies, privacy and connectivity explicit.
5. Evaluate Capacitor/native iOS/Android and Tauri desktop packaging, permissions, signing, file access, update channels and platform store requirements. Build and test on actual platforms before offering APK/AAB, iOS or desktop packages. iOS PWA and native app capabilities differ.
6. Only then implement optional cloud sync, AI via a secure server, accounts, payment and premium plans, with a privacy and retention policy.
7. Run accessibility, security, cross-browser, offline/recovery and real-device QA continuously. Never claim offline or installation support without verification.

## Constraints
No external service, domain, store credentials, native SDKs, licensed AI provider or production hosting were provided. The browser cannot guarantee unrestricted filesystem access or durable storage; local data may be evicted. External fonts are decorative and fall back to system fonts. The current service worker caches visited URLs, but online/offline behavior and update handling need cross-browser testing. Individual tool pages are server rendered; search/filtering works client-side. All published tools run in-browser and do not transmit inputs to the server.
