const categories = [
['PDF Tools','PDF','Edit and work with documents'],['Image Tools','IMG','Create, convert and refine images'],['Text Tools','TXT','Write, edit and transform text'],['Calculators','CALC','Make everyday calculations simple'],['Unit Converters','UNIT','Convert measurements with ease'],['Date and Time Tools','TIME','Plan and calculate across dates'],['QR Code and Barcode Tools','QR','Create and read scannable codes'],['Password and Security Tools','SEC','Useful privacy and security utilities'],['Video and Audio Tools','MEDIA','Work with video and audio'],['Social Media Tools','SOCIAL','Create content for your channels'],['SEO and Website Tools','SEO','Build a better web presence'],['Developer and Coding Tools','CODE','Format, validate and create'],['Education and Student Tools','STUDY','Make learning more productive'],['AI Writing and Productivity Tools','AI','Get a little help with your writing'],['Career and Job Tools','CAREER','Take the next step in your career'],['Business and Finance Tools','BIZ','Practical tools for your business'],['Pakistan-Specific Tools','PK','Utilities tailored for Pakistan'],['Design and Color Tools','COLOR','Find the perfect look and feel'],['Productivity and Daily Life Tools','LIFE','Make more of your every day'],['Mathematics, Statistics and Research Tools','MATH','Explore numbers and data'],['E-commerce and Retail Tools','SHOP','Tools for modern retail'],['File and Data Conversion Tools','FILE','Convert and organize your files'],['Internet and Network Tools','NET','Understand your connection'],['Random and Fun Tools','FUN','A little bit of serendipity']];
const tools = [
{slug:'pdf-merger',name:'PDF Merger',category:'PDF Tools',icon:'PDF',description:'Combine multiple PDF documents into one file.',popular:true},
{slug:'pdf-page-extractor',name:'PDF Page Extractor',category:'PDF Tools',icon:'PDF',description:'Select pages from a PDF and save them as a new document.',popular:true},
{slug:'pdf-page-deleter',name:'PDF Page Deleter',category:'PDF Tools',icon:'PDF',description:'Remove selected pages from a PDF document.'},
{slug:'pdf-rotate',name:'PDF Rotate',category:'PDF Tools',icon:'PDF',description:'Rotate all pages of a PDF and save a copy.'},
{slug:'pdf-splitter',name:'PDF Splitter',category:'PDF Tools',icon:'PDF',description:'Split a PDF into separate single-page PDF files.'},
{slug:'word-counter',name:'Word Counter',category:'Text Tools',icon:'Aa',description:'Count words, characters, sentences and reading time as you type.',popular:true},
{slug:'case-converter',name:'Case Converter',category:'Text Tools',icon:'Tt',description:'Convert text to uppercase, lowercase or title case.',popular:true},
{slug:'remove-duplicate-lines',name:'Remove Duplicate Lines',category:'Text Tools',icon:'≡',description:'Clean up repeated lines while keeping their original order.'},
{slug:'percentage-calculator',name:'Percentage Calculator',category:'Calculators',icon:'%',description:'Find a percentage of any number in seconds.',popular:true},
{slug:'discount-calculator',name:'Discount Calculator',category:'Calculators',icon:'↘',description:'Calculate the final price and savings after a discount.',popular:true},
{slug:'length-converter',name:'Length Converter',category:'Unit Converters',icon:'↔',description:'Convert between meters, kilometers, feet, inches and miles.'},
{slug:'json-formatter',name:'JSON Formatter',category:'Developer and Coding Tools',icon:'{ }',description:'Validate and format JSON data right in your browser.',popular:true},
{slug:'password-generator',name:'Password Generator',category:'Password and Security Tools',icon:'✳',description:'Generate a random password using your device’s secure random source.',popular:true},
{slug:'image-resizer',name:'Image Resizer',category:'Image Tools',icon:'▧',description:'Resize an image locally and download it as a PNG.',popular:true},
{slug:'age-calculator',name:'Age Calculator',category:'Date and Time Tools',icon:'◷',description:'Calculate your age in years, months and days.'},
{slug:'base64-encoder',name:'Base64 Encoder',category:'Developer and Coding Tools',icon:'64',description:'Encode and decode Unicode text using Base64.'},
{slug:'color-converter',name:'HEX to RGB Converter',category:'Design and Color Tools',icon:'◉',description:'Convert a hexadecimal color code to RGB.'}
];
module.exports={categories,tools};
